# Changelog

## 1.1.0 (October 2026)

Commission instead of plans, and ads that run themselves.

- **Commission model**: sellers join free; the platform earns `COMMISSION_PERCENT` (default 5%) of every sale. Taken automatically on online payments; WhatsApp and hand-added orders add up on the new **Earnings** page and sellers pay it by MoMo or card. Cancelled orders are reversed or credited. WhatsApp checkout pauses at `COMMISSION_DUE_LIMIT` until paid. Admins see commission earned and still to collect, and can mark commission paid by hand.
- **Ads on Facebook, Instagram & TikTok**: connect ad accounts (OAuth, encrypted tokens), create ads with AI-written text and a live preview, pause/resume/end, change budgets.
- **AI ads autopilot**: picks products to advertise from real sales and stock, writes and launches ads (or suggests them for approval), pauses ads that don't perform and boosts winners, always within the seller's daily limit.
- **Ad results for sellers**: spend, views, clicks, CTR, CPC, shop visits, WhatsApp chats, orders and sales from ads, ROAS, daily chart, autopilot timeline. Ad links are tracked so orders from ads are tagged.
- **Demo ad network** (`ADS_DEMO_MODE`) with believable simulated results, seeded for Ama's Kitchen and in the browser demo.
- AI service: `/v1/ad-copy` and `/v1/ads-autopilot`, with code-based product scoring and an offline writer.
- Removed: plans, billing and plan limits (`PLAN_CURRENCY`, `FREE_PRODUCT_LIMIT`, `FREE_AI_CREDITS`, `PAID_AI_CREDITS`). New: `AI_MONTHLY_CREDITS`, `PRODUCT_LIMIT`, `DEFAULT_CURRENCY`, `ADS_*`, `META_*`, `TIKTOK_*`.
- New guide: docs/ADS.md. Tests: 50 Java unit tests + the full journey, 32 Python tests.

## 1.0.0 (October 2026)

First full-stack release, rebuilt from the Lite Marketplace Plain app.

- Java 21 / Spring Boot API: accounts, shops, products, orders, plans (replaced by commission in 1.1.0), admin, uploads
- Secure logins: BCrypt, JWT access tokens, rotating HttpOnly refresh tokens, password reset, rate limits
- Payments: Paystack, Flutterwave and Stripe with server-side verification, signed webhooks, split payments, commission and payouts ledger, plus a demo gateway
- Python AI service: product writer (with photo), shopper chat, reply drafts, sales coach, broadcast writer; Claude, OpenAI or built-in engine
- React website: animated landing page, seller dashboard, storefront with cart, WhatsApp and online checkout, admin panel, dark mode, browser demo mode
- Docker Compose deployment, documentation and automated tests
