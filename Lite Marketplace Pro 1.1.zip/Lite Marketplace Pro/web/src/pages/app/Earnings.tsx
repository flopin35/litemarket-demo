import { useEffect, useState } from "react";
import { FaWhatsapp } from "react-icons/fa6";
import {
  LuArrowDownLeft,
  LuBanknote,
  LuCircleCheck,
  LuHandCoins,
  LuPercent,
  LuShieldCheck,
  LuTriangleAlert,
  LuUndo2,
  LuWallet,
} from "react-icons/lu";
import { Kpi } from "../../components/Kpi";
import { Badge, Button, Card, EmptyState, ErrorBox, PageHeader, Skeleton } from "../../components/ui";
import { api, errorMessage } from "../../lib/api";
import { cn } from "../../lib/cn";
import { money, shortDate } from "../../lib/format";
import { useLoad, usePageTitle } from "../../lib/hooks";
import { navigate, useLocation } from "../../lib/router";
import { useToast } from "../../lib/toast";
import type { CheckoutStart, CommissionEntry, Earnings as EarningsData } from "../../lib/types";

/**
 * The seller's money page. Sellers don't pay a monthly fee: the platform takes a small percentage of each
 * sale. Online payments pay it automatically; WhatsApp and hand-added orders add it here to pay later.
 */
export default function Earnings() {
  usePageTitle("Earnings");
  const toast = useToast();
  const { query } = useLocation();
  const { data, error, loading, reload } = useLoad(() => api.get<EarningsData>("/api/earnings"));
  const [provider, setProvider] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    if (query.get("cancelled")) {
      toast("Payment cancelled. You can try again any time.", "info");
      navigate("/app/earnings", { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (data && !provider) setProvider(data.providers[0]?.id ?? null);
  }, [data, provider]);

  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const cur = data?.currency ?? "GHS";

  async function pay() {
    if (!provider) return;
    setPaying(true);
    try {
      const r = await api.post<CheckoutStart>("/api/earnings/pay", { provider });
      window.location.href = r.checkoutUrl;
    } catch (e) {
      toast(errorMessage(e), "error");
      setPaying(false);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Earnings"
        subtitle={data ? `No monthly fees. You pay ${data.percent}% only when you make a sale.` : "Your sales and commission"}
      />

      {data?.whatsappPaused && (
        <div className="flex animate-fade-up items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-200">
          <LuTriangleAlert className="mt-0.5 size-5 shrink-0" />
          <div>
            <p className="font-bold">WhatsApp ordering is paused on your shop</p>
            <p className="mt-0.5">
              You owe {money(data.due, cur)} in commission (the limit is {money(data.dueLimit, cur)}). Customers can still pay online.
              Pay below and WhatsApp orders switch back on straight away.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Kpi loading={loading} icon={<LuBanknote />} tone="green" label="Sales this month" value={data?.salesThisMonth ?? 0} money={cur} sub="paid & delivered" />
        <Kpi loading={loading} icon={<LuWallet />} tone={data?.whatsappPaused ? "rose" : "amber"} label="Commission due" value={data?.due ?? 0} money={cur} sub={data?.due ? "from WhatsApp orders" : "all clear"} delay={60} />
        <Kpi loading={loading} icon={<LuPercent />} tone="violet" label="Commission paid" value={data?.paidThisMonth ?? 0} money={cur} sub={data ? `${money(data.paidAllTime, cur)} all time` : ""} delay={120} />
        <Kpi loading={loading} icon={<LuHandCoins />} tone="sky" label="Owed to you" value={data?.owedToYou ?? 0} money={cur} sub="online payments we'll send you" delay={180} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="animate-fade-up p-5 [animation-delay:120ms] sm:p-6 lg:col-span-2">
          {loading || !data ? (
            <Skeleton className="h-44" />
          ) : data.due > 0 ? (
            <div>
              <p className="text-sm font-semibold text-zinc-500">Commission to pay</p>
              <p className="mt-1 text-4xl font-black tracking-tight tabular-nums">{money(data.due, cur)}</p>
              <p className="mt-1 text-sm text-zinc-500">
                {data.percent}% of the WhatsApp and hand-added orders you marked as paid or delivered.
              </p>
              {data.providers.length ? (
                <>
                  <div className="mt-5 grid gap-2 sm:grid-cols-2">
                    {data.providers.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => setProvider(p.id)}
                        className={cn(
                          "flex items-center gap-3 rounded-2xl border-2 p-3.5 text-left text-sm font-semibold transition-all duration-200",
                          provider === p.id
                            ? "border-brand-500 bg-brand-50/60 dark:bg-brand-500/10"
                            : "border-zinc-200 hover:border-zinc-300 dark:border-white/10",
                        )}
                      >
                        <span className={cn("flex size-5 items-center justify-center rounded-full border-2", provider === p.id ? "border-brand-500 bg-brand-500 text-white" : "border-zinc-300")}>
                          {provider === p.id && <LuCircleCheck className="size-3" />}
                        </span>
                        {p.label}
                      </button>
                    ))}
                  </div>
                  <Button className="mt-5 w-full sm:w-auto" size="lg" loading={paying} onClick={pay} icon={<LuShieldCheck />}>
                    Pay {money(data.due, cur)}
                  </Button>
                </>
              ) : (
                <p className="mt-4 text-sm text-zinc-500">Online payments aren't switched on yet. Pay the admin directly and they'll mark it as paid.</p>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center py-6 text-center">
              <div className="flex size-16 animate-pop items-center justify-center rounded-full bg-brand-50 text-3xl text-brand-600 dark:bg-brand-500/15">
                <LuCircleCheck />
              </div>
              <p className="mt-4 text-lg font-bold">You're all clear</p>
              <p className="mt-1 max-w-sm text-sm text-zinc-500">
                Nothing to pay right now. Commission on online payments is taken automatically when your customer pays.
              </p>
            </div>
          )}
        </Card>

        <Card className="animate-fade-up p-5 [animation-delay:180ms] sm:p-6">
          <h2 className="font-bold">How commission works</h2>
          <ul className="mt-4 space-y-4 text-sm">
            <li className="flex gap-3">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15"><LuShieldCheck /></span>
              <span><b>Online payments:</b> {data?.percent ?? 5}% is taken automatically when the customer pays. Nothing to do.</span>
            </li>
            <li className="flex gap-3">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-xl bg-[#1fae53]/10 text-[#1fae53]"><FaWhatsapp /></span>
              <span>
                <b>WhatsApp & hand-added orders:</b>{" "}
                {data?.chargesWhatsappOrders === false
                  ? "free: no commission."
                  : "the commission is added here when you mark the order Paid or Delivered."}
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-xl bg-zinc-100 text-zinc-600 dark:bg-white/10"><LuUndo2 /></span>
              <span><b>Cancelled an order?</b> Its commission is removed, or credited if you already paid it.</span>
            </li>
          </ul>
        </Card>
      </div>

      <Card className="animate-fade-up overflow-hidden [animation-delay:220ms]">
        <div className="flex items-center justify-between p-5 pb-3 sm:px-6">
          <h2 className="font-bold">Commission history</h2>
          <span className="text-xs text-zinc-400">Latest 100</span>
        </div>
        {loading ? (
          <div className="space-y-2 p-5 pt-0">
            {[0, 1, 2].map((i) => <Skeleton key={i} className="h-11" />)}
          </div>
        ) : data && data.entries.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="border-y border-zinc-100 bg-zinc-50/80 text-left text-xs font-semibold text-zinc-500 dark:border-white/5 dark:bg-white/5">
                  <th className="px-5 py-2.5 sm:pl-6">Date</th>
                  <th className="px-3 py-2.5">Order</th>
                  <th className="px-3 py-2.5">How it was paid</th>
                  <th className="px-3 py-2.5 text-right">Order total</th>
                  <th className="px-3 py-2.5 text-right">Commission</th>
                  <th className="px-5 py-2.5 sm:pr-6">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-white/5">
                {data.entries.map((e) => (
                  <tr key={e.id} className="transition hover:bg-zinc-50/60 dark:hover:bg-white/5">
                    <td className="px-5 py-3 whitespace-nowrap text-zinc-500 sm:pl-6">{shortDate(e.createdAt)}</td>
                    <td className="px-3 py-3 font-mono text-xs">{e.orderNumber ?? "-"}</td>
                    <td className="px-3 py-3"><KindLabel entry={e} /></td>
                    <td className="px-3 py-3 text-right tabular-nums">{money(e.orderTotal, e.currency)}</td>
                    <td className={cn("px-3 py-3 text-right font-semibold tabular-nums", e.amount < 0 && "text-brand-600")}>{money(e.amount, e.currency)}</td>
                    <td className="px-5 py-3 sm:pr-6"><EntryStatus entry={e} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState icon={<LuPercent />} title="No commission yet" text="When you make sales, the commission for each order shows up here." />
        )}
      </Card>

      {data && data.payments.length > 0 && (
        <Card className="animate-fade-up p-5 [animation-delay:260ms] sm:p-6">
          <h2 className="mb-3 font-bold">Your commission payments</h2>
          <ul className="divide-y divide-zinc-100 text-sm dark:divide-white/5">
            {data.payments.map((p) => (
              <li key={p.reference} className="flex items-center gap-3 py-3">
                <span className="flex size-9 items-center justify-center rounded-xl bg-zinc-100 text-zinc-600 dark:bg-white/10"><LuArrowDownLeft /></span>
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold">{money(p.amount, p.currency)}</span>
                  <span className="block truncate font-mono text-xs text-zinc-400">{p.reference} · {p.provider}</span>
                </span>
                <span className="text-right text-xs text-zinc-500">
                  <Badge tone={p.status === "SUCCESS" ? "green" : p.status === "FAILED" ? "rose" : "amber"}>
                    {p.status === "SUCCESS" ? "Paid" : p.status === "FAILED" ? "Failed" : "Pending"}
                  </Badge>
                  <span className="mt-1 block">{shortDate(p.paidAt ?? p.createdAt)}</span>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}

function KindLabel({ entry }: { entry: CommissionEntry }) {
  if (entry.kind === "ONLINE") return <span className="text-zinc-600 dark:text-zinc-300">Online · taken automatically</span>;
  if (entry.kind === "ADJUSTMENT") return <span className="text-zinc-600 dark:text-zinc-300">Credit · order cancelled</span>;
  return (
    <span className="inline-flex items-center gap-1.5 text-zinc-600 dark:text-zinc-300">
      <FaWhatsapp className="text-[#1fae53]" /> WhatsApp / by hand
    </span>
  );
}

function EntryStatus({ entry }: { entry: CommissionEntry }) {
  switch (entry.status) {
    case "DUE":
      return <Badge tone="amber">To pay</Badge>;
    case "SETTLED":
      return <Badge tone="green">Paid</Badge>;
    case "REVERSED":
      return <Badge tone="zinc">Removed</Badge>;
    default:
      return <Badge tone="zinc">Waived</Badge>;
  }
}
