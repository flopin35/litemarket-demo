import { useEffect, useState } from "react";
import { LuBot, LuShieldCheck } from "react-icons/lu";
import { Drawer } from "../../../components/Overlay";
import { Button, Input, Switch } from "../../../components/ui";
import { api, errorMessage } from "../../../lib/api";
import { cn } from "../../../lib/cn";
import { money } from "../../../lib/format";
import { useToast } from "../../../lib/toast";
import type { AdNetworkId, AdSettingsInput, AdSettingsView, NetworkView } from "../../../lib/types";
import { NETWORK_LABEL } from "./adUi";

/** Autopilot on/off, spending limits and rules. */
export function AutopilotDrawer({
  open,
  onClose,
  settings,
  networks,
  shopCurrency,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  settings: AdSettingsView;
  networks: NetworkView[];
  shopCurrency: string;
  onSaved: (s: AdSettingsView) => void;
}) {
  const toast = useToast();
  const [form, setForm] = useState<AdSettingsInput>(() => toInput(settings));
  const [countries, setCountries] = useState(settings.countries.join(", "));
  const [accept, setAccept] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(toInput(settings));
      setCountries(settings.countries.join(", "));
      setAccept(false);
    }
  }, [open, settings]);

  const connected = networks.filter((n) => n.status === "CONNECTED");
  const adCurrency = connected[0]?.currency ?? shopCurrency;
  const needsFx = adCurrency !== shopCurrency;
  const needsTerms = form.autopilotEnabled && !settings.termsAccepted;
  const set = <K extends keyof AdSettingsInput>(k: K, v: AdSettingsInput[K]) => setForm((f) => ({ ...f, [k]: v }));

  function toggleNetwork(n: AdNetworkId) {
    set("networks", form.networks.includes(n) ? form.networks.filter((x) => x !== n) : [...form.networks, n]);
  }

  async function save() {
    setSaving(true);
    try {
      const body: AdSettingsInput = {
        ...form,
        countries: countries.split(/[\s,]+/).map((c) => c.trim().toUpperCase()).filter(Boolean),
        acceptTerms: accept,
      };
      const s = await api.put<AdSettingsView>("/api/ads/settings", body);
      toast(s.autopilotEnabled ? "Autopilot is on" : "Settings saved");
      onSaved(s);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={
        <span className="flex items-center gap-2">
          <LuBot className="text-violet-500" /> AI autopilot
        </span>
      }
      subtitle="Picks your best products, writes the ads, keeps winners running and pauses the rest."
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving} disabled={(needsTerms && !accept) || form.networks.length === 0}>
            Save
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        <div className="space-y-3 rounded-2xl bg-zinc-50 p-4 dark:bg-white/5">
          <Switch checked={form.autopilotEnabled} onChange={(v) => set("autopilotEnabled", v)} label="Autopilot on" hint="Checks your ads every few hours." />
          <Switch
            checked={form.autoLaunch}
            onChange={(v) => set("autoLaunch", v)}
            label="Launch new ads by itself"
            hint={form.autoLaunch ? "New ads start automatically within your limits." : "New ads wait for you to approve them."}
          />
        </div>

        <div>
          <p className="mb-2 text-sm font-semibold">Where to advertise</p>
          <div className="grid grid-cols-2 gap-2">
            {(["meta", "tiktok"] as AdNetworkId[]).map((n) => {
              const status = networks.find((x) => x.network === n)?.status ?? "DISCONNECTED";
              const on = form.networks.includes(n);
              return (
                <button
                  key={n}
                  type="button"
                  onClick={() => toggleNetwork(n)}
                  className={cn(
                    "rounded-xl border-2 p-3 text-left text-sm transition",
                    on ? "border-violet-500 bg-violet-50/60 dark:bg-violet-500/10" : "border-zinc-200 dark:border-white/10",
                  )}
                >
                  <span className="block font-semibold">{NETWORK_LABEL[n]}</span>
                  <span className={cn("text-xs", status === "CONNECTED" ? "text-brand-600" : "text-zinc-400")}>
                    {status === "CONNECTED" ? "Connected" : "Not connected yet"}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Input
            label="Daily limit (all ads)"
            type="number"
            min={0}
            step="0.5"
            leading={adCurrency}
            value={form.dailyBudgetCap}
            onChange={(e) => set("dailyBudgetCap", Number(e.target.value))}
            hint="The most it may spend per day."
          />
          <Input
            label="Budget per ad"
            type="number"
            min={0.5}
            step="0.5"
            leading={adCurrency}
            value={form.perAdBudget}
            onChange={(e) => set("perAdBudget", Number(e.target.value))}
            hint="Per day, for each new ad."
          />
          <Input
            label="Ads at the same time"
            type="number"
            min={1}
            max={10}
            value={form.maxActiveAds}
            onChange={(e) => set("maxActiveAds", Math.max(1, Math.min(10, Number(e.target.value))))}
          />
          <Input label="Countries" value={countries} onChange={(e) => setCountries(e.target.value)} hint="Codes, e.g. GH, NG" />
          <Input label="Youngest age" type="number" min={18} max={65} value={form.ageMin} onChange={(e) => set("ageMin", Number(e.target.value))} />
          <Input label="Oldest age" type="number" min={18} max={65} value={form.ageMax} onChange={(e) => set("ageMax", Number(e.target.value))} />
        </div>

        <details className="group rounded-2xl border border-zinc-200 p-4 dark:border-white/10">
          <summary className="cursor-pointer text-sm font-semibold">Advanced rules</summary>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <Input
              label="Pause below click rate"
              type="number"
              min={0}
              step="0.1"
              leading="%"
              value={form.minCtr}
              onChange={(e) => set("minCtr", Number(e.target.value))}
              hint="Judged after 1,500 views."
            />
            <Input
              label="Max cost per click"
              type="number"
              min={0}
              step="0.01"
              leading={adCurrency}
              value={form.maxCpc ?? ""}
              placeholder="No limit"
              onChange={(e) => set("maxCpc", e.target.value === "" ? null : Number(e.target.value))}
            />
            {needsFx && (
              <Input
                className="col-span-2"
                label={`1 ${adCurrency} in ${shopCurrency}`}
                type="number"
                min={0}
                step="0.01"
                value={form.fxRate ?? ""}
                placeholder="e.g. 15.50"
                onChange={(e) => set("fxRate", e.target.value === "" ? null : Number(e.target.value))}
                hint="Lets us compare ad spend with your sales (return on ad spend)."
              />
            )}
          </div>
          <p className="mt-3 text-xs text-zinc-500">
            The autopilot also pauses ads that spend 4 days of budget without an order, and gives ads that bring orders 20% more budget
            (within your daily limit).
          </p>
        </details>

        {needsTerms && (
          <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-100">
            <input type="checkbox" checked={accept} onChange={(e) => setAccept(e.target.checked)} className="mt-1 size-4 accent-violet-600" />
            <span>
              <span className="flex items-center gap-1.5 font-bold">
                <LuShieldCheck /> I understand ads cost money
              </span>
              The autopilot may spend up to {money(form.dailyBudgetCap, adCurrency)} a day from my connected ad accounts. I can pause it at any time.
            </span>
          </label>
        )}
      </div>
    </Drawer>
  );
}

function toInput(s: AdSettingsView): AdSettingsInput {
  return {
    autopilotEnabled: s.autopilotEnabled,
    autoLaunch: s.autoLaunch,
    networks: s.networks.length ? s.networks : ["meta"],
    dailyBudgetCap: Number(s.dailyBudgetCap),
    perAdBudget: Number(s.perAdBudget),
    maxActiveAds: s.maxActiveAds,
    countries: s.countries,
    ageMin: s.ageMin,
    ageMax: s.ageMax,
    minCtr: Number(s.minCtr),
    maxCpc: s.maxCpc,
    fxRate: s.fxRate,
    acceptTerms: false,
  };
}
