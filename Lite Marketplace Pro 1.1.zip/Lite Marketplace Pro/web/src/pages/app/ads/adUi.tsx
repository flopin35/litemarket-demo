import type { ReactNode } from "react";
import { LuEllipsis, LuHeart, LuMessageCircle, LuSend } from "react-icons/lu";
import { Avatar, ProductImage } from "../../../components/bits";
import { Badge } from "../../../components/ui";
import { cn } from "../../../lib/cn";
import type { AdNetworkId, AdStatus, CallToAction } from "../../../lib/types";

export const NETWORK_LABEL: Record<AdNetworkId, string> = { meta: "Facebook & Instagram", tiktok: "TikTok" };

export const CTA_LABEL: Record<CallToAction, string> = {
  SHOP_NOW: "Shop now",
  ORDER_NOW: "Order now",
  LEARN_MORE: "Learn more",
  BUY_NOW: "Buy now",
};

/** Small coloured chip naming the network (text only, no third-party logos). */
export function NetworkChip({ network, className }: { network: AdNetworkId; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-bold whitespace-nowrap",
        network === "meta" ? "bg-[#1877F2]/10 text-[#1563d0] dark:bg-[#1877F2]/20 dark:text-[#7fb2ff]" : "bg-zinc-900 text-white dark:bg-white dark:text-zinc-900",
        className,
      )}
    >
      <span className={cn("size-1.5 rounded-full", network === "meta" ? "bg-[#1877F2]" : "bg-[#25F4EE] shadow-[1.5px_0_0_#FE2C55]")} />
      {network === "meta" ? "Facebook & Instagram" : "TikTok"}
    </span>
  );
}

const STATUS: Record<AdStatus, { label: string; tone: "green" | "amber" | "rose" | "sky" | "zinc" | "violet" }> = {
  DRAFT: { label: "Suggested", tone: "violet" },
  LAUNCHING: { label: "Launching", tone: "sky" },
  IN_REVIEW: { label: "In review", tone: "amber" },
  ACTIVE: { label: "Running", tone: "green" },
  PAUSED: { label: "Paused", tone: "zinc" },
  REJECTED: { label: "Not approved", tone: "rose" },
  ERROR: { label: "Needs attention", tone: "rose" },
  ENDED: { label: "Ended", tone: "zinc" },
};

export function AdStatusBadge({ status }: { status: AdStatus }) {
  const s = STATUS[status];
  return (
    <Badge tone={s.tone}>
      {status === "ACTIVE" && <span className="size-1.5 animate-pulse rounded-full bg-current" />}
      {s.label}
    </Badge>
  );
}

/** A generic social feed post / short-video mock so sellers see roughly how the ad will look. */
export function AdPreview(props: {
  network: AdNetworkId;
  shopName: string;
  logoUrl?: string | null;
  accent?: string | null;
  imageUrl?: string | null;
  productName: string;
  category?: string | null;
  headline: string;
  primaryText: string;
  description?: string | null;
  cta: CallToAction;
  domain: string;
}) {
  if (props.network === "tiktok") {
    return (
      <div className="mx-auto w-[220px] overflow-hidden rounded-[28px] border-[6px] border-zinc-900 bg-zinc-900 shadow-xl">
        <div className="relative aspect-[9/16] overflow-hidden rounded-[22px]">
          <ProductImage src={props.imageUrl} name={props.productName} category={props.category} className="absolute inset-0" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
          <div className="absolute top-3 left-3 rounded-full bg-black/40 px-2 py-0.5 text-[10px] font-semibold text-white backdrop-blur">Sponsored</div>
          <div className="absolute right-2 bottom-24 flex flex-col items-center gap-3 text-white">
            <Avatar name={props.shopName} src={props.logoUrl} color={props.accent} className="size-8 text-[10px] ring-2 ring-white" />
            <LuHeart className="size-5" />
            <LuMessageCircle className="size-5" />
            <LuSend className="size-5" />
          </div>
          <div className="absolute inset-x-3 bottom-3 text-white">
            <p className="text-xs font-bold">@{props.shopName.toLowerCase().replace(/[^a-z0-9]+/g, "")}</p>
            <p className="mt-1 line-clamp-3 text-[11px] leading-snug">{props.primaryText || "Your ad text appears here"}</p>
            <div className="mt-2 rounded-md bg-[#FE2C55] py-1.5 text-center text-[11px] font-bold">{CTA_LABEL[props.cta]}</div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="mx-auto w-full max-w-[340px] overflow-hidden rounded-2xl border border-zinc-200 bg-white text-zinc-900 shadow-lg dark:border-white/10 dark:bg-zinc-900 dark:text-white">
      <div className="flex items-center gap-2.5 px-3 pt-3">
        <Avatar name={props.shopName} src={props.logoUrl} color={props.accent} className="size-9 text-xs" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">{props.shopName}</p>
          <p className="text-[11px] text-zinc-500">Sponsored</p>
        </div>
        <LuEllipsis className="text-zinc-400" />
      </div>
      <p className="px-3 py-2.5 text-[13px] leading-snug whitespace-pre-line">{props.primaryText || "Your ad text appears here"}</p>
      <div className="aspect-square bg-zinc-100">
        <ProductImage src={props.imageUrl} name={props.productName} category={props.category} />
      </div>
      <div className="flex items-center gap-3 bg-zinc-50 px-3 py-2.5 dark:bg-white/5">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[11px] text-zinc-500 uppercase">{props.domain}</p>
          <p className="truncate text-sm font-bold">{props.headline || "Your headline"}</p>
          {props.description && <p className="truncate text-xs text-zinc-500">{props.description}</p>}
        </div>
        <span className="shrink-0 rounded-md bg-zinc-200 px-3 py-1.5 text-xs font-bold dark:bg-white/15">{CTA_LABEL[props.cta]}</span>
      </div>
    </div>
  );
}

export function Metric({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="min-w-0" title={hint}>
      <p className="truncate text-[11px] font-semibold text-zinc-500 uppercase">{label}</p>
      <p className="truncate text-sm font-bold tabular-nums">{value}</p>
    </div>
  );
}
