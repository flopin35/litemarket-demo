import { useState } from "react";
import { LuBot, LuCircleAlert, LuPause, LuPencil, LuPlay, LuRocket, LuSquare, LuTrash2 } from "react-icons/lu";
import { ProductImage } from "../../../components/bits";
import { Confirm, Modal } from "../../../components/Overlay";
import { Button, Input } from "../../../components/ui";
import { api, errorMessage } from "../../../lib/api";
import { cn } from "../../../lib/cn";
import { money, timeAgo } from "../../../lib/format";
import { useToast } from "../../../lib/toast";
import type { AdView } from "../../../lib/types";
import { AdStatusBadge, CTA_LABEL, Metric, NetworkChip } from "./adUi";

/** One ad with its numbers and controls. Drafts (autopilot suggestions) get Approve / Discard. */
export function AdCard({
  ad,
  shopCurrency,
  onChange,
  onRemove,
  delay = 0,
}: {
  ad: AdView;
  shopCurrency: string;
  onChange: (ad: AdView) => void;
  onRemove: (id: number) => void;
  delay?: number;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const [ending, setEnding] = useState(false);
  const [editBudget, setEditBudget] = useState(false);
  const [budget, setBudget] = useState(Number(ad.dailyBudget));
  const cur = ad.currency ?? shopCurrency;

  async function act(action: "pause" | "resume" | "end" | "approve") {
    setBusy(action);
    try {
      const r = await api.post<AdView>(`/api/ads/${ad.id}/${action}`);
      if (ad.status === "DRAFT" && action === "end") {
        onRemove(ad.id);
        toast("Suggestion discarded", "info");
      } else {
        onChange(r);
        toast(
          action === "pause" ? "Ad paused" : action === "resume" ? "Ad running again" : action === "approve"
            ? r.status === "ERROR" ? r.lastError ?? "Couldn't launch the ad" : "Ad launched"
            : "Ad ended",
          r.status === "ERROR" ? "error" : "success",
        );
      }
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setBusy(null);
      setEnding(false);
    }
  }

  async function saveBudget() {
    setBusy("budget");
    try {
      onChange(await api.put<AdView>(`/api/ads/${ad.id}/budget`, { dailyBudget: budget }));
      toast("Budget updated");
      setEditBudget(false);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setBusy(null);
    }
  }

  const draft = ad.status === "DRAFT";
  const ended = ad.status === "ENDED";

  return (
    <div className="animate-fade-up" style={{ animationDelay: `${delay}ms` }}>
      <div
        className={cn(
          "card group flex h-full flex-col overflow-hidden transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg",
          draft && "ring-2 ring-violet-400/60",
          ended && "opacity-70",
        )}
      >
        <div className="flex gap-3 p-4">
          <div className="size-20 shrink-0 overflow-hidden rounded-xl">
            <ProductImage src={ad.imageUrl} name={ad.productName ?? "Product"} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <AdStatusBadge status={ad.status} />
              <NetworkChip network={ad.network} />
              {ad.origin === "AUTOPILOT" && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-violet-600 dark:text-violet-300">
                  <LuBot /> AI
                </span>
              )}
            </div>
            <p className="mt-1.5 line-clamp-2 leading-snug font-bold">{ad.headline}</p>
            <p className="line-clamp-2 text-sm text-zinc-500">{ad.primaryText}</p>
          </div>
        </div>

        {(ad.aiReason && draft) && (
          <p className="mx-4 mb-3 rounded-xl bg-violet-50 px-3 py-2 text-xs text-violet-800 dark:bg-violet-500/10 dark:text-violet-200">
            <LuBot className="mr-1 inline" /> {ad.aiReason}
          </p>
        )}
        {(ad.reviewNote || ad.lastError) && (ad.status === "REJECTED" || ad.status === "ERROR") && (
          <p className="mx-4 mb-3 flex items-start gap-2 rounded-xl bg-rose-50 px-3 py-2 text-xs text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
            <LuCircleAlert className="mt-0.5 shrink-0" /> {ad.reviewNote ?? ad.lastError}
          </p>
        )}

        {!draft && (
          <div className="mx-4 grid grid-cols-4 gap-2 rounded-xl bg-zinc-50 px-3 py-2.5 dark:bg-white/5">
            <Metric label="Spent" value={`${cur} ${Math.round(Number(ad.spend)).toLocaleString()}`} hint={money(ad.spend, cur)} />
            <Metric label="Clicks" value={ad.clicks.toLocaleString()} hint={`${ad.impressions.toLocaleString()} views`} />
            <Metric label="CTR" value={ad.ctr != null ? `${ad.ctr.toFixed(2)}%` : "-"} hint="Clicks per 100 views" />
            <Metric label="Orders" value={`${ad.orders}`} hint={money(ad.revenue, shopCurrency) + " in sales"} />
          </div>
        )}

        <div className="mt-auto flex flex-wrap items-center gap-2 p-4 pt-3">
          <span className="mr-auto text-xs text-zinc-500">
            {money(ad.dailyBudget, cur)}/day · {CTA_LABEL[ad.callToAction ?? "SHOP_NOW"]}
            {ad.launchedAt ? ` · ${timeAgo(ad.launchedAt)}` : ""}
          </span>
          {draft ? (
            <>
              <Button size="sm" variant="ghost" onClick={() => act("end")} loading={busy === "end"} icon={<LuTrash2 />}>
                Discard
              </Button>
              <Button size="sm" onClick={() => act("approve")} loading={busy === "approve"} icon={<LuRocket />}>
                Approve & launch
              </Button>
            </>
          ) : ad.status === "ERROR" && !ad.launchedAt ? (
            <>
              <Button size="sm" variant="ghost" onClick={() => act("end")} loading={busy === "end"} icon={<LuTrash2 />}>
                Remove
              </Button>
              <Button size="sm" variant="secondary" onClick={() => act("approve")} loading={busy === "approve"} icon={<LuRocket />}>
                Try again
              </Button>
            </>
          ) : !ended ? (
            <>
              {(ad.status === "ACTIVE" || ad.status === "IN_REVIEW" || ad.status === "PAUSED") && (
                <Button size="sm" variant="ghost" onClick={() => setEditBudget(true)} icon={<LuPencil />} aria-label="Change budget">
                  Budget
                </Button>
              )}
              {ad.status === "PAUSED" ? (
                <Button size="sm" variant="secondary" onClick={() => act("resume")} loading={busy === "resume"} icon={<LuPlay />}>
                  Resume
                </Button>
              ) : (ad.status === "ACTIVE" || ad.status === "IN_REVIEW") && (
                <Button size="sm" variant="secondary" onClick={() => act("pause")} loading={busy === "pause"} icon={<LuPause />}>
                  Pause
                </Button>
              )}
              <Button size="sm" variant="ghost" className="text-rose-600!" onClick={() => setEnding(true)} icon={<LuSquare />}>
                End
              </Button>
            </>
          ) : null}
        </div>
      </div>

      <Confirm
        open={ending}
        onClose={() => setEnding(false)}
        onConfirm={() => act("end")}
        busy={busy === "end"}
        title="End this ad?"
        text="It stops for good. You can always create a new ad for this product later."
        confirmLabel="End ad"
      />
      <Modal
        open={editBudget}
        onClose={() => setEditBudget(false)}
        size="sm"
        title="Daily budget"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setEditBudget(false)}>Cancel</Button>
            <Button onClick={saveBudget} loading={busy === "budget"}>Save</Button>
          </div>
        }
      >
        <Input type="number" min={0.5} step="0.5" leading={cur} value={budget} onChange={(e) => setBudget(Number(e.target.value))} hint="Changes apply from now." />
      </Modal>
    </div>
  );
}
