import { useEffect, useMemo, useState } from "react";
import { LuRocket, LuSparkles, LuWandSparkles } from "react-icons/lu";
import { EngineBadge, ProductImage } from "../../../components/bits";
import { Drawer } from "../../../components/Overlay";
import { Button, Input, Segmented, Select, Skeleton, Textarea } from "../../../components/ui";
import { ApiError, api, errorMessage } from "../../../lib/api";
import { useAuth } from "../../../lib/auth";
import { cn } from "../../../lib/cn";
import { money } from "../../../lib/format";
import { useLoad } from "../../../lib/hooks";
import { navigate } from "../../../lib/router";
import { useToast } from "../../../lib/toast";
import type { AdCopy, AdNetworkId, AdView, CallToAction, LaunchInput, NetworkView, Product } from "../../../lib/types";
import { AdPreview, CTA_LABEL, NETWORK_LABEL } from "./adUi";

/** Create one ad by hand: pick a product, let the AI write it (or write it yourself), set the budget, launch. */
export function CreateAdDrawer({
  open,
  onClose,
  networks,
  maxDailyBudget,
  presetProductId,
  onLaunched,
}: {
  open: boolean;
  onClose: () => void;
  networks: NetworkView[];
  maxDailyBudget: number | null;
  presetProductId?: number | null;
  onLaunched: (ad: AdView) => void;
}) {
  const toast = useToast();
  const { me } = useAuth();
  const store = me?.store;
  const products = useLoad(() => (open ? api.get<Product[]>("/api/products") : Promise.resolve([] as Product[])), [open]);
  const connected = networks.filter((n) => n.status === "CONNECTED");
  const [network, setNetwork] = useState<AdNetworkId>("meta");
  const [productId, setProductId] = useState<number | null>(null);
  const [copy, setCopy] = useState<AdCopy | null>(null);
  const [writing, setWriting] = useState(false);
  const [form, setForm] = useState({ headline: "", primaryText: "", description: "", cta: "SHOP_NOW" as CallToAction });
  const [budget, setBudget] = useState(5);
  const [days, setDays] = useState<"0" | "7" | "14" | "30">("0");
  const [countries, setCountries] = useState("GH");
  const [ages, setAges] = useState({ min: 18, max: 45 });
  const [launching, setLaunching] = useState(false);

  useEffect(() => {
    if (!open) return;
    setNetwork(connected[0]?.network ?? "meta");
    setProductId(presetProductId ?? null);
    setCopy(null);
    setForm({ headline: "", primaryText: "", description: "", cta: "SHOP_NOW" });
    setDays("0");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const net = networks.find((n) => n.network === network);
  const currency = net?.currency ?? store?.currency ?? "GHS";
  const min = Number(net?.minDailyBudget ?? 1);
  useEffect(() => {
    setBudget((b) => (b < min ? min : b));
  }, [min]);

  const available = useMemo(() => (products.data ?? []).filter((p) => p.available), [products.data]);
  const product = available.find((p) => p.id === productId) ?? null;
  const textLimit = network === "tiktok" ? 100 : 500;

  async function write() {
    if (!productId) return;
    setWriting(true);
    try {
      const c = await api.post<AdCopy>("/api/ads/copy", { productId, network });
      setCopy(c);
      pick(c, 0);
    } catch (e) {
      if (e instanceof ApiError && e.code === "AI_CREDITS") navigate("/app/earnings");
      toast(errorMessage(e), "error");
    } finally {
      setWriting(false);
    }
  }

  function pick(c: AdCopy, i: number) {
    const v = c.variants[i];
    if (!v) return;
    setForm({ headline: v.headline, primaryText: v.primary_text, description: v.description ?? "", cta: v.call_to_action });
  }

  async function launch() {
    if (!productId) return;
    setLaunching(true);
    try {
      const body: LaunchInput = {
        network,
        productId,
        headline: form.headline,
        primaryText: form.primaryText,
        description: form.description || null,
        callToAction: form.cta,
        dailyBudget: budget,
        days: days === "0" ? null : Number(days),
        countries: countries.split(/[\s,]+/).map((c) => c.trim().toUpperCase()).filter(Boolean),
        ageMin: ages.min,
        ageMax: ages.max,
      };
      const ad = await api.post<AdView>("/api/ads", body);
      if (ad.status === "ERROR") toast(ad.lastError ?? "The ad couldn't be created.", "error");
      else toast(net?.simulated ? "Demo ad created: it goes live in about a minute" : "Ad sent for review. It usually goes live within a day.");
      onLaunched(ad);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setLaunching(false);
    }
  }

  const ready = !!productId && form.headline.trim() && form.primaryText.trim() && budget >= min && connected.some((n) => n.network === network);
  const domain = (store?.publicLink || store?.shopUrl || "").replace(/^https?:\/\//, "").split("/")[0] || "your-shop";

  return (
    <Drawer
      open={open}
      onClose={onClose}
      width="max-w-3xl"
      title="New ad"
      subtitle="Customers tap the ad and land on the product in your shop, ready to order."
      footer={
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-zinc-500">
            {net?.simulated ? "Demo network: nothing is charged." : `Up to ${money(budget, currency)} a day, charged by ${NETWORK_LABEL[network]}.`}
          </p>
          <Button onClick={launch} loading={launching} disabled={!ready} icon={<LuRocket />}>
            Launch ad
          </Button>
        </div>
      }
    >
      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        <div className="space-y-6">
          {connected.length > 1 && (
            <Segmented value={network} onChange={(v) => setNetwork(v)} options={connected.map((n) => ({ value: n.network, label: NETWORK_LABEL[n.network] }))} />
          )}

          <div>
            <p className="mb-2 text-sm font-semibold">1. Product</p>
            {products.loading ? (
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="aspect-square" />)}
              </div>
            ) : available.length ? (
              <div className="grid max-h-56 grid-cols-3 gap-2 overflow-y-auto pr-1 sm:grid-cols-4">
                {available.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setProductId(p.id);
                      setCopy(null);
                    }}
                    className={cn(
                      "group overflow-hidden rounded-xl border-2 text-left transition",
                      productId === p.id ? "border-violet-500 shadow-lg shadow-violet-500/20" : "border-transparent hover:border-zinc-200 dark:hover:border-white/10",
                    )}
                  >
                    <div className="aspect-square overflow-hidden rounded-lg">
                      <ProductImage src={p.imageUrl} name={p.name} category={p.category} />
                    </div>
                    <p className="truncate px-1 pt-1 text-xs font-semibold">{p.name}</p>
                    <p className="px-1 pb-1 text-[11px] text-zinc-500">{money(p.price, store?.currency)}</p>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-zinc-500">Add a product that's in stock first.</p>
            )}
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between gap-3">
              <p className="text-sm font-semibold">2. Ad text</p>
              <Button size="sm" variant="secondary" onClick={write} loading={writing} disabled={!productId} icon={<LuWandSparkles className="text-violet-500" />}>
                Write with AI
              </Button>
            </div>
            {copy && (
              <div className="mb-3 flex animate-fade-up flex-wrap items-center gap-2">
                {copy.variants.map((v, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => pick(copy, i)}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs font-semibold transition",
                      form.headline === v.headline ? "border-violet-500 bg-violet-50 text-violet-700 dark:bg-violet-500/15 dark:text-violet-200" : "border-zinc-200 dark:border-white/10",
                    )}
                  >
                    <LuSparkles className="mr-1 inline" />
                    {v.angle}
                  </button>
                ))}
                <EngineBadge engine={copy.engine} />
              </div>
            )}
            <div className="space-y-3">
              <Input label="Headline" maxLength={40} value={form.headline} onChange={(e) => setForm({ ...form, headline: e.target.value })} hint={`${form.headline.length}/40`} />
              <Textarea
                label="Main text"
                rows={3}
                maxLength={textLimit}
                value={form.primaryText}
                onChange={(e) => setForm({ ...form, primaryText: e.target.value })}
                hint={network === "tiktok" ? `${form.primaryText.length}/100 · one short line works best` : `${form.primaryText.length}/500 · under 125 characters works best`}
              />
              <div className="grid grid-cols-2 gap-3">
                <Input label="Short description" maxLength={60} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                <Select
                  label="Button"
                  value={form.cta}
                  onChange={(e) => setForm({ ...form, cta: e.target.value as CallToAction })}
                  options={(Object.keys(CTA_LABEL) as CallToAction[]).map((k) => ({ value: k, label: CTA_LABEL[k] }))}
                />
              </div>
              {copy?.tips.length ? (
                <ul className="space-y-1 rounded-xl bg-violet-50 p-3 text-xs text-violet-800 dark:bg-violet-500/10 dark:text-violet-200">
                  {copy.tips.map((t) => <li key={t}>💡 {t}</li>)}
                </ul>
              ) : null}
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold">3. Budget & audience</p>
            <div className="grid grid-cols-2 gap-3">
              <Input
                label="Per day"
                type="number"
                min={min}
                max={maxDailyBudget ?? undefined}
                step="0.5"
                leading={currency}
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                hint={`At least ${min} ${currency}`}
              />
              <Select
                label="Run for"
                value={days}
                onChange={(e) => setDays(e.target.value as typeof days)}
                options={[
                  { value: "0", label: "Until I stop it" },
                  { value: "7", label: "7 days" },
                  { value: "14", label: "14 days" },
                  { value: "30", label: "30 days" },
                ]}
              />
              <Input label="Countries" value={countries} onChange={(e) => setCountries(e.target.value)} hint="e.g. GH or GH, NG" />
              <div className="grid grid-cols-2 gap-2">
                <Input label="Age from" type="number" min={18} max={65} value={ages.min} onChange={(e) => setAges({ ...ages, min: Number(e.target.value) })} />
                <Input label="to" type="number" min={18} max={65} value={ages.max} onChange={(e) => setAges({ ...ages, max: Number(e.target.value) })} />
              </div>
            </div>
          </div>
        </div>

        <div className="lg:sticky lg:top-0 lg:self-start">
          <p className="mb-2 text-sm font-semibold">Preview</p>
          <AdPreview
            network={network}
            shopName={store?.name ?? "Your shop"}
            logoUrl={store?.logoUrl}
            accent={store?.accentColor}
            imageUrl={product?.imageUrl}
            productName={product?.name ?? "Your product"}
            category={product?.category}
            headline={form.headline}
            primaryText={form.primaryText}
            description={form.description}
            cta={form.cta}
            domain={domain}
          />
          <p className="mt-3 text-center text-[11px] text-zinc-400">Rough preview. The network decides the final layout for each placement.</p>
        </div>
      </div>
    </Drawer>
  );
}
