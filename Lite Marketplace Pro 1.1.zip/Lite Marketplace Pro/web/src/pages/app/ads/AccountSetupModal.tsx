import { useEffect, useState } from "react";
import { LuCircleCheck, LuInfo } from "react-icons/lu";
import { Modal } from "../../../components/Overlay";
import { Button, ErrorBox, Skeleton } from "../../../components/ui";
import { api, errorMessage } from "../../../lib/api";
import { cn } from "../../../lib/cn";
import { useToast } from "../../../lib/toast";
import type { AdNetworkId, AssetsView, NetworkView, OptionView } from "../../../lib/types";
import { NETWORK_LABEL } from "./adUi";

/** After sign-in: choose the ad account (and the Facebook Page or TikTok account the ads come from). */
export function AccountSetupModal({
  network,
  onClose,
  onSaved,
}: {
  network: AdNetworkId | null;
  onClose: () => void;
  onSaved: (v: NetworkView) => void;
}) {
  const toast = useToast();
  const [assets, setAssets] = useState<AssetsView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [account, setAccount] = useState<string>("");
  const [page, setPage] = useState<string>("");
  const [identity, setIdentity] = useState<string>("");
  const [saving, setSaving] = useState(false);

  async function load(adAccountId?: string) {
    if (!network) return;
    setError(null);
    try {
      const q = adAccountId ? `?adAccountId=${encodeURIComponent(adAccountId)}` : "";
      const a = await api.get<AssetsView>(`/api/ads/accounts/${network}/options${q}`);
      setAssets(a);
      setAccount((cur) => cur || a.adAccounts.find((x) => x.type === "ACTIVE")?.id || a.adAccounts[0]?.id || "");
      setPage((cur) => cur || a.pages[0]?.id || "");
      setIdentity(a.identities[0]?.id ?? "");
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  useEffect(() => {
    setAssets(null);
    setAccount("");
    setPage("");
    setIdentity("");
    if (network) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [network]);

  async function save() {
    if (!network) return;
    setSaving(true);
    try {
      const v = await api.put<NetworkView>(`/api/ads/accounts/${network}`, {
        adAccountId: account,
        pageId: network === "meta" ? page : null,
        identityId: network === "tiktok" ? identity || null : null,
      });
      toast(`${NETWORK_LABEL[network]} is ready for ads`);
      onSaved(v);
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setSaving(false);
    }
  }

  const ready = !!account && (network !== "meta" || !!page);

  return (
    <Modal
      open={!!network}
      onClose={onClose}
      title={network ? `Set up ${NETWORK_LABEL[network]}` : ""}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save} loading={saving} disabled={!ready}>
            Save
          </Button>
        </div>
      }
    >
      {error ? (
        <ErrorBox message={error} onRetry={() => load()} />
      ) : !assets ? (
        <div className="space-y-2">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-14" />)}
        </div>
      ) : (
        <div className="space-y-5">
          <Group title="Ad account" hint="Ads are paid from this account (its card or balance).">
            {assets.adAccounts.length ? (
              assets.adAccounts.map((o) => (
                <Choice
                  key={o.id}
                  option={o}
                  selected={account === o.id}
                  onClick={() => {
                    setAccount(o.id);
                    if (network === "tiktok") load(o.id);
                  }}
                  detail={`${o.currency ?? ""}${o.type === "INACTIVE" ? " · not active" : ""}${o.minDailyBudget ? ` · from ${o.minDailyBudget}/day` : ""}`}
                />
              ))
            ) : (
              <Empty text="No ad accounts found. Create one in Meta Ads Manager / TikTok Ads Manager, then reconnect." />
            )}
          </Group>

          {network === "meta" && (
            <Group title="Facebook Page" hint="Your ads show this Page's name and picture. Its linked Instagram account is used for Instagram.">
              {assets.pages.length ? (
                assets.pages.map((o) => (
                  <Choice key={o.id} option={o} selected={page === o.id} onClick={() => setPage(o.id)}
                          detail={o.linkedName ? `Instagram: @${o.linkedName}` : "No Instagram account linked: Facebook only"} />
                ))
              ) : (
                <Empty text="You need a Facebook Page to run ads. Create one for your shop, then reconnect." />
              )}
            </Group>
          )}

          {network === "tiktok" && (
            <Group title="TikTok account" hint="New TikTok ads must come from a real TikTok account linked to your ad account.">
              {assets.identities.length ? (
                assets.identities.map((o) => (
                  <Choice key={o.id} option={o} selected={identity === o.id} onClick={() => setIdentity(o.id)} detail="Linked TikTok account" />
                ))
              ) : (
                <Empty text="No TikTok account is linked to this ad account yet. Link it in TikTok Ads Manager (Assets > Identities), then reload." />
              )}
            </Group>
          )}
        </div>
      )}
    </Modal>
  );
}

function Group({ title, hint, children }: { title: string; hint: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-sm font-bold">{title}</p>
      <p className="mb-2 text-xs text-zinc-500">{hint}</p>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Choice({ option, selected, onClick, detail }: { option: OptionView; selected: boolean; onClick: () => void; detail?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl border-2 p-3 text-left text-sm transition",
        selected ? "border-brand-500 bg-brand-50/60 dark:bg-brand-500/10" : "border-zinc-200 hover:border-zinc-300 dark:border-white/10",
      )}
    >
      <span className={cn("flex size-5 shrink-0 items-center justify-center rounded-full border-2", selected ? "border-brand-500 bg-brand-500 text-white" : "border-zinc-300")}>
        {selected && <LuCircleCheck className="size-3" />}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-semibold">{option.name}</span>
        {detail && <span className="block truncate text-xs text-zinc-500">{detail}</span>}
      </span>
    </button>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <p className="flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">
      <LuInfo className="mt-0.5 shrink-0" /> {text}
    </p>
  );
}
