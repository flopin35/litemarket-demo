import { useEffect, useMemo, useState } from "react";
import { FaWhatsapp } from "react-icons/fa6";
import {
  LuBanknote,
  LuBot,
  LuCircleAlert,
  LuCirclePause,
  LuEye,
  LuFlaskConical,
  LuMegaphone,
  LuMousePointerClick,
  LuPlug,
  LuPlus,
  LuRefreshCw,
  LuRocket,
  LuSettings2,
  LuShoppingBag,
  LuSparkles,
  LuTrendingUp,
  LuUnplug,
  LuWallet,
} from "react-icons/lu";
import { BarChart } from "../../components/BarChart";
import { Kpi } from "../../components/Kpi";
import { Confirm } from "../../components/Overlay";
import { Badge, Button, Card, EmptyState, ErrorBox, PageHeader, Segmented, Skeleton } from "../../components/ui";
import { api, errorMessage } from "../../lib/api";
import { cn } from "../../lib/cn";
import { dayLabel, dayMonth, money, timeAgo } from "../../lib/format";
import { useLoad, usePageTitle } from "../../lib/hooks";
import { navigate, useLocation } from "../../lib/router";
import { useToast } from "../../lib/toast";
import type { AdNetworkId, AdsOverview, AdStats, AdView, AutopilotLogView, AutopilotRun, ConnectView, NetworkView } from "../../lib/types";
import { AccountSetupModal } from "./ads/AccountSetupModal";
import { AdCard } from "./ads/AdCard";
import { NETWORK_LABEL, NetworkChip } from "./ads/adUi";
import { AutopilotDrawer } from "./ads/AutopilotDrawer";
import { CreateAdDrawer } from "./ads/CreateAdDrawer";

type Range = "7" | "30";
type Metric = "revenue" | "spend" | "clicks";
type Filter = "all" | "running" | "paused" | "ended";

/**
 * The seller's Ads page: connect Facebook & Instagram / TikTok, let the AI autopilot run ads, see the numbers.
 * Everything here belongs to the signed-in seller; the platform admin never sees ads or ad results.
 */
export default function Ads() {
  usePageTitle("Ads");
  const toast = useToast();
  const { query } = useLocation();
  const overview = useLoad(() => api.get<AdsOverview>("/api/ads"));
  const [range, setRange] = useState<Range>("30");
  const [metric, setMetric] = useState<Metric>("revenue");
  const [filter, setFilter] = useState<Filter>("all");
  const [version, setVersion] = useState(0);
  const stats = useLoad(() => api.get<AdStats>(`/api/ads/stats?days=${range}`), [range, version]);
  const [creating, setCreating] = useState(false);
  const [setup, setSetup] = useState<AdNetworkId | null>(null);
  const [autopilotOpen, setAutopilotOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [disconnect, setDisconnect] = useState<NetworkView | null>(null);
  const data = overview.data;

  // Back from Facebook/TikTok sign-in.
  useEffect(() => {
    const connected = query.get("connected") as AdNetworkId | null;
    const err = query.get("adsError");
    if (connected) toast(`${NETWORK_LABEL[connected] ?? "Account"} connected`);
    if (err) {
      toast(err === "cancelled" ? "Connection cancelled." : err === "expired" ? "That sign-in link expired. Try again." : err, "error");
    }
    if (connected || err) navigate("/app/ads", { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Open the account picker when a network still needs setting up.
  useEffect(() => {
    const pending = data?.networks.find((n) => n.status === "NEEDS_SETUP");
    if (pending && !setup) setSetup(pending.network);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.networks.map((n) => n.status).join()]);

  function refresh() {
    overview.reload();
    setVersion((v) => v + 1);
  }

  function replaceAd(ad: AdView) {
    overview.setData((d) => (d ? { ...d, ads: d.ads.map((a) => (a.id === ad.id ? ad : a)) } : d));
    setVersion((v) => v + 1);
  }

  async function connect(network: AdNetworkId) {
    try {
      const r = await api.post<ConnectView>(`/api/ads/accounts/${network}/connect`);
      const url = new URL(r.url, window.location.origin);
      if (url.origin === window.location.origin) {
        // Demo network: connected straight away, no sign-in page.
        toast(`${NETWORK_LABEL[network]} connected`);
        refresh();
      } else {
        window.location.href = r.url;
      }
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  }

  async function doDisconnect() {
    if (!disconnect) return;
    try {
      await api.del(`/api/ads/accounts/${disconnect.network}`);
      toast(`${disconnect.label} disconnected`, "info");
      setDisconnect(null);
      refresh();
    } catch (e) {
      toast(errorMessage(e), "error");
    }
  }

  async function runAutopilot() {
    setRunning(true);
    try {
      const r = await api.post<AutopilotRun>("/api/ads/autopilot/run");
      toast(r.summary);
      refresh();
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setRunning(false);
    }
  }

  async function sync() {
    setSyncing(true);
    try {
      await api.post("/api/ads/sync");
      refresh();
      toast("Results updated");
    } catch (e) {
      toast(errorMessage(e), "error");
    } finally {
      setSyncing(false);
    }
  }

  const bars = useMemo(() => {
    const s = stats.data;
    if (!s) return [];
    return s.daily.map((d) => {
      const value = metric === "revenue" ? Number(d.revenue) : metric === "spend" ? Number(d.spend) : d.clicks;
      return {
        label: range === "7" ? dayLabel(d.date) : dayMonth(d.date),
        value,
        extra: `${money(d.spend, s.spendCurrency)} spent · ${d.clicks} clicks · ${d.orders} order${d.orders === 1 ? "" : "s"} · ${dayMonth(d.date)}`,
      };
    });
  }, [stats.data, metric, range]);

  if (overview.error) return <ErrorBox message={overview.error} onRetry={overview.reload} />;

  const shopCur = data?.shopCurrency ?? "GHS";
  const t = stats.data?.totals;
  const spendCur = stats.data?.spendCurrency ?? shopCur;
  const connected = data?.networks.filter((n) => n.status === "CONNECTED") ?? [];
  const drafts = data?.ads.filter((a) => a.status === "DRAFT") ?? [];
  const others = (data?.ads.filter((a) => a.status !== "DRAFT") ?? []).filter((a) =>
    filter === "all" ? true : filter === "running" ? ["ACTIVE", "IN_REVIEW", "LAUNCHING"].includes(a.status)
      : filter === "paused" ? a.status === "PAUSED" : ["ENDED", "REJECTED", "ERROR"].includes(a.status));
  const simulated = data?.networks.some((n) => n.simulated) ?? false;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Ads"
        subtitle="Facebook, Instagram and TikTok ads that send customers straight to your products."
        actions={
          <>
            <Button variant="secondary" onClick={sync} loading={syncing} icon={<LuRefreshCw />} disabled={!data?.ads.length}>
              Update results
            </Button>
            <Button onClick={() => setCreating(true)} icon={<LuPlus />} disabled={!connected.length}>
              New ad
            </Button>
          </>
        }
      />

      {simulated && (
        <div className="flex animate-fade-up items-center gap-2 rounded-2xl border border-amber-300/70 bg-amber-50 px-4 py-2.5 text-sm text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
          <LuFlaskConical className="shrink-0" />
          Demo ad network: ads and results are simulated and no money is spent. Add your Meta / TikTok app keys to run real ads.
        </div>
      )}

      {data ? (
        <AutopilotHero data={data} running={running} onRun={runAutopilot} onOpen={() => setAutopilotOpen(true)} />
      ) : (
        <Skeleton className="h-40 rounded-3xl" />
      )}

      {/* Numbers */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-6">
        <Kpi loading={stats.loading} icon={<LuWallet />} tone="amber" label="Spent" value={t?.spend ?? 0} money={spendCur} sub={`last ${range} days`} />
        <Kpi loading={stats.loading} icon={<LuEye />} tone="sky" label="Views" value={t?.impressions ?? 0} sub={t ? `${t.activeAds} ad${t.activeAds === 1 ? "" : "s"} running` : ""} delay={50} />
        <Kpi loading={stats.loading} icon={<LuMousePointerClick />} tone="violet" label="Clicks" value={t?.clicks ?? 0} sub={t?.ctr != null ? `${t.ctr.toFixed(2)}% click rate` : "-"} delay={100} />
        <Kpi loading={stats.loading} icon={<FaWhatsapp />} tone="green" label="WhatsApp chats" value={t?.whatsappClicks ?? 0} sub={t ? `${t.visits.toLocaleString()} shop visits` : ""} delay={150} />
        <Kpi loading={stats.loading} icon={<LuShoppingBag />} tone="sky" label="Orders" value={t?.orders ?? 0} sub={t?.cpc != null ? `${money(t.cpc, spendCur)} per click` : ""} delay={200} />
        <Kpi loading={stats.loading} icon={<LuBanknote />} tone="green" label="Sales from ads" value={t?.revenue ?? 0} money={shopCur} sub={t?.roas != null ? `${t.roas.toFixed(1)}x what you spent` : "return shows after sales"} delay={250} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="animate-fade-up p-5 [animation-delay:150ms] sm:p-6 lg:col-span-2">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-bold">Results by day</h2>
              <p className="text-sm text-zinc-500">Only you can see your ad numbers.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Segmented value={metric} onChange={setMetric} options={[{ value: "revenue", label: "Sales" }, { value: "spend", label: "Spend" }, { value: "clicks", label: "Clicks" }]} />
              <Segmented value={range} onChange={setRange} options={[{ value: "7", label: "7d" }, { value: "30", label: "30d" }]} />
            </div>
          </div>
          {stats.loading ? (
            <Skeleton className="h-[220px] w-full" />
          ) : (
            <BarChart
              key={`${range}-${metric}`}
              data={bars}
              format={(v) => (metric === "revenue" ? money(v, shopCur) : metric === "spend" ? money(v, spendCur) : Math.round(v).toLocaleString())}
            />
          )}
        </Card>

        <div className="space-y-4">
          {(data?.networks ?? []).map((n, i) => (
            <NetworkCard
              key={n.network}
              n={n}
              delay={200 + i * 60}
              byNetwork={stats.data?.byNetwork.find((b) => b.network === n.network)}
              onConnect={() => connect(n.network)}
              onSetup={() => setSetup(n.network)}
              onDisconnect={() => setDisconnect(n)}
            />
          ))}
          {!data && <Skeleton className="h-36" />}
        </div>
      </div>

      {drafts.length > 0 && (
        <div className="space-y-3">
          <h2 className="flex items-center gap-2 font-bold">
            <LuSparkles className="text-violet-500" /> Suggested by the autopilot
            <Badge tone="violet">{drafts.length}</Badge>
          </h2>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {drafts.map((a, i) => (
              <AdCard key={a.id} ad={a} shopCurrency={shopCur} delay={i * 60} onChange={replaceAd}
                      onRemove={(id) => overview.setData((d) => (d ? { ...d, ads: d.ads.filter((x) => x.id !== id) } : d))} />
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-bold">Your ads</h2>
          <Segmented
            value={filter}
            onChange={setFilter}
            options={[{ value: "all", label: "All" }, { value: "running", label: "Running" }, { value: "paused", label: "Paused" }, { value: "ended", label: "Ended" }]}
          />
        </div>
        {overview.loading ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {[0, 1, 2].map((i) => <Skeleton key={i} className="h-56" />)}
          </div>
        ) : others.length ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {others.map((a, i) => (
              <AdCard key={a.id} ad={a} shopCurrency={shopCur} delay={i * 50} onChange={replaceAd}
                      onRemove={(id) => overview.setData((d) => (d ? { ...d, ads: d.ads.filter((x) => x.id !== id) } : d))} />
            ))}
          </div>
        ) : (
          <Card>
            <EmptyState
              icon={<LuMegaphone />}
              title={filter === "all" ? "No ads yet" : "Nothing here"}
              text={connected.length ? "Create an ad for a product, or turn on the autopilot and let the AI do it." : "Connect Facebook & Instagram or TikTok above to start."}
              action={connected.length ? <Button onClick={() => setCreating(true)} icon={<LuPlus />}>New ad</Button> : undefined}
            />
          </Card>
        )}
      </div>

      {data && data.activity.length > 0 && <Activity items={data.activity} />}

      {data && (
        <>
          <CreateAdDrawer
            open={creating}
            onClose={() => setCreating(false)}
            networks={data.networks}
            maxDailyBudget={data.maxDailyBudget}
            onLaunched={() => {
              setCreating(false);
              refresh();
            }}
          />
          <AutopilotDrawer
            open={autopilotOpen}
            onClose={() => setAutopilotOpen(false)}
            settings={data.settings}
            networks={data.networks}
            shopCurrency={shopCur}
            onSaved={(s) => {
              overview.setData((d) => (d ? { ...d, settings: s } : d));
              setAutopilotOpen(false);
            }}
          />
        </>
      )}
      <AccountSetupModal
        network={setup}
        onClose={() => setSetup(null)}
        onSaved={() => {
          setSetup(null);
          refresh();
        }}
      />
      <Confirm
        open={!!disconnect}
        onClose={() => setDisconnect(null)}
        onConfirm={doDisconnect}
        title={`Disconnect ${disconnect?.label ?? ""}?`}
        text="Running ads keep running at the network until you stop them there, but you won't see their results here."
        confirmLabel="Disconnect"
      />
    </div>
  );
}

function AutopilotHero({ data, running, onRun, onOpen }: { data: AdsOverview; running: boolean; onRun: () => void; onOpen: () => void }) {
  const s = data.settings;
  const on = s.autopilotEnabled;
  const connected = data.networks.some((n) => n.status === "CONNECTED");
  return (
    <div className="relative animate-scale-in overflow-hidden rounded-3xl bg-gradient-to-br from-violet-600 via-violet-700 to-indigo-900 p-6 text-white shadow-xl shadow-violet-900/20 sm:p-8">
      <div className="pointer-events-none absolute -top-20 -right-16 size-64 animate-blob rounded-full bg-fuchsia-400/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-10 size-56 animate-blob rounded-full bg-sky-400/20 blur-3xl [animation-delay:2s]" />
      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-start gap-4">
          <div className="relative">
            {on && <span className="absolute inset-0 animate-ping-slow rounded-2xl bg-white/30" />}
            <span className="relative flex size-14 items-center justify-center rounded-2xl bg-white/15 text-3xl backdrop-blur">
              <LuBot />
            </span>
          </div>
          <div>
            <p className="flex items-center gap-2 text-sm font-semibold text-violet-200">
              AI autopilot
              <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-bold", on ? "bg-emerald-400 text-emerald-950" : "bg-white/20 text-white")}>
                {on ? "ON" : "OFF"}
              </span>
            </p>
            <h2 className="mt-1 text-xl font-extrabold sm:text-2xl">
              {on ? "Your ads are on autopilot" : "Let the AI run your ads"}
            </h2>
            <p className="mt-1 max-w-xl text-sm text-violet-100">
              {on
                ? `Up to ${s.maxActiveAds} ads, ${money(s.dailyBudgetCap, data.networks.find((n) => n.status === "CONNECTED")?.currency ?? data.shopCurrency)} a day at most. ${s.autoLaunch ? "It launches new ads by itself." : "New ads wait for your approval."}`
                : "It picks your best-selling products, writes the ads, keeps the winners running and pauses the ones that don't sell. You set the daily limit."}
            </p>
            {s.lastRunAt && (
              <p className="mt-2 text-xs text-violet-200">
                Last check {timeAgo(s.lastRunAt)}: {s.lastRunSummary}
              </p>
            )}
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          {on && (
            <Button variant="dark" className="bg-white! text-violet-800!" onClick={onRun} loading={running} icon={<LuRocket />}>
              Run now
            </Button>
          )}
          <Button
            variant="secondary"
            className="border-white/30! bg-white/10! text-white! hover:bg-white/20!"
            onClick={onOpen}
            disabled={!connected && !on}
            icon={on ? <LuSettings2 /> : <LuSparkles />}
          >
            {on ? "Settings" : connected ? "Turn on autopilot" : "Connect an account first"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function NetworkCard({
  n,
  delay,
  byNetwork,
  onConnect,
  onSetup,
  onDisconnect,
}: {
  n: NetworkView;
  delay: number;
  byNetwork?: { spend: number; clicks: number; orders: number; currency: string | null };
  onConnect: () => void;
  onSetup: () => void;
  onDisconnect: () => void;
}) {
  const expiresSoon = n.tokenExpiresAt && new Date(n.tokenExpiresAt).getTime() - Date.now() < 7 * 86_400_000;
  return (
    <Card className="animate-fade-up p-5" >
      <div style={{ animationDelay: `${delay}ms` }}>
        <div className="flex items-center justify-between gap-2">
          <NetworkChip network={n.network} />
          {n.status === "CONNECTED" ? (
            <Badge tone="green">Connected</Badge>
          ) : n.status === "RECONNECT" ? (
            <Badge tone="rose">Reconnect</Badge>
          ) : n.status === "NEEDS_SETUP" ? (
            <Badge tone="amber">Finish setup</Badge>
          ) : (
            <Badge>Not connected</Badge>
          )}
        </div>
        {n.status === "DISCONNECTED" ? (
          <>
            <p className="mt-3 text-sm text-zinc-500">
              {n.network === "meta"
                ? "Show your products in Facebook and Instagram feeds, Stories and Reels."
                : "Reach shoppers on TikTok with swipeable photo ads of your products."}
            </p>
            <Button className="mt-4 w-full" variant="secondary" onClick={onConnect} icon={<LuPlug />}>
              Connect {n.label}
            </Button>
          </>
        ) : (
          <>
            <div className="mt-3 space-y-1 text-sm">
              <p className="truncate font-semibold">{n.accountName ?? "Choose an ad account"}</p>
              <p className="truncate text-xs text-zinc-500">
                {n.network === "meta"
                  ? [n.pageName, n.instagramUsername ? `@${n.instagramUsername}` : null].filter(Boolean).join(" · ") || "No Page chosen"
                  : n.identityName ?? "No TikTok account chosen"}
                {n.currency ? ` · ${n.currency}` : ""}
              </p>
            </div>
            {byNetwork && (
              <p className="mt-3 rounded-xl bg-zinc-50 px-3 py-2 text-xs text-zinc-600 dark:bg-white/5 dark:text-zinc-300">
                {money(byNetwork.spend, byNetwork.currency ?? n.currency ?? undefined)} spent · {byNetwork.clicks.toLocaleString()} clicks · {byNetwork.orders} orders
              </p>
            )}
            {(n.status === "RECONNECT" || expiresSoon) && (
              <p className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">
                <LuCircleAlert className="mt-0.5 shrink-0" />
                {n.status === "RECONNECT" ? "The connection stopped working. Reconnect to keep managing your ads." : "Facebook connections last about 60 days. Reconnect soon to keep things running."}
              </p>
            )}
            <div className="mt-4 flex flex-wrap gap-2">
              {n.status === "RECONNECT" || expiresSoon ? (
                <Button size="sm" onClick={onConnect} icon={<LuPlug />}>
                  Reconnect
                </Button>
              ) : (
                <Button size="sm" variant="secondary" onClick={onSetup}>
                  {n.status === "NEEDS_SETUP" ? "Finish setup" : "Change"}
                </Button>
              )}
              <Button size="sm" variant="ghost" onClick={onDisconnect} icon={<LuUnplug />}>
                Disconnect
              </Button>
            </div>
          </>
        )}
      </div>
    </Card>
  );
}

const ACTION_STYLE: Record<AutopilotLogView["action"], { icon: React.ReactNode; tone: string }> = {
  LAUNCHED: { icon: <LuRocket />, tone: "bg-brand-50 text-brand-600 dark:bg-brand-500/15" },
  SUGGESTED: { icon: <LuSparkles />, tone: "bg-violet-50 text-violet-600 dark:bg-violet-500/15" },
  PAUSED: { icon: <LuCirclePause />, tone: "bg-zinc-100 text-zinc-600 dark:bg-white/10" },
  BUDGET_UP: { icon: <LuTrendingUp />, tone: "bg-amber-50 text-amber-600 dark:bg-amber-500/15" },
  KEPT: { icon: <LuBot />, tone: "bg-zinc-100 text-zinc-600 dark:bg-white/10" },
  SKIPPED: { icon: <LuCircleAlert />, tone: "bg-sky-50 text-sky-600 dark:bg-sky-500/15" },
  ERROR: { icon: <LuCircleAlert />, tone: "bg-rose-50 text-rose-600 dark:bg-rose-500/15" },
  INFO: { icon: <LuBot />, tone: "bg-zinc-100 text-zinc-600 dark:bg-white/10" },
};

function Activity({ items }: { items: AutopilotLogView[] }) {
  return (
    <Card className="animate-fade-up p-5 sm:p-6">
      <h2 className="mb-4 flex items-center gap-2 font-bold">
        <LuBot className="text-violet-500" /> What the autopilot did
      </h2>
      <ol className="relative space-y-4 border-l border-zinc-200 pl-6 dark:border-white/10">
        {items.slice(0, 12).map((l, i) => {
          const st = ACTION_STYLE[l.action] ?? ACTION_STYLE.INFO;
          return (
            <li key={l.id} className="relative animate-fade-up" style={{ animationDelay: `${i * 40}ms` }}>
              <span className={cn("absolute top-0 -left-[37px] flex size-7 items-center justify-center rounded-full text-sm ring-4 ring-white dark:ring-zinc-900", st.tone)}>
                {st.icon}
              </span>
              <p className="text-sm">{l.message}</p>
              <p className="mt-0.5 text-xs text-zinc-400">{timeAgo(l.createdAt)}</p>
            </li>
          );
        })}
      </ol>
    </Card>
  );
}
