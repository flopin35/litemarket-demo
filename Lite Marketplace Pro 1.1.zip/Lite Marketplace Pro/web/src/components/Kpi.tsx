import type { ReactNode } from "react";
import { cn } from "../lib/cn";
import { money } from "../lib/format";
import { CountUp } from "./motion";
import { Card, Skeleton } from "./ui";

export type KpiTone = "green" | "amber" | "sky" | "violet" | "rose";

const TONES: Record<KpiTone, string> = {
  green: "from-brand-50 to-brand-100 text-brand-700 dark:from-brand-500/20 dark:to-brand-500/5 dark:text-brand-300",
  amber: "from-amber-50 to-amber-100 text-amber-700 dark:from-amber-500/20 dark:to-amber-500/5 dark:text-amber-300",
  sky: "from-sky-50 to-sky-100 text-sky-700 dark:from-sky-500/20 dark:to-sky-500/5 dark:text-sky-300",
  violet: "from-violet-50 to-violet-100 text-violet-700 dark:from-violet-500/20 dark:to-violet-500/5 dark:text-violet-300",
  rose: "from-rose-50 to-rose-100 text-rose-700 dark:from-rose-500/20 dark:to-rose-500/5 dark:text-rose-300",
};

/** A number tile with an icon that counts up when it appears. */
export function Kpi(props: {
  loading?: boolean;
  icon: ReactNode;
  tone: KpiTone;
  label: string;
  value: number;
  money?: string;
  format?: (v: number) => string;
  sub?: string;
  delay?: number;
}) {
  const fmt = props.format ?? ((v: number) => (props.money ? money(v, props.money) : Math.round(v).toLocaleString()));
  return (
    <div className="animate-fade-up" style={{ animationDelay: `${props.delay ?? 0}ms` }}>
      <Card className="group h-full p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg sm:p-5">
        <span className={cn("flex size-10 items-center justify-center rounded-xl bg-gradient-to-br text-lg transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6", TONES[props.tone])}>
          {props.icon}
        </span>
        <p className="mt-4 text-xs font-semibold text-zinc-500 sm:text-sm dark:text-zinc-400">{props.label}</p>
        {props.loading ? (
          <Skeleton className="mt-2 h-7 w-24" />
        ) : (
          <p className="mt-1 text-lg font-extrabold tracking-tight sm:text-2xl">
            <CountUp value={Number(props.value)} format={fmt} />
          </p>
        )}
        {props.sub !== undefined && <p className="mt-1 truncate text-xs text-zinc-400">{props.sub}</p>}
      </Card>
    </div>
  );
}
