import { api } from "./api";

/**
 * Ad attribution for the public shop.
 *
 * Ads link to `/s/{shop}?p={productId}&ref=ad{id}`. We remember the ref for 7 days (per shop),
 * report one "visit" per browser session, report "whatsapp" when an order is sent on WhatsApp,
 * and attach the ref to orders so sellers see which ads bring sales.
 */
const DAYS = 7;
const REF = /^ad\d{1,15}$/;
const key = (slug: string) => `lm-ref:${slug}`;

export function rememberRef(slug: string, ref: string | null) {
  if (!ref || !REF.test(ref)) return;
  try {
    localStorage.setItem(key(slug), JSON.stringify({ ref, at: Date.now() }));
  } catch {
    /* private mode: attribution just won't stick */
  }
  const seen = `lm-ref-seen:${slug}:${ref}`;
  try {
    if (sessionStorage.getItem(seen)) return;
    sessionStorage.setItem(seen, "1");
  } catch {
    /* ignore */
  }
  track(slug, ref, "visit");
}

export function currentRef(slug: string): string | null {
  try {
    const raw = localStorage.getItem(key(slug));
    if (!raw) return null;
    const { ref, at } = JSON.parse(raw) as { ref: string; at: number };
    if (!REF.test(ref) || Date.now() - at > DAYS * 86_400_000) {
      localStorage.removeItem(key(slug));
      return null;
    }
    return ref;
  } catch {
    return null;
  }
}

export function track(slug: string, ref: string | null, event: "visit" | "whatsapp") {
  if (!ref) return;
  api.post(`/api/shops/${encodeURIComponent(slug)}/track`, { ref, event }).catch(() => undefined);
}
