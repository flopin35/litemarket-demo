/**
 * Demo mode: a tiny copy of the Java API that runs in the browser and saves to localStorage.
 * It answers the same URLs with the same JSON, so every page works without a server.
 * Turned on with VITE_DEMO_MODE=true (see .env.example). Not used in production builds.
 *
 * Money model: a commission on every sale (no plans). Ads use a simulated network, like the
 * backend with ADS_DEMO_MODE=true: nothing is published and nothing is charged.
 */
import type {
  AccountView,
  AdminOverview,
  AdminPayment,
  AdNetworkId,
  AdsOverview,
  AdSettingsView,
  AdStats,
  AdStatus,
  AdView,
  AssetsView,
  AutopilotLogView,
  CallToAction,
  CommissionEntry,
  CommissionKind,
  CommissionStatus,
  Dashboard,
  Earnings,
  MeView,
  NetworkView,
  Order,
  OrderStatus,
  PaymentStatus,
  PaymentView,
  PayoutRow,
  Product,
  PublicConfig,
  SellerRow,
  Shop,
  StoreView,
} from "../types";
import * as ai from "./demoAi";

// ── Settings (same defaults as backend/src/main/resources/application.yml) ────

const PERCENT = 5;
const ON_WHATSAPP = true;
const DUE_LIMIT = 200;
const AI_CREDITS = 300;
const PRODUCT_LIMIT: number | null = null;
const MAX_DAILY_BUDGET = 100;
const DAY = 86_400_000;
const PROVIDERS = [{ id: "demo", label: "Demo payment (test mode)" }];
const NETWORKS: { id: AdNetworkId; label: string }[] = [
  { id: "meta", label: "Facebook & Instagram" },
  { id: "tiktok", label: "TikTok" },
];

// ── Data ──────────────────────────────────────────────────────────────────────

interface DUser { id: number; email: string; password: string; fullName: string | null; role: "SELLER" | "ADMIN"; status: "ACTIVE" | "SUSPENDED"; createdAt: string }
interface DStore {
  id: number; ownerId: number; name: string; slug: string; whatsapp: string; currency: string; about: string | null; accentColor: string | null; logoUrl: string | null;
  onlinePayments: boolean; whatsappOrders: boolean; publicLink: string | null; aiUsed: number; aiPeriod: string | null;
  paystackSubaccount: string | null; flutterwaveSubaccount: string | null; stripeAccount: string | null; createdAt: string;
}
interface DProduct extends Omit<Product, "available"> { storeId: number }
interface DOrder extends Omit<Order, "fromAd"> { storeId: number; stockDeducted: boolean; adId: number | null }
interface DPayment {
  reference: string; purpose: "ORDER" | "COMMISSION"; provider: string; status: "PENDING" | "SUCCESS" | "FAILED"; amount: number; currency: string; storeId: number;
  orderId: number | null; paid: boolean; payerEmail: string | null; note: string | null; settlement: string; platformFee: number | null; sellerAmount: number | null; createdAt: string; paidAt: string | null;
}
interface DCommission {
  id: number; storeId: number; orderId: number | null; orderNumber: string | null; orderTotal: number; percent: number; amount: number; currency: string;
  kind: CommissionKind; status: CommissionStatus; reference: string | null; createdAt: string; settledAt: string | null;
}
interface DAccount {
  storeId: number; network: AdNetworkId; state: "NEEDS_SETUP" | "CONNECTED" | "RECONNECT"; accountId: string | null; accountName: string | null; currency: string | null;
  pageName: string | null; instagram: string | null; identityName: string | null; tokenExpiresAt: string | null; connectedAt: string;
}
/** A stretch of time an ad was running at one daily budget (results are simulated from these). */
interface DSpan { from: number; until: number | null; budget: number }
interface DAd {
  id: number; storeId: number; network: AdNetworkId; productId: number; productName: string; imageUrl: string | null; status: AdStatus; origin: "SELLER" | "AUTOPILOT";
  headline: string; primaryText: string; description: string | null; callToAction: CallToAction; dailyBudget: number; currency: string; countries: string[]; ageMin: number; ageMax: number;
  endDate: string | null; lastError: string | null; aiReason: string | null; createdAt: string; launchedAt: string | null; lastSyncedAt: string | null; pausedAt: string | null;
  pausedByAutopilot: boolean; endedAt: string | null; ctr: number; spans: DSpan[]; tracked: Record<string, [number, number]>;
}
interface DSettings {
  storeId: number; autopilotEnabled: boolean; autoLaunch: boolean; networks: AdNetworkId[]; dailyBudgetCap: number; perAdBudget: number; maxActiveAds: number; countries: string[];
  ageMin: number; ageMax: number; minCtr: number; maxCpc: number | null; fxRate: number | null; termsAcceptedAt: string | null; lastRunAt: string | null; lastRunSummary: string | null;
}
interface DLog { id: number; storeId: number; action: AutopilotLogView["action"]; message: string; adId: number | null; createdAt: string }
interface DB {
  seq: number; users: DUser[]; stores: DStore[]; products: DProduct[]; orders: DOrder[]; payments: DPayment[]; commission: DCommission[];
  accounts: DAccount[]; ads: DAd[]; settings: DSettings[]; logs: DLog[];
}

const KEY = "lm-demo-db-v2";
const SESSION = "lm-demo-session";

class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

const empty = (): DB => ({ seq: 0, users: [], stores: [], products: [], orders: [], payments: [], commission: [], accounts: [], ads: [], settings: [], logs: [] });
// Loaded on every request (see mockFetch) so several tabs stay in sync.
let db: DB = empty();

function load(): DB {
  try {
    localStorage.removeItem("lm-demo-db"); // the old plans-era demo
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as DB;
  } catch {
    /* fall through */
  }
  const fresh = seed();
  persist(fresh);
  return fresh;
}

function persist(d: DB = db) {
  try {
    localStorage.setItem(KEY, JSON.stringify(d));
  } catch {
    /* storage full: keep working in memory */
  }
}

const iso = (msAgo = 0) => new Date(Date.now() - msAgo).toISOString();
const code = (n: number) => Array.from({ length: n }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random() * 32)]).join("");
const round = (v: number) => Math.round(v * 100) / 100;
const fee = (total: number) => round((total * PERCENT) / 100);
const isSale = (s: OrderStatus) => s === "PAID" || s === "DELIVERED";
const dateOf = (ms: number) => new Date(ms).toISOString().slice(0, 10);

function seed(): DB {
  const d: DB = { ...empty(), seq: 100 };
  const id = () => ++d.seq;
  const mkUser = (email: string, password: string, fullName: string, role: DUser["role"]) => {
    const u: DUser = { id: id(), email, password, fullName, role, status: "ACTIVE", createdAt: iso(40 * DAY) };
    d.users.push(u);
    return u;
  };
  const mkStore = (owner: DUser, name: string, slug: string, whatsapp: string, about: string, accent: string) => {
    const s: DStore = {
      id: id(), ownerId: owner.id, name, slug, whatsapp, currency: "GHS", about, accentColor: accent, logoUrl: null, onlinePayments: true, whatsappOrders: true, publicLink: null,
      aiUsed: 3, aiPeriod: new Date().toISOString().slice(0, 7), paystackSubaccount: null, flutterwaveSubaccount: null, stripeAccount: null, createdAt: iso(38 * DAY),
    };
    d.stores.push(s);
    return s;
  };
  const mkProduct = (s: DStore, name: string, price: number, category: string, description: string, featured = false, stockQty: number | null = null) => {
    const p: DProduct = { id: id(), storeId: s.id, name, price, category, description, imageUrl: null, inStock: true, stockQty, featured, createdAt: iso(30 * DAY) };
    d.products.push(p);
    return p;
  };

  const admin = mkUser("admin@litemarket.dev", "admin12345", "Platform Admin", "ADMIN");
  mkStore(admin, "Lite Marketplace HQ", "hq", "233200000000", "The admin's own shop.", "#0F9D7A");
  const ama = mkUser("demo@litemarket.dev", "demo12345", "Ama Mensah", "SELLER");
  const shop = mkStore(ama, "Ama's Kitchen", "amas-kitchen", "233241234567", "Home-cooked Ghanaian meals and drinks, delivered hot around Accra. Order on WhatsApp or pay with MoMo.", "#E8590C");
  const menu = [
    mkProduct(shop, "Jollof Rice & Grilled Chicken", 45, "Food", "Smoky party jollof with a quarter grilled chicken, fried plantain and fresh salad.", true),
    mkProduct(shop, "Waakye Special", 35, "Food", "Waakye with gari, spaghetti, egg, wele, fish and our house shito.", true),
    mkProduct(shop, "Banku & Grilled Tilapia", 60, "Food", "Two balls of banku with a whole grilled tilapia, pepper and onions.", false, 8),
    mkProduct(shop, "Fried Rice & Shito", 40, "Food", "Vegetable fried rice with chicken and a side of hot black shito."),
    mkProduct(shop, "Kelewele (Spicy Plantain)", 15, "Snacks", "Ripe plantain cubes fried with ginger and pepper."),
    mkProduct(shop, "Meat Pie (2 pieces)", 10, "Snacks", "Buttery, flaky pastry filled with minced beef. Baked fresh every morning.", false, 3),
    mkProduct(shop, "Sobolo (500ml)", 12, "Drinks", "Chilled hibiscus drink with ginger, pineapple and cloves."),
    mkProduct(shop, "Fresh Pineapple Juice (500ml)", 15, "Drinks", "100% pressed pineapple, no added sugar.", false, 0),
  ];
  const kofi = mkUser("kofi@kicks.example", "demo12345", "Kofi Asante", "SELLER");
  const kicks = mkStore(kofi, "Kofi Kicks", "kofi-kicks", "233201112233", "Clean sneakers, fair prices. Delivery in Kumasi and Accra.", "#2563EB");
  mkProduct(kicks, "Classic White Sneakers", 350, "Shoes", "Leather upper, cushioned sole. Sizes 39-45.", true);
  mkProduct(kicks, "Street Runner Trainers", 420, "Shoes", "Breathable mesh, made for long days.");
  const efua = mkUser("efua@glow.example", "demo12345", "Efua Owusu", "SELLER");
  const glow = mkStore(efua, "Glow by Efua", "glow-by-efua", "233559998877", "Handmade shea butter and natural skincare.", "#DB2777");
  mkProduct(glow, "Whipped Shea Body Butter", 80, "Beauty", "Raw shea, coconut oil and vanilla. 250ml jar.", true);

  const customers = ["Kofi Boateng", "Efua Owusu", "Yaw Asante", "Akosua Darko", "Kwame Mensah", "Abena Osei", "Kojo Mensah", "Adwoa Sarpong"];
  const places = ["East Legon, near A&C Mall", "Osu, Oxford Street", "Madina Zongo Junction", "Spintex, Coca-Cola roundabout", "Achimota Mall", "Dansoman Last Stop"];
  let r = 7;
  const rand = (n: number) => ((r = (r * 9301 + 49297) % 233280), Math.floor((r / 233280) * n));
  for (let i = 0; i < 26; i++) {
    const created = iso((6 + i * 11 + rand(5)) * 3_600_000);
    const lines = 1 + rand(3);
    const items = Array.from({ length: lines }, () => {
      const p = menu[rand(6)]!;
      const q = 1 + rand(3);
      return { productId: p.id, name: p.name, unitPrice: p.price, quantity: q, lineTotal: p.price * q };
    });
    const status: OrderStatus = i < 3 ? "NEW" : i === 7 ? "CANCELLED" : i % 4 === 0 ? "PAID" : "DELIVERED";
    const channel = i % 3 === 0 ? "ONLINE" : "WHATSAPP";
    const paidAt = isSale(status) ? new Date(new Date(created).getTime() + 20 * 60_000).toISOString() : null;
    const o: DOrder = {
      id: id(), storeId: shop.id, number: `LM-DEMO${10 + i}`, customerName: customers[rand(customers.length)]!, customerPhone: `23324${1000000 + rand(8999999)}`, customerEmail: null,
      address: places[rand(places.length)]!, note: null, channel, status, total: items.reduce((n, x) => n + x.lineTotal, 0), currency: "GHS",
      paymentProvider: channel === "ONLINE" && isSale(status) ? "paystack" : null, itemsSummary: items.map((x) => `${x.quantity} x ${x.name}`).join(", "), items,
      createdAt: created, paidAt, stockDeducted: true, adId: null,
    };
    d.orders.push(o);
    // Commission: online ones were taken automatically, WhatsApp ones older than a week were paid.
    if (paidAt) {
      const online = o.paymentProvider !== null;
      const old = Date.now() - new Date(paidAt).getTime() > 7 * DAY;
      d.commission.push({
        id: id(), storeId: shop.id, orderId: o.id, orderNumber: o.number, orderTotal: o.total, percent: PERCENT, amount: fee(o.total), currency: "GHS",
        kind: online ? "ONLINE" : "WHATSAPP", status: online || old ? "SETTLED" : "DUE", reference: online ? "SEED-ONLINE" : old ? "SEED-PAID" : null, createdAt: paidAt,
        settledAt: online ? paidAt : old ? new Date(new Date(paidAt).getTime() + 3 * DAY).toISOString() : null,
      });
    }
  }
  seedAds(d, shop, menu);
  return d;
}

/** Same as backend AdsDemoSeeder: a demo Facebook & Instagram account, four ads and some autopilot history. */
function seedAds(d: DB, s: DStore, menu: DProduct[]) {
  const now = Date.now();
  d.accounts.push({
    storeId: s.id, network: "meta", state: "CONNECTED", accountId: "sim-1001", accountName: "Ama's Kitchen ads (demo)", currency: s.currency, pageName: "Ama's Kitchen",
    instagram: "amaskitchen.gh", identityName: null, tokenExpiresAt: iso(-52 * DAY), connectedAt: iso(16 * DAY),
  });
  d.settings.push({
    storeId: s.id, autopilotEnabled: true, autoLaunch: false, networks: ["meta"], dailyBudgetCap: 120, perAdBudget: 40, maxActiveAds: 3, countries: ["GH"], ageMin: 18, ageMax: 45,
    minCtr: 0.8, maxCpc: null, fxRate: null, termsAcceptedAt: iso(16 * DAY), lastRunAt: iso(2 * 3_600_000), lastRunSummary: "1 suggested.",
  });
  const by = (part: string) => menu.find((p) => p.name.includes(part)) ?? menu[0]!;
  const mk = (p: DProduct, origin: DAd["origin"], status: AdStatus, headline: string, text: string, description: string, budget: number, ctr: number, spans: DSpan[], reason: string | null) => {
    const launched = spans[0]?.from ?? null;
    const ad: DAd = {
      id: ++d.seq, storeId: s.id, network: "meta", productId: p.id, productName: p.name, imageUrl: p.imageUrl, status, origin, headline, primaryText: text, description,
      callToAction: "ORDER_NOW", dailyBudget: budget, currency: s.currency, countries: ["GH"], ageMin: 18, ageMax: 45, endDate: null, lastError: null, aiReason: reason,
      createdAt: new Date(launched ? launched - 5 * 60_000 : now - 2 * 3_600_000).toISOString(), launchedAt: launched ? new Date(launched).toISOString() : null, lastSyncedAt: null,
      pausedAt: null, pausedByAutopilot: false, endedAt: null, ctr, spans, tracked: {},
    };
    d.ads.push(ad);
    return ad;
  };
  const j = mk(by("Jollof"), "AUTOPILOT", "ACTIVE", "Smoky party jollof, delivered hot",
    "Craving real party jollof? 🔥 Smoky rice, grilled chicken, fried plantain and fresh salad, delivered hot around Accra. Order in 2 taps on WhatsApp or pay with MoMo.",
    "GHS 45 · Delivered hot", 48, 0.021, [{ from: now - 12 * DAY, until: now - 2 * DAY, budget: 40 }, { from: now - 2 * DAY, until: null, budget: 48 }],
    "Your best seller this month with 2 orders a day on average, and it has a photo customers love.");
  const w = mk(by("Waakye"), "SELLER", "ACTIVE", "Waakye Special for lunch",
    "Waakye with gari, spaghetti, egg, wele, fish and our house shito. Order before 12 and lunch arrives hot. 🍛", "Order on WhatsApp", 30, 0.016,
    [{ from: now - 8 * DAY, until: null, budget: 30 }], null);
  const k = mk(by("Kelewele"), "AUTOPILOT", "PAUSED", "Spicy kelewele, the perfect snack",
    "Ripe plantain cubes fried with ginger and pepper. Add peanuts for the full experience!", "GHS 15 snack", 25, 0.0045,
    [{ from: now - 15 * DAY, until: now - 4 * DAY, budget: 25 }], "Snacks sell well in the evening and this one is cheap to try.");
  k.pausedAt = iso(4 * DAY);
  k.pausedByAutopilot = true;
  const sob = mk(by("Sobolo"), "AUTOPILOT", "DRAFT", "Ice-cold sobolo for the heat",
    "Chilled hibiscus sobolo with ginger and pineapple. Add a bottle to any meal for GHS 12! 🧊", "Add one to your order", 25, 0.018, [],
    "Drinks are the easiest add-on: customers who order food often add one.");

  // Customers who came through the ads ordered (link a few demo orders to them).
  const tag = (ad: DAd, productId: number, count: number) => {
    let tagged = 0;
    for (const o of [...d.orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt))) {
      if (tagged >= count) break;
      if (o.adId !== null || !isSale(o.status) || (ad.launchedAt && o.createdAt < ad.launchedAt)) continue;
      const has = o.items.some((i) => i.productId === productId);
      if (!has && tagged >= count / 2) continue;
      o.adId = ad.id;
      tagged++;
    }
  };
  tag(j, j.productId, 5);
  tag(w, w.productId, 3);

  const log = (adId: number | null, action: DLog["action"], message: string, msAgo: number) =>
    d.logs.push({ id: ++d.seq, storeId: s.id, action, message, adId, createdAt: iso(msAgo) });
  log(j.id, "LAUNCHED", `Launched "${j.headline}" for ${j.productName} at 40.00 GHS/day. ${j.aiReason}`, 12 * DAY);
  log(k.id, "PAUSED", `Paused "${k.headline}": few people who saw it clicked, so the budget went to better ads.`, 4 * DAY);
  log(j.id, "BUDGET_UP", `"${j.headline}" is a winner. It brought 5 orders. Daily budget raised to 48.00 GHS.`, 2 * DAY);
  log(sob.id, "SUGGESTED", `Suggested an ad for ${sob.productName}. Approve it below to launch. ${sob.aiReason}`, 2 * 3_600_000);
}

// ── Views (same shapes as the Java DTOs) ──────────────────────────────────────

const month = () => new Date().toISOString().slice(0, 7);
const aiUsed = (s: DStore) => (s.aiPeriod === month() ? s.aiUsed : 0);
const shopUrl = (s: DStore) => `${window.location.origin}/s/${s.slug}`;
const available = (p: DProduct) => p.inStock && (p.stockQty === null || p.stockQty > 0);
const due = (s: DStore) => round(db.commission.filter((c) => c.storeId === s.id && c.status === "DUE").reduce((n, c) => n + c.amount, 0));
const whatsappPaused = (s: DStore) => ON_WHATSAPP && DUE_LIMIT > 0 && due(s) >= DUE_LIMIT;

function storeView(s: DStore): StoreView {
  return { id: s.id, name: s.name, slug: s.slug, whatsapp: s.whatsapp, currency: s.currency, about: s.about, accentColor: s.accentColor, logoUrl: s.logoUrl, onlinePayments: s.onlinePayments, whatsappOrders: s.whatsappOrders, publicLink: s.publicLink, shopUrl: shopUrl(s) };
}

function accountView(s: DStore): AccountView {
  return {
    commissionPercent: PERCENT, currency: s.currency, commissionDue: Math.max(0, due(s)), dueLimit: DUE_LIMIT, whatsappPaused: whatsappPaused(s),
    aiCreditsUsed: aiUsed(s), aiCreditsLimit: AI_CREDITS, productLimit: PRODUCT_LIMIT,
  };
}

function meView(u: DUser): MeView {
  const s = db.stores.find((x) => x.ownerId === u.id);
  return { id: u.id, email: u.email, fullName: u.fullName, role: u.role, store: s ? storeView(s) : null, account: s ? accountView(s) : null };
}

const productView = (p: DProduct): Product => {
  const { storeId: _s, ...rest } = p;
  void _s;
  return { ...rest, available: available(p) };
};
const orderView = (o: DOrder): Order => {
  const { storeId: _s, stockDeducted: _d, adId, ...rest } = o;
  void _s;
  void _d;
  return { ...rest, fromAd: adId !== null };
};
const paymentView = (p: DPayment): PaymentView => ({
  reference: p.reference, purpose: p.purpose, provider: p.provider, status: p.status, amount: p.amount, currency: p.currency, note: p.note, createdAt: p.createdAt, paidAt: p.paidAt,
});
const entryView = (c: DCommission): CommissionEntry => ({
  id: c.id, orderNumber: c.orderNumber, orderTotal: c.orderTotal, percent: c.percent, amount: c.amount, currency: c.currency, kind: c.kind, status: c.status, createdAt: c.createdAt, settledAt: c.settledAt,
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function json(status: number, body: unknown): Response {
  if (status === 204) return new Response(null, { status });
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}

function auth(token: string | null): DUser {
  const id = Number(token?.startsWith("demo.") ? token.slice(5) : NaN);
  const u = db.users.find((x) => x.id === id);
  if (!u) throw new HttpError(401, "UNAUTHORIZED", "Please log in.");
  return u;
}
const storeOf = (u: DUser) => {
  const s = db.stores.find((x) => x.ownerId === u.id);
  if (!s) throw new HttpError(404, "NOT_FOUND", "You don't have a store yet.");
  return s;
};
const session = (u: DUser) => {
  localStorage.setItem(SESSION, String(u.id));
  return { accessToken: `demo.${u.id}`, expiresIn: 900, me: meView(u) };
};
const cleanPhone = (raw: string) => {
  const d = raw.replace(/\D/g, "");
  return d.startsWith("0") ? "233" + d.slice(1) : d.startsWith("00") ? d.slice(2) : d;
};
const slugify = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/['’]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "my-shop";
const wa = (phone: string, text: string) => `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
const fmt = (v: number, c: string) => `${c} ${v.toFixed(2)}`;
const bad = (message: string) => new HttpError(400, "BAD_REQUEST", message);

function takeCredit(s: DStore) {
  if (s.aiPeriod !== month()) (s.aiPeriod = month()), (s.aiUsed = 0);
  if (s.aiUsed >= AI_CREDITS) throw new HttpError(402, "AI_CREDITS", `You've used all ${AI_CREDITS} AI credits this month. They refill on the 1st.`);
  s.aiUsed++;
}

/** Commission bookkeeping when an order changes status (CommissionService.onOrderStatus). */
function onOrderStatus(o: DOrder, previous: OrderStatus | null, next: OrderStatus) {
  const s = db.stores.find((x) => x.id === o.storeId)!;
  const mine = db.commission.filter((c) => c.orderId === o.id && (c.kind === "WHATSAPP" || c.kind === "ADJUSTMENT"));
  if (isSale(next) && (previous === null || !isSale(previous))) {
    if (o.paymentProvider || !ON_WHATSAPP) return;
    const charged = mine.filter((c) => c.status === "DUE" || c.status === "SETTLED").reduce((n, c) => n + c.amount, 0);
    if (charged > 0 || fee(o.total) <= 0) return;
    db.commission.push({ id: ++db.seq, storeId: s.id, orderId: o.id, orderNumber: o.number, orderTotal: o.total, percent: PERCENT, amount: fee(o.total), currency: o.currency, kind: "WHATSAPP", status: "DUE", reference: null, createdAt: iso(), settledAt: null });
  } else if (next === "CANCELLED") {
    let settled = 0;
    mine.forEach((c) => {
      if (c.status === "DUE") (c.status = "REVERSED"), (c.settledAt = iso());
      else if (c.status === "SETTLED") settled += c.amount;
    });
    if (settled > 0) {
      db.commission.push({ id: ++db.seq, storeId: s.id, orderId: o.id, orderNumber: o.number, orderTotal: o.total, percent: PERCENT, amount: -round(settled), currency: o.currency, kind: "ADJUSTMENT", status: "DUE", reference: null, createdAt: iso(), settledAt: null });
    }
  }
}

function changeStatus(o: DOrder, next: OrderStatus) {
  if (next === o.status) return;
  const previous = o.status;
  if (isSale(next)) {
    o.paidAt ??= iso();
    if (!o.stockDeducted) adjustStock(o, -1), (o.stockDeducted = true);
  } else if (next === "CANCELLED" && o.stockDeducted) adjustStock(o, 1), (o.stockDeducted = false);
  o.status = next;
  onOrderStatus(o, previous, next);
}
function adjustStock(o: DOrder, dir: number) {
  o.items.forEach((i) => {
    const p = db.products.find((x) => x.id === i.productId);
    if (p && p.stockQty !== null) p.stockQty = Math.max(0, p.stockQty + dir * i.quantity);
  });
}

function adIdFromRef(s: DStore, ref: unknown): number | null {
  const m = typeof ref === "string" ? /^ad(\d{1,15})$/.exec(ref) : null;
  if (!m) return null;
  const id = Number(m[1]);
  return db.ads.some((a) => a.id === id && a.storeId === s.id) ? id : null;
}

function cartOrder(s: DStore, body: any, channel: "WHATSAPP" | "ONLINE", status: OrderStatus): DOrder {
  const items = (body.items ?? []).map((l: { productId: number; quantity: number }) => {
    const p = db.products.find((x) => x.id === l.productId && x.storeId === s.id);
    if (!p) throw bad("One of the products is no longer in this shop. Refresh the page.");
    if (!available(p)) throw bad(`${p.name} is sold out.`);
    return { productId: p.id, name: p.name, unitPrice: p.price, quantity: l.quantity, lineTotal: p.price * l.quantity };
  });
  if (!items.length) throw new HttpError(400, "VALIDATION", "Your cart is empty.");
  const c = body.customer ?? {};
  if (!c.name || !c.phone || !c.address) throw new HttpError(400, "VALIDATION", "Please fill in your name, phone and address.");
  const o: DOrder = {
    id: ++db.seq, storeId: s.id, number: `LM-${code(6)}`, customerName: c.name, customerPhone: cleanPhone(c.phone), customerEmail: c.email ?? null, address: c.address, note: c.note ?? null,
    channel, status, total: round(items.reduce((n: number, i: { lineTotal: number }) => n + i.lineTotal, 0)), currency: s.currency, paymentProvider: null,
    itemsSummary: items.map((i: { quantity: number; name: string }) => `${i.quantity} x ${i.name}`).join(", "), items, createdAt: iso(), paidAt: null, stockDeducted: false,
    adId: adIdFromRef(s, body.ref),
  };
  db.orders.push(o);
  return o;
}

function paymentStatus(p: DPayment): PaymentStatus {
  const s = db.stores.find((x) => x.id === p.storeId)!;
  const o = p.orderId ? db.orders.find((x) => x.id === p.orderId) : undefined;
  return {
    reference: p.reference, status: p.status, purpose: p.purpose, provider: p.provider, amount: p.amount, currency: p.currency, orderNumber: o?.number ?? null, storeName: s.name, storeSlug: s.slug,
    whatsappUrl: o && p.status === "SUCCESS" ? wa(s.whatsapp, `Hello ${s.name}! I just paid ${fmt(p.amount, p.currency)} for order ${o.number}. Payment reference: ${p.reference}.`) : null,
    message: p.status === "SUCCESS" ? (p.purpose === "COMMISSION" ? "Commission paid. Thank you!" : "Payment received. Thank you!") : p.status === "PENDING" ? "We're waiting for the payment to be confirmed." : p.note ?? "The payment didn't go through.",
  };
}

/** Settles the oldest due entries a payment covers (CommissionMath.coveredCount). */
function settle(storeId: number, paid: number, reference: string) {
  const list = db.commission.filter((c) => c.storeId === storeId && c.status === "DUE").sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  let running = 0;
  let covered = 0;
  list.forEach((c, i) => {
    running += c.amount;
    if (running <= paid + 0.005) covered = i + 1;
  });
  list.slice(0, covered).forEach((c) => ((c.status = "SETTLED"), (c.settledAt = iso()), (c.reference = reference)));
}

function fulfill(p: DPayment) {
  if (p.status === "SUCCESS") return;
  p.status = "SUCCESS";
  p.paidAt = iso();
  if (p.purpose === "COMMISSION") return settle(p.storeId, p.amount, p.reference);
  const o = p.orderId ? db.orders.find((x) => x.id === p.orderId) : undefined;
  if (!o) return;
  o.paymentProvider = p.provider;
  changeStatus(o, "PAID");
  if ((p.platformFee ?? 0) > 0 && !db.commission.some((c) => c.orderId === o.id && c.kind === "ONLINE")) {
    db.commission.push({ id: ++db.seq, storeId: o.storeId, orderId: o.id, orderNumber: o.number, orderTotal: o.total, percent: PERCENT, amount: p.platformFee!, currency: o.currency, kind: "ONLINE", status: "SETTLED", reference: p.reference, createdAt: iso(), settledAt: iso() });
  }
}

async function shrinkImage(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = dataUrl;
    });
    const scale = Math.min(1, 900 / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * scale);
    c.height = Math.round(img.height * scale);
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.82);
  } catch {
    return dataUrl;
  }
}

// ── Ads: simulated network ────────────────────────────────────────────────────

const STRONG = new Set(["USD", "EUR", "GBP", "CAD", "AUD", "CHF"]);
const label = (n: AdNetworkId) => NETWORKS.find((x) => x.id === n)!.label;
const running = (st: AdStatus) => st === "LAUNCHING" || st === "IN_REVIEW" || st === "ACTIVE";

function rng(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

interface SimDay { date: string; impressions: number; clicks: number; spend: number; visits: number; whatsapp: number }

/** Day-by-day results for one ad, like SimulatedAdsNetwork.simulate: most of the budget spent, a click rate that depends on the ad. */
function simulate(ad: DAd, now = Date.now()): SimDay[] {
  const perUnit = STRONG.has(ad.currency) ? 650 : 48;
  const days = new Map<string, SimDay>();
  for (const sp of ad.spans) {
    const end = Math.min(sp.until ?? now, now);
    for (let t = Math.floor(sp.from / DAY) * DAY; t < end; t += DAY) {
      const from = Math.max(sp.from, t);
      const until = Math.min(end, t + DAY);
      if (until <= from) continue;
      const share = (until - from) / DAY;
      const r = rng(ad.id * 7919 + Math.floor(t / DAY));
      const spend = sp.budget * share * (0.82 + r() * 0.17);
      const impressions = Math.round(spend * perUnit * (0.85 + r() * 0.3));
      const clicks = Math.round(impressions * ad.ctr * (0.8 + r() * 0.4));
      const visits = Math.round(clicks * (0.7 + r() * 0.2));
      const whatsapp = Math.round(visits * (0.08 + r() * 0.1));
      const date = dateOf(t);
      const d = days.get(date) ?? { date, impressions: 0, clicks: 0, spend: 0, visits: 0, whatsapp: 0 };
      d.impressions += impressions;
      d.clicks += clicks;
      d.spend = round(d.spend + spend);
      d.visits += visits;
      d.whatsapp += whatsapp;
      days.set(date, d);
    }
  }
  for (const [date, [v, w]] of Object.entries(ad.tracked)) {
    const d = days.get(date) ?? { date, impressions: 0, clicks: 0, spend: 0, visits: 0, whatsapp: 0 };
    d.visits += v;
    d.whatsapp += w;
    days.set(date, d);
  }
  return [...days.values()];
}

/** Moves ads out of review after a minute and ends ads past their end date (AdsSync for the demo network). */
function syncAds(s: DStore) {
  const now = Date.now();
  db.ads.filter((a) => a.storeId === s.id).forEach((a) => {
    if (a.status === "IN_REVIEW" && a.launchedAt && now - new Date(a.launchedAt).getTime() >= 60_000) a.status = "ACTIVE";
    if (a.endDate && (a.status === "ACTIVE" || a.status === "IN_REVIEW" || a.status === "PAUSED") && dateOf(now) > a.endDate) endAd(a);
    if (a.launchedAt) a.lastSyncedAt = iso();
  });
}

function closeSpan(a: DAd) {
  const open = a.spans.find((x) => x.until === null);
  if (open) open.until = Date.now();
}
function openSpan(a: DAd) {
  closeSpan(a);
  a.spans.push({ from: Date.now(), until: null, budget: a.dailyBudget });
}
function endAd(a: DAd) {
  closeSpan(a);
  a.status = "ENDED";
  a.endedAt = iso();
}

function adOrders(a: DAd) {
  const list = db.orders.filter((o) => o.adId === a.id && isSale(o.status));
  return { count: list.length, revenue: round(list.reduce((n, o) => n + o.total, 0)) };
}

function adView(a: DAd): AdView {
  const days = simulate(a);
  const impressions = days.reduce((n, d) => n + d.impressions, 0);
  const clicks = days.reduce((n, d) => n + d.clicks, 0);
  const spend = round(days.reduce((n, d) => n + d.spend, 0));
  const o = adOrders(a);
  return {
    id: a.id, network: a.network, productId: a.productId, productName: a.productName, imageUrl: a.imageUrl, status: a.status, origin: a.origin, headline: a.headline,
    primaryText: a.primaryText, description: a.description, callToAction: a.callToAction, dailyBudget: a.dailyBudget, currency: a.currency, countries: a.countries,
    ageMin: a.ageMin, ageMax: a.ageMax, endDate: a.endDate, reviewNote: null, lastError: a.lastError, aiReason: a.aiReason, impressions, clicks, spend,
    visits: days.reduce((n, d) => n + d.visits, 0), whatsappClicks: days.reduce((n, d) => n + d.whatsapp, 0), orders: o.count, revenue: o.revenue,
    ctr: impressions ? round((clicks * 100) / impressions) : null, cpc: clicks ? round(spend / clicks) : null, createdAt: a.createdAt, launchedAt: a.launchedAt, lastSyncedAt: a.lastSyncedAt,
  };
}

function settingsOf(s: DStore): DSettings {
  let x = db.settings.find((z) => z.storeId === s.id);
  if (!x) {
    x = { storeId: s.id, autopilotEnabled: false, autoLaunch: true, networks: ["meta"], dailyBudgetCap: 10, perAdBudget: 5, maxActiveAds: 3, countries: ["GH"], ageMin: 18, ageMax: 55, minCtr: 0.8, maxCpc: null, fxRate: null, termsAcceptedAt: null, lastRunAt: null, lastRunSummary: null };
    db.settings.push(x);
  }
  return x;
}
const settingsView = (x: DSettings): AdSettingsView => ({
  autopilotEnabled: x.autopilotEnabled, autoLaunch: x.autoLaunch, networks: x.networks, dailyBudgetCap: x.dailyBudgetCap, perAdBudget: x.perAdBudget, maxActiveAds: x.maxActiveAds,
  countries: x.countries, ageMin: x.ageMin, ageMax: x.ageMax, minCtr: x.minCtr, maxCpc: x.maxCpc, fxRate: x.fxRate, termsAccepted: !!x.termsAcceptedAt, lastRunAt: x.lastRunAt, lastRunSummary: x.lastRunSummary,
});
const logView = (l: DLog): AutopilotLogView => ({ id: l.id, action: l.action, message: l.message, adId: l.adId, createdAt: l.createdAt });

function networkViews(s: DStore): NetworkView[] {
  return NETWORKS.map(({ id, label: name }) => {
    const a = db.accounts.find((x) => x.storeId === s.id && x.network === id);
    if (!a) return { network: id, label: name, simulated: true, status: "DISCONNECTED", accountName: null, currency: null, minDailyBudget: null, pageName: null, instagramUsername: null, identityName: null, tokenExpiresAt: null };
    return { network: id, label: name, simulated: true, status: a.state, accountName: a.accountName, currency: a.currency, minDailyBudget: 1, pageName: a.pageName, instagramUsername: a.instagram, identityName: a.identityName, tokenExpiresAt: a.tokenExpiresAt };
  });
}

function assets(s: DStore, network: AdNetworkId): AssetsView {
  const account = { id: "sim-1001", name: "Demo ad account", currency: s.currency, minDailyBudget: 1, linkedId: null, linkedName: null, type: "ACTIVE" };
  if (network === "meta") {
    return { adAccounts: [account], pages: [{ id: "sim-page-1", name: `${s.name} (demo Page)`, currency: null, minDailyBudget: null, linkedId: "sim-ig-1", linkedName: `${slugify(s.name).replace(/-/g, "")}.demo`, type: "PAGE" }], identities: [] };
  }
  return { adAccounts: [account], pages: [], identities: [{ id: "sim-tt-1", name: `@${slugify(s.name).replace(/-/g, "")} (demo)`, currency: null, minDailyBudget: null, linkedId: "sim-1001", linkedName: null, type: "TT_USER" }] };
}

function readyAccount(s: DStore, network: AdNetworkId) {
  const a = db.accounts.find((x) => x.storeId === s.id && x.network === network);
  if (!a) throw bad(`Connect ${label(network)} first.`);
  if (a.state === "RECONNECT") throw bad(`Your ${label(network)} connection expired. Reconnect it first.`);
  if (a.state !== "CONNECTED") throw bad(`Finish setting up ${label(network)}: choose your ad account.`);
  return a;
}
function checkBudget(a: DAccount, budget: number) {
  if (!(budget >= 1)) throw bad(`${label(a.network)} needs at least 1 ${a.currency} a day.`);
  if (budget > MAX_DAILY_BUDGET) throw bad(`The most an ad can spend per day here is ${MAX_DAILY_BUDGET} ${a.currency}.`);
}
const cut = (v: unknown, n: number) => (v == null ? null : String(v).trim().slice(0, n).trim());
const cleanCountries = (c: unknown) => {
  const list = Array.isArray(c) ? [...new Set(c.map((x) => String(x).trim().toUpperCase()).filter(Boolean))] : [];
  return list.length ? list : ["GH"];
};

function prepare(s: DStore, network: AdNetworkId, productId: number, f: { headline: string; primaryText: string; description: string | null; callToAction: CallToAction | null; dailyBudget: number; days: number | null; countries: string[]; ageMin: number; ageMax: number }, origin: DAd["origin"], reason: string | null): DAd {
  const a = readyAccount(s, network);
  const p = db.products.find((x) => x.id === productId && x.storeId === s.id);
  if (!p) throw new HttpError(404, "NOT_FOUND", "Product not found.");
  if (!available(p)) throw bad(`${p.name} is sold out. Advertise something in stock.`);
  const budget = round(Number(f.dailyBudget));
  checkBudget(a, budget);
  const lo = Math.max(18, Number(f.ageMin) || 18);
  const hi = Math.max(lo, Number(f.ageMax) || 55);
  const ad: DAd = {
    id: ++db.seq, storeId: s.id, network, productId: p.id, productName: p.name, imageUrl: p.imageUrl, status: "DRAFT", origin, headline: cut(f.headline, 40) ?? "", primaryText: cut(f.primaryText, 500) ?? "",
    description: cut(f.description, 60), callToAction: f.callToAction ?? "SHOP_NOW", dailyBudget: budget, currency: a.currency ?? s.currency, countries: cleanCountries(f.countries), ageMin: lo, ageMax: hi,
    endDate: f.days ? dateOf(Date.now() + (f.days - 1) * DAY) : null, lastError: null, aiReason: reason, createdAt: iso(), launchedAt: null, lastSyncedAt: null, pausedAt: null, pausedByAutopilot: false,
    endedAt: null, ctr: 0.005 + rng(Date.now() + p.id)() * 0.025, spans: [], tracked: {},
  };
  db.ads.push(ad);
  return ad;
}
function launch(a: DAd) {
  a.status = "IN_REVIEW";
  a.lastError = null;
  a.launchedAt = iso();
  openSpan(a);
}

function ownAd(s: DStore, id: string) {
  const a = db.ads.find((x) => x.id === Number(id) && x.storeId === s.id);
  if (!a) throw new HttpError(404, "NOT_FOUND", "Ad not found.");
  return a;
}

function productSignals(s: DStore): ai.AdProduct[] {
  const since30 = Date.now() - 30 * DAY;
  const since7 = Date.now() - 7 * DAY;
  const u30 = new Map<number, number>();
  const u7 = new Map<number, number>();
  db.orders.filter((o) => o.storeId === s.id && isSale(o.status) && new Date(o.createdAt).getTime() > since30).forEach((o) => {
    const when = new Date(o.paidAt ?? o.createdAt).getTime();
    o.items.forEach((i) => {
      if (!i.productId) return;
      u30.set(i.productId, (u30.get(i.productId) ?? 0) + i.quantity);
      if (when > since7) u7.set(i.productId, (u7.get(i.productId) ?? 0) + i.quantity);
    });
  });
  const ads = db.ads.filter((a) => a.storeId === s.id).map((a) => ({ a, v: adView(a) }));
  return db.products.filter((p) => p.storeId === s.id).map((p) => {
    const past = ads.filter((x) => x.a.productId === p.id && x.v.impressions > 0);
    return {
      id: p.id, name: p.name, price: p.price, category: p.category, description: p.description, available: available(p), featured: p.featured, stockQty: p.stockQty, imageUrl: p.imageUrl,
      units7: u7.get(p.id) ?? 0, units30: u30.get(p.id) ?? 0, pastAds: past.length, bestCtr: past.reduce((m, x) => Math.max(m, x.v.ctr ?? 0), 0),
    };
  });
}

/** One autopilot pass (AutopilotService.run): judge its running ads, then fill free slots with AI-written ads. */
function runAutopilot(s: DStore) {
  const x = settingsOf(s);
  syncAds(s);
  const made: DLog[] = [];
  const note = (ad: DAd | null, action: DLog["action"], message: string) => {
    const l: DLog = { id: ++db.seq, storeId: s.id, action, message, adId: ad?.id ?? null, createdAt: iso() };
    db.logs.push(l);
    made.push(l);
  };
  let paused = 0, raised = 0, launched = 0, suggested = 0;
  const mine = () => db.ads.filter((a) => a.storeId === s.id);
  const runningBudget = () => mine().filter((a) => a.origin === "AUTOPILOT" && running(a.status)).reduce((n, a) => n + a.dailyBudget, 0);
  const maxBudget = Math.min(MAX_DAILY_BUDGET, x.dailyBudgetCap);

  // 1) Judge running autopilot ads (AutopilotRules.judge).
  for (const a of mine()) {
    if (a.origin !== "AUTOPILOT" || a.status !== "ACTIVE") continue;
    const v = adView(a);
    const ctr = v.impressions ? (v.clicks * 100) / v.impressions : 0;
    const daysRunning = a.launchedAt ? Math.floor((Date.now() - new Date(a.launchedAt).getTime()) / DAY) : 0;
    const cpc = v.clicks ? v.spend / v.clicks : 0;
    let pause: string | null = null;
    if (v.impressions >= 1500 && ctr < x.minCtr) pause = `Only ${ctr.toFixed(2)}% of the ${v.impressions} people who saw it clicked (your target is ${x.minCtr.toFixed(2)}%).`;
    else if (x.maxCpc && v.clicks >= 20 && cpc > x.maxCpc) pause = `Each click cost ${cpc.toFixed(2)} ${a.currency}, above your limit of ${x.maxCpc.toFixed(2)}.`;
    else if (v.orders === 0 && v.spend >= a.dailyBudget * 4) pause = `Spent ${v.spend.toFixed(2)} ${a.currency} (4 days of budget) without an order.`;
    if (pause) {
      closeSpan(a);
      a.status = "PAUSED";
      a.pausedAt = iso();
      a.pausedByAutopilot = true;
      note(a, "PAUSED", `Paused "${a.headline}": ${pause}`);
      paused++;
      continue;
    }
    const revenue = a.currency === s.currency ? v.revenue : x.fxRate ? v.revenue / x.fxRate : null;
    const roas = revenue !== null && v.spend > 0 ? revenue / v.spend : null;
    const winner = v.orders >= 2 && daysRunning >= 2 && (roas !== null ? roas >= 2 : ctr >= Math.max(1, x.minCtr * 2));
    if (winner) {
      const next = round(Math.min(a.dailyBudget * 1.2, maxBudget));
      if (next > a.dailyBudget && runningBudget() + (next - a.dailyBudget) <= x.dailyBudgetCap) {
        a.dailyBudget = next;
        openSpan(a);
        const why = roas !== null ? `It brought ${v.orders} orders, ${roas.toFixed(1)}x what it cost.` : `It brought ${v.orders} orders and ${ctr.toFixed(2)}% of viewers clicked.`;
        note(a, "BUDGET_UP", `"${a.headline}" is a winner. ${why} Daily budget raised to ${next.toFixed(2)} ${a.currency}.`);
        raised++;
      }
    }
  }

  // 2) Fill free slots.
  const networks = x.networks.filter((n) => {
    try {
      readyAccount(s, n);
      return true;
    } catch {
      return false;
    }
  });
  const busy = mine().filter((a) => a.origin === "AUTOPILOT" && (running(a.status) || a.status === "DRAFT")).length;
  const slots = Math.max(0, x.maxActiveAds - busy);
  if (!networks.length) {
    note(null, "SKIPPED", "Connect Facebook & Instagram or TikTok on this page so the autopilot can run ads.");
  } else if (slots > 0) {
    const cooldown = Date.now() - 14 * DAY;
    const taken = new Set(mine().filter((a) => running(a.status) || a.status === "DRAFT" || (a.pausedByAutopilot && a.pausedAt && new Date(a.pausedAt).getTime() > cooldown)).map((a) => a.productId));
    const candidates = productSignals(s).filter((p) => p.available && !taken.has(p.id));
    const budgetFor = () => {
      const b = round(Math.min(x.perAdBudget, x.dailyBudgetCap - runningBudget()));
      return b >= 1 ? b : null;
    };
    if (budgetFor() === null) note(null, "SKIPPED", "Your daily ad limit is already in use, so no new ads were started.");
    else if (!candidates.length) note(null, "SKIPPED", "No products to advertise: keep products in stock.");
    else {
      takeCredit(s);
      const store = { name: s.name, currency: s.currency, whatsappOrders: s.whatsappOrders, onlinePayments: s.onlinePayments };
      for (const pick of ai.autopilotPicks(store, candidates, taken, slots, networks)) {
        const b = budgetFor();
        if (b === null) {
          note(null, "SKIPPED", "The daily limit left isn't enough for another ad.");
          break;
        }
        const v = pick.variant;
        const ad = prepare(s, pick.network, pick.productId, { headline: v.headline, primaryText: v.primary_text, description: v.description, callToAction: v.call_to_action, dailyBudget: b, days: null, countries: x.countries, ageMin: x.ageMin, ageMax: x.ageMax }, "AUTOPILOT", pick.reason);
        if (x.autoLaunch) {
          launch(ad);
          note(ad, "LAUNCHED", `Launched "${ad.headline}" for ${ad.productName} at ${b.toFixed(2)} ${ad.currency}/day. ${pick.reason}`);
          launched++;
        } else {
          note(ad, "SUGGESTED", `Suggested an ad for ${ad.productName}. Approve it below to launch. ${pick.reason}`);
          suggested++;
        }
      }
    }
  }
  const parts = ([[paused, "paused"], [raised, "budget raised"], [launched, "launched"], [suggested, "suggested"]] as [number, string][]).filter(([n]) => n > 0).map(([n, w]) => `${n} ${w}`);
  const summary = parts.length ? parts.join(", ") + "." : "Checked your ads: nothing needed changing.";
  x.lastRunAt = iso();
  x.lastRunSummary = summary;
  return { summary, actions: made.map(logView) };
}

/** Runs the autopilot for every shop that turned it on, at most every 6 hours (like ADS_AUTOPILOT_CRON). */
function autopilotTick() {
  db.settings.filter((x) => x.autopilotEnabled && (!x.lastRunAt || Date.now() - new Date(x.lastRunAt).getTime() > 6 * 3_600_000)).forEach((x) => {
    const s = db.stores.find((z) => z.id === x.storeId);
    if (!s) return;
    try {
      runAutopilot(s);
    } catch {
      /* e.g. out of AI credits: try again next time */
    }
  });
}

// ── Router ────────────────────────────────────────────────────────────────────

type Handler = (ctx: { body: any; token: string | null; params: string[]; query: URLSearchParams; form?: FormData }) => unknown | Promise<unknown>;
const routes: [string, RegExp, Handler][] = [];
const on = (method: string, pattern: string, h: Handler) => routes.push([method, new RegExp("^" + pattern.replace(/:[a-zA-Z]+/g, "([^/]+)") + "$"), h]);

on("GET", "/api/config", (): PublicConfig => ({
  brandName: "Lite Marketplace", supportEmail: "support@example.com", currency: "GHS", commissionPercent: PERCENT, commissionOnWhatsappOrders: ON_WHATSAPP, aiMonthlyCredits: AI_CREDITS,
  productLimit: PRODUCT_LIMIT, providers: PROVIDERS, demoPayments: true, ads: { meta: false, tiktok: false, demo: true },
}));
on("GET", "/api/health", () => ({ status: "ok" }));

on("POST", "/api/auth/signup", ({ body }) => {
  const email = String(body.email ?? "").trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, "VALIDATION", "email must be a well-formed email address");
  if (String(body.password ?? "").length < 8) throw new HttpError(400, "VALIDATION", "password must be at least 8 characters");
  if (!String(body.storeName ?? "").trim()) throw new HttpError(400, "VALIDATION", "storeName must not be blank");
  if (db.users.some((u) => u.email === email)) throw new HttpError(409, "CONFLICT", "There is already an account with that email. Log in instead.");
  const u: DUser = { id: ++db.seq, email, password: body.password, fullName: body.fullName ?? null, role: "SELLER", status: "ACTIVE", createdAt: iso() };
  db.users.push(u);
  let slug = slugify(body.storeName);
  for (let n = 2; db.stores.some((s) => s.slug === slug); n++) slug = `${slugify(body.storeName)}-${n}`;
  db.stores.push({
    id: ++db.seq, ownerId: u.id, name: body.storeName.trim(), slug, whatsapp: cleanPhone(body.whatsapp ?? ""), currency: "GHS", about: "Order on WhatsApp or pay online. We reply fast!", accentColor: "#0F9D7A",
    logoUrl: null, onlinePayments: true, whatsappOrders: true, publicLink: null, aiUsed: 0, aiPeriod: null, paystackSubaccount: null, flutterwaveSubaccount: null, stripeAccount: null, createdAt: iso(),
  });
  return session(u);
});
on("POST", "/api/auth/login", ({ body }) => {
  const u = db.users.find((x) => x.email === String(body.email ?? "").trim().toLowerCase());
  if (!u || u.password !== body.password) throw new HttpError(401, "UNAUTHORIZED", "That email and password don't match.");
  if (u.status !== "ACTIVE") throw new HttpError(403, "FORBIDDEN", "This account is suspended.");
  return session(u);
});
on("POST", "/api/auth/refresh", () => {
  const u = db.users.find((x) => x.id === Number(localStorage.getItem(SESSION)));
  if (!u) throw new HttpError(401, "UNAUTHORIZED", "Please log in.");
  return session(u);
});
on("POST", "/api/auth/logout", () => (localStorage.removeItem(SESSION), { message: "Logged out" }));
on("POST", "/api/auth/forgot-password", () => ({ message: "If that email has an account, a reset link is on its way." }));
on("POST", "/api/auth/reset-password", () => {
  throw bad("Password reset emails are not sent in the demo.");
});
on("GET", "/api/me", ({ token }) => meView(auth(token)));
on("PUT", "/api/me/password", ({ token, body }) => {
  const u = auth(token);
  if (u.password !== body.currentPassword) throw bad("Your current password isn't right.");
  u.password = body.newPassword;
  return { message: "Password changed." };
});

on("GET", "/api/store", ({ token }) => storeView(storeOf(auth(token))));
on("PUT", "/api/store", ({ token, body }) => {
  const s = storeOf(auth(token));
  if (body.slug !== s.slug && db.stores.some((x) => x.slug === body.slug)) throw new HttpError(409, "CONFLICT", "That shop address is taken. Try another one.");
  if (!body.onlinePayments && !body.whatsappOrders) throw bad("Keep at least one way for customers to order.");
  Object.assign(s, { name: body.name, slug: body.slug, whatsapp: cleanPhone(body.whatsapp), currency: body.currency, about: body.about, accentColor: body.accentColor, logoUrl: body.logoUrl, onlinePayments: body.onlinePayments, whatsappOrders: body.whatsappOrders, publicLink: body.publicLink });
  return storeView(s);
});

on("POST", "/api/uploads", async ({ token, form }) => {
  auth(token);
  const file = form?.get("file");
  if (!(file instanceof File)) throw bad("Choose a photo first.");
  return { url: await shrinkImage(file) };
});

on("GET", "/api/products", ({ token }) => {
  const s = storeOf(auth(token));
  return db.products.filter((p) => p.storeId === s.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(productView);
});
on("POST", "/api/products", ({ token, body }) => {
  const s = storeOf(auth(token));
  if (PRODUCT_LIMIT && db.products.filter((p) => p.storeId === s.id).length >= PRODUCT_LIMIT) throw bad(`Shops can have up to ${PRODUCT_LIMIT} products. Remove one to add another.`);
  const p: DProduct = { id: ++db.seq, storeId: s.id, name: body.name, price: round(body.price), category: body.category, description: body.description, imageUrl: body.imageUrl, inStock: body.inStock, stockQty: body.stockQty, featured: body.featured, createdAt: iso() };
  db.products.push(p);
  return productView(p);
});
on("PUT", "/api/products/:id", ({ token, body, params }) => {
  const s = storeOf(auth(token));
  const p = db.products.find((x) => x.id === Number(params[0]) && x.storeId === s.id);
  if (!p) throw new HttpError(404, "NOT_FOUND", "Product not found.");
  Object.assign(p, { name: body.name, price: round(body.price), category: body.category, description: body.description, imageUrl: body.imageUrl, inStock: body.inStock, stockQty: body.stockQty, featured: body.featured });
  return productView(p);
});
on("DELETE", "/api/products/:id", ({ token, params }) => {
  const s = storeOf(auth(token));
  db.products = db.products.filter((x) => !(x.id === Number(params[0]) && x.storeId === s.id));
  return undefined;
});

on("GET", "/api/orders", ({ token, query }) => {
  const s = storeOf(auth(token));
  const st = query.get("status");
  return db.orders.filter((o) => o.storeId === s.id && (!st || o.status === st)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(orderView);
});
on("POST", "/api/orders", ({ token, body }) => {
  const s = storeOf(auth(token));
  const o: DOrder = { id: ++db.seq, storeId: s.id, number: `LM-${code(6)}`, customerName: body.customerName, customerPhone: body.customerPhone, customerEmail: null, address: body.address, note: body.note, channel: "MANUAL", status: "NEW", total: round(body.total), currency: s.currency, paymentProvider: null, itemsSummary: body.itemsSummary, items: [], createdAt: iso(), paidAt: null, stockDeducted: false, adId: null };
  db.orders.push(o);
  changeStatus(o, body.status);
  return orderView(o);
});
const ownOrder = (token: string | null, id: string) => {
  const s = storeOf(auth(token));
  const o = db.orders.find((x) => x.id === Number(id) && x.storeId === s.id);
  if (!o) throw new HttpError(404, "NOT_FOUND", "Order not found.");
  return o;
};
on("GET", "/api/orders/:id", ({ token, params }) => orderView(ownOrder(token, params[0]!)));
on("PUT", "/api/orders/:id", ({ token, params, body }) => {
  const o = ownOrder(token, params[0]!);
  Object.assign(o, { customerName: body.customerName, customerPhone: body.customerPhone, address: body.address, note: body.note });
  if (o.channel === "MANUAL") Object.assign(o, { itemsSummary: body.itemsSummary, total: round(body.total) });
  changeStatus(o, body.status);
  return orderView(o);
});
on("PATCH", "/api/orders/:id/status", ({ token, params, body }) => {
  const o = ownOrder(token, params[0]!);
  changeStatus(o, body.status);
  return orderView(o);
});

on("GET", "/api/dashboard", ({ token }): Dashboard => {
  const s = storeOf(auth(token));
  const orders = db.orders.filter((o) => o.storeId === s.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const sales = orders.filter((o) => isSale(o.status));
  const today = new Date(new Date().toISOString().slice(0, 10)).getTime();
  const last30 = Array.from({ length: 30 }, (_, k) => {
    const d = new Date(today - (29 - k) * DAY).toISOString().slice(0, 10);
    const day = sales.filter((o) => (o.paidAt ?? o.createdAt).slice(0, 10) === d);
    return { date: d, total: round(day.reduce((n, o) => n + o.total, 0)), orders: day.length };
  });
  const top = new Map<string, { productId: number | null; name: string; quantity: number; revenue: number }>();
  sales.filter((o) => Date.now() - new Date(o.paidAt ?? o.createdAt).getTime() < 30 * DAY).forEach((o) =>
    o.items.forEach((i) => {
      const t = top.get(i.name) ?? { productId: i.productId, name: i.name, quantity: 0, revenue: 0 };
      t.quantity += i.quantity;
      t.revenue += i.lineTotal;
      top.set(i.name, t);
    }),
  );
  const revenue = sales.reduce((n, o) => n + o.total, 0);
  return {
    currency: s.currency, revenue: round(revenue), revenue30: round(last30.reduce((n, d) => n + d.total, 0)), paidOrders: sales.length, newOrders: orders.filter((o) => o.status === "NEW").length,
    totalOrders: orders.length, productCount: db.products.filter((p) => p.storeId === s.id).length, averageOrder: sales.length ? round(revenue / sales.length) : 0, account: accountView(s),
    last7: last30.slice(23), last30, topProducts: [...top.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5), recentOrders: orders.slice(0, 6).map(orderView), shopUrl: shopUrl(s),
  };
});

// ── Public shop ───────────────────────────────────────────────────────────────

const openShop = (slug: string) => {
  const s = db.stores.find((x) => x.slug === slug);
  const owner = s && db.users.find((u) => u.id === s.ownerId);
  if (!s || owner?.status !== "ACTIVE") throw new HttpError(404, "NOT_FOUND", "This shop doesn't exist.");
  return s;
};
/** WhatsApp checkout pauses while too much commission is unpaid (online payment keeps working). */
const takesWhatsapp = (s: DStore) => s.whatsappOrders && !whatsappPaused(s);
on("GET", "/api/shops/:slug", ({ params }): Shop => {
  const s = openShop(params[0]!);
  const products = db.products.filter((p) => p.storeId === s.id).sort((a, b) => Number(b.featured) - Number(a.featured) || Number(available(b)) - Number(available(a)) || b.createdAt.localeCompare(a.createdAt));
  return {
    name: s.name, slug: s.slug, about: s.about, whatsapp: s.whatsapp, currency: s.currency, accentColor: s.accentColor, logoUrl: s.logoUrl, whatsappOrders: takesWhatsapp(s), onlinePayments: s.onlinePayments,
    providers: s.onlinePayments ? PROVIDERS : [], categories: [...new Set(products.map((p) => p.category).filter(Boolean) as string[])].sort(),
    products: products.map((p) => ({ id: p.id, name: p.name, price: p.price, category: p.category, description: p.description, imageUrl: p.imageUrl, available: available(p), featured: p.featured, stockLeft: p.stockQty !== null && p.stockQty <= 5 ? p.stockQty : null })),
    assistant: true,
  };
});
on("POST", "/api/shops/:slug/orders", ({ params, body }) => {
  const s = openShop(params[0]!);
  if (!takesWhatsapp(s)) throw bad("This shop takes online payments only right now.");
  const o = cartOrder(s, body, "WHATSAPP", "NEW");
  const text = [`Hello ${s.name}! I'd like to order (${o.number}):`, ...o.items.map((i) => `• ${i.quantity} x ${i.name} (${fmt(i.lineTotal, o.currency)})`), `Total: ${fmt(o.total, o.currency)}`, `Name: ${o.customerName}`, `Phone: ${o.customerPhone}`, `Deliver to: ${o.address}`, ...(o.note ? [`Note: ${o.note}`] : [])].join("\n");
  return { orderNumber: o.number, total: o.total, currency: o.currency, whatsappUrl: wa(s.whatsapp, text) };
});
on("POST", "/api/shops/:slug/checkout", ({ params, body }) => {
  const s = openShop(params[0]!);
  const o = cartOrder(s, body, "ONLINE", "PENDING_PAYMENT");
  const f = fee(o.total);
  const p: DPayment = { reference: `PAY-${code(12)}`, purpose: "ORDER", provider: "demo", status: "PENDING", amount: o.total, currency: o.currency, storeId: s.id, orderId: o.id, paid: false, payerEmail: o.customerEmail, note: null, settlement: "NONE", platformFee: f, sellerAmount: round(o.total - f), createdAt: iso(), paidAt: null };
  db.payments.push(p);
  const q = new URLSearchParams({ reference: p.reference, amount: String(p.amount), currency: p.currency, title: s.name, return: `${location.origin}/s/${s.slug}/thanks`, cancel: `${location.origin}/s/${s.slug}?checkout=cancelled` });
  return { reference: p.reference, checkoutUrl: `/pay/demo?${q}` };
});
on("POST", "/api/shops/:slug/track", ({ params, body }) => {
  const s = openShop(params[0]!);
  const id = adIdFromRef(s, body.ref);
  const ad = id ? db.ads.find((a) => a.id === id) : undefined;
  if (ad) {
    const t = (ad.tracked[dateOf(Date.now())] ??= [0, 0]);
    if (body.event === "whatsapp") t[1]++;
    else t[0]++;
  }
  return undefined;
});
on("POST", "/api/shops/:slug/assistant", ({ params, body }) => {
  const s = openShop(params[0]!);
  const last = [...(body.messages ?? [])].reverse().find((m: { role: string }) => m.role === "user")?.content ?? "";
  try {
    takeCredit(s);
  } catch {
    return { reply: 'Our assistant is taking a short break. Add what you like to your cart and tap "Order on WhatsApp". We\'ll help you there!', suggestions: [], engine: "none" };
  }
  const products = db.products.filter((p) => p.storeId === s.id).map((p) => ({ ...p, price: p.price, available: available(p) }));
  return ai.chat(last, products, s);
});

// ── Payments ──────────────────────────────────────────────────────────────────

on("POST", "/api/payments/verify", ({ body }) => {
  const p = db.payments.find((x) => x.reference === body.reference);
  if (!p) throw new HttpError(404, "NOT_FOUND", "We can't find that payment.");
  if (p.paid) fulfill(p);
  return paymentStatus(p);
});
on("POST", "/api/payments/demo/:ref/complete", ({ params }) => {
  const p = db.payments.find((x) => x.reference === decodeURIComponent(params[0]!));
  if (!p) throw new HttpError(404, "NOT_FOUND", "We can't find that payment.");
  p.paid = true;
  fulfill(p);
  return paymentStatus(p);
});

// ── Earnings (commission) ─────────────────────────────────────────────────────

on("GET", "/api/earnings", ({ token }): Earnings => {
  const s = storeOf(auth(token));
  const monthStart = new Date(`${month()}-01T00:00:00Z`).toISOString();
  const mine = db.commission.filter((c) => c.storeId === s.id);
  const settled = mine.filter((c) => c.status === "SETTLED");
  const d = due(s);
  return {
    currency: s.currency, percent: PERCENT, chargesWhatsappOrders: ON_WHATSAPP, due: Math.max(0, d), dueLimit: DUE_LIMIT, whatsappPaused: whatsappPaused(s),
    paidThisMonth: round(settled.filter((c) => (c.settledAt ?? "") >= monthStart).reduce((n, c) => n + c.amount, 0)),
    paidAllTime: round(settled.reduce((n, c) => n + c.amount, 0)),
    salesThisMonth: round(db.orders.filter((o) => o.storeId === s.id && isSale(o.status) && o.createdAt >= monthStart).reduce((n, o) => n + o.total, 0)),
    owedToYou: round(db.payments.filter((p) => p.storeId === s.id && p.settlement === "OWED" && p.status === "SUCCESS").reduce((n, p) => n + (p.sellerAmount ?? 0), 0)),
    providers: PROVIDERS,
    entries: [...mine].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 100).map(entryView),
    payments: db.payments.filter((p) => p.storeId === s.id && p.purpose === "COMMISSION").sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 50).map(paymentView),
  };
});
on("POST", "/api/earnings/pay", ({ token }) => {
  const u = auth(token);
  const s = storeOf(u);
  const d = due(s);
  if (d <= 0) throw bad("You don't owe any commission right now.");
  const p: DPayment = { reference: `COM-${code(12)}`, purpose: "COMMISSION", provider: "demo", status: "PENDING", amount: d, currency: s.currency, storeId: s.id, orderId: null, paid: false, payerEmail: u.email, note: null, settlement: "NONE", platformFee: null, sellerAmount: null, createdAt: iso(), paidAt: null };
  db.payments.push(p);
  const q = new URLSearchParams({ reference: p.reference, amount: String(p.amount), currency: s.currency, title: "Lite Marketplace: commission", return: `${location.origin}/app/earnings/callback`, cancel: `${location.origin}/app/earnings?cancelled=1` });
  return { reference: p.reference, checkoutUrl: `/pay/demo?${q}` };
});

// ── AI ────────────────────────────────────────────────────────────────────────

on("GET", "/api/ai/usage", ({ token }) => {
  const s = storeOf(auth(token));
  return { used: aiUsed(s), limit: AI_CREDITS };
});
on("POST", "/api/ai/product-writer", ({ token, body }) => {
  const s = storeOf(auth(token));
  takeCredit(s);
  return ai.writeProduct(body, { name: s.name, currency: s.currency, shopUrl: shopUrl(s) });
});
on("POST", "/api/ai/reply-drafts", ({ token, body }) => {
  const s = storeOf(auth(token));
  takeCredit(s);
  const o = body.orderId ? db.orders.find((x) => x.id === body.orderId && x.storeId === s.id) : null;
  return ai.replyDrafts(body.message, { name: s.name, shopUrl: shopUrl(s) }, o);
});
on("POST", "/api/ai/broadcast", ({ token, body }) => {
  const s = storeOf(auth(token));
  takeCredit(s);
  const mine = db.products.filter((p) => p.storeId === s.id && available(p));
  const picked = body.productIds?.length ? mine.filter((p) => body.productIds.includes(p.id)) : mine.sort((a, b) => Number(b.featured) - Number(a.featured)).slice(0, 4);
  return ai.broadcast({ name: s.name, currency: s.currency, shopUrl: shopUrl(s) }, picked.map((p) => ({ ...p, available: true })), body.goal ?? "", body.tone ?? "exciting");
});
on("POST", "/api/ai/coach", ({ token }) => {
  const s = storeOf(auth(token));
  takeCredit(s);
  const products = db.products.filter((p) => p.storeId === s.id).map((p) => ({ ...p, available: available(p) }));
  return ai.coach({ currency: s.currency }, products, db.orders.filter((o) => o.storeId === s.id));
});

// ── Ads (seller only) ─────────────────────────────────────────────────────────

on("GET", "/api/ads", ({ token }): AdsOverview => {
  const s = storeOf(auth(token));
  syncAds(s);
  return {
    shopCurrency: s.currency, maxDailyBudget: MAX_DAILY_BUDGET, networks: networkViews(s), settings: settingsView(settingsOf(s)),
    ads: db.ads.filter((a) => a.storeId === s.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(adView),
    activity: db.logs.filter((l) => l.storeId === s.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 40).map(logView),
  };
});
on("GET", "/api/ads/stats", ({ token, query }): AdStats => {
  const s = storeOf(auth(token));
  syncAds(s);
  const req = Number(query.get("days") ?? 30);
  const days = req <= 7 ? 7 : req <= 30 ? 30 : 90;
  const today = new Date(new Date().toISOString().slice(0, 10)).getTime();
  const since = dateOf(today - (days - 1) * DAY);
  const ads = db.ads.filter((a) => a.storeId === s.id);
  const spendCurrency = ads.find((a) => a.status !== "DRAFT")?.currency ?? s.currency;
  const series = new Map<string, { date: string; impressions: number; clicks: number; spend: number; orders: number; revenue: number }>();
  for (let k = days - 1; k >= 0; k--) {
    const date = dateOf(today - k * DAY);
    series.set(date, { date, impressions: 0, clicks: 0, spend: 0, orders: 0, revenue: 0 });
  }
  const totals = { impressions: 0, clicks: 0, spend: 0, visits: 0, whatsappClicks: 0, orders: 0, revenue: 0 };
  const net = new Map<AdNetworkId, { network: AdNetworkId; currency: string | null; impressions: number; clicks: number; spend: number; orders: number; revenue: number }>();
  const netOf = (a: DAd) => net.get(a.network) ?? (net.set(a.network, { network: a.network, currency: a.currency, impressions: 0, clicks: 0, spend: 0, orders: 0, revenue: 0 }), net.get(a.network)!);
  for (const a of ads) {
    for (const d of simulate(a)) {
      if (d.date < since) continue;
      totals.impressions += d.impressions;
      totals.clicks += d.clicks;
      totals.spend += d.spend;
      totals.visits += d.visits;
      totals.whatsappClicks += d.whatsapp;
      const row = series.get(d.date);
      if (row) (row.impressions += d.impressions), (row.clicks += d.clicks), (row.spend = round(row.spend + d.spend));
      if (d.impressions || d.spend) {
        const n = netOf(a);
        n.impressions += d.impressions;
        n.clicks += d.clicks;
        n.spend = round(n.spend + d.spend);
      }
    }
  }
  db.orders.filter((o) => o.storeId === s.id && o.adId !== null && isSale(o.status) && o.createdAt.slice(0, 10) >= since).forEach((o) => {
    const a = ads.find((x) => x.id === o.adId);
    if (!a) return;
    totals.orders++;
    totals.revenue += o.total;
    const row = series.get((o.paidAt ?? o.createdAt).slice(0, 10));
    if (row) (row.orders++, (row.revenue = round(row.revenue + o.total)));
    const n = netOf(a);
    n.orders++;
    n.revenue = round(n.revenue + o.total);
  });
  const fx = settingsOf(s).fxRate;
  const spendInShop = spendCurrency === s.currency ? totals.spend : fx ? totals.spend * fx : null;
  return {
    days, shopCurrency: s.currency, spendCurrency,
    totals: {
      ...totals, spend: round(totals.spend), revenue: round(totals.revenue), ctr: totals.impressions ? round((totals.clicks * 100) / totals.impressions) : null,
      cpc: totals.clicks ? round(totals.spend / totals.clicks) : null, roas: spendInShop ? round(totals.revenue / spendInShop) : null, activeAds: ads.filter((a) => a.status === "ACTIVE").length,
    },
    daily: [...series.values()],
    byNetwork: [...net.values()],
  };
});
on("POST", "/api/ads/sync", ({ token }) => {
  const s = storeOf(auth(token));
  syncAds(s);
  return { synced: db.ads.filter((a) => a.storeId === s.id && a.launchedAt).length };
});
on("POST", "/api/ads/accounts/:network/connect", ({ token, params }) => {
  const s = storeOf(auth(token));
  const network = params[0] as AdNetworkId;
  if (!NETWORKS.some((n) => n.id === network)) throw new HttpError(404, "NOT_FOUND", "Unknown ad network.");
  let a = db.accounts.find((x) => x.storeId === s.id && x.network === network);
  const expires = network === "meta" ? iso(-60 * DAY) : null;
  if (a) Object.assign(a, { tokenExpiresAt: expires, connectedAt: iso(), state: a.accountId ? "CONNECTED" : "NEEDS_SETUP" });
  else {
    // One demo ad account and Page/TikTok account: picked automatically, like the backend's autoSelect.
    const x = assets(s, network);
    a = {
      storeId: s.id, network, state: "CONNECTED", accountId: x.adAccounts[0]!.id, accountName: x.adAccounts[0]!.name, currency: s.currency, pageName: x.pages[0]?.name ?? null,
      instagram: x.pages[0]?.linkedName ?? null, identityName: x.identities[0]?.name ?? null, tokenExpiresAt: expires, connectedAt: iso(),
    };
    db.accounts.push(a);
  }
  return { url: `/app/ads?connected=${network}` };
});
on("GET", "/api/ads/accounts/:network/options", ({ token, params }) => {
  const s = storeOf(auth(token));
  const network = params[0] as AdNetworkId;
  if (!db.accounts.some((x) => x.storeId === s.id && x.network === network)) throw bad(`Connect ${label(network)} first.`);
  return assets(s, network);
});
on("PUT", "/api/ads/accounts/:network", ({ token, params, body }) => {
  const s = storeOf(auth(token));
  const network = params[0] as AdNetworkId;
  const a = db.accounts.find((x) => x.storeId === s.id && x.network === network);
  if (!a) throw bad(`Connect ${label(network)} first.`);
  const x = assets(s, network);
  const acc = x.adAccounts.find((o) => o.id === body.adAccountId);
  if (!acc) throw bad("That ad account isn't available. Pick another one.");
  Object.assign(a, { accountId: acc.id, accountName: acc.name, currency: acc.currency ?? s.currency });
  if (network === "meta") {
    const page = x.pages.find((o) => o.id === body.pageId);
    if (!page) throw bad("Choose the Facebook Page your ads will come from.");
    Object.assign(a, { pageName: page.name, instagram: page.linkedName });
  } else {
    a.identityName = x.identities.find((o) => o.id === body.identityId)?.name ?? null;
  }
  a.state = "CONNECTED";
  return networkViews(s).find((n) => n.network === network);
});
on("DELETE", "/api/ads/accounts/:network", ({ token, params }) => {
  const s = storeOf(auth(token));
  db.accounts = db.accounts.filter((x) => !(x.storeId === s.id && x.network === params[0]));
  return undefined;
});
on("POST", "/api/ads/copy", ({ token, body }) => {
  const s = storeOf(auth(token));
  const p = productSignals(s).find((x) => x.id === Number(body.productId));
  if (!p) throw new HttpError(404, "NOT_FOUND", "Product not found.");
  takeCredit(s);
  return ai.adCopy({ name: s.name, currency: s.currency, whatsappOrders: s.whatsappOrders, onlinePayments: s.onlinePayments }, p, body.network === "tiktok" ? "tiktok" : "meta");
});
on("POST", "/api/ads", ({ token, body }) => {
  const s = storeOf(auth(token));
  const ad = prepare(s, body.network, Number(body.productId), body, "SELLER", null);
  launch(ad);
  return adView(ad);
});
on("POST", "/api/ads/:id/approve", ({ token, params }) => {
  const s = storeOf(auth(token));
  const a = ownAd(s, params[0]!);
  if (a.status !== "DRAFT" && a.status !== "ERROR") throw bad("This ad has already been launched.");
  checkBudget(readyAccount(s, a.network), a.dailyBudget);
  launch(a);
  return adView(a);
});
on("POST", "/api/ads/:id/pause", ({ token, params }) => {
  const a = ownAd(storeOf(auth(token)), params[0]!);
  if (a.status !== "ACTIVE" && a.status !== "IN_REVIEW") throw bad("Only running ads can be paused.");
  closeSpan(a);
  Object.assign(a, { status: "PAUSED", pausedAt: iso(), pausedByAutopilot: false });
  return adView(a);
});
on("POST", "/api/ads/:id/resume", ({ token, params }) => {
  const a = ownAd(storeOf(auth(token)), params[0]!);
  if (a.status !== "PAUSED") throw bad("Only paused ads can be resumed.");
  openSpan(a);
  Object.assign(a, { status: "ACTIVE", pausedAt: null, pausedByAutopilot: false });
  return adView(a);
});
on("POST", "/api/ads/:id/end", ({ token, params }) => {
  const a = ownAd(storeOf(auth(token)), params[0]!);
  if (a.status === "DRAFT") {
    db.ads = db.ads.filter((x) => x.id !== a.id);
    return adView(a);
  }
  endAd(a);
  return adView(a);
});
on("PUT", "/api/ads/:id/budget", ({ token, params, body }) => {
  const s = storeOf(auth(token));
  const a = ownAd(s, params[0]!);
  const b = round(Number(body.dailyBudget));
  checkBudget(readyAccount(s, a.network), b);
  a.dailyBudget = b;
  if (a.spans.some((x) => x.until === null)) openSpan(a);
  return adView(a);
});
on("PUT", "/api/ads/settings", ({ token, body }) => {
  const s = storeOf(auth(token));
  const x = settingsOf(s);
  if (body.autopilotEnabled && !x.termsAcceptedAt && !body.acceptTerms) throw bad("Please confirm that the autopilot may spend up to your daily limit.");
  if (body.acceptTerms && !x.termsAcceptedAt) x.termsAcceptedAt = iso();
  if (Number(body.perAdBudget) > MAX_DAILY_BUDGET) throw bad(`The most any single ad can spend per day is ${MAX_DAILY_BUDGET}.`);
  if (Number(body.dailyBudgetCap) > 0 && Number(body.perAdBudget) > Number(body.dailyBudgetCap)) throw bad("The budget for each ad can't be more than your total daily limit.");
  if (!Array.isArray(body.networks) || !body.networks.length) throw new HttpError(400, "VALIDATION", "networks must not be empty");
  const wasOff = !x.autopilotEnabled;
  Object.assign(x, {
    autopilotEnabled: !!body.autopilotEnabled, autoLaunch: !!body.autoLaunch, networks: body.networks, dailyBudgetCap: round(Number(body.dailyBudgetCap)), perAdBudget: round(Number(body.perAdBudget)),
    maxActiveAds: Math.max(1, Math.min(10, Number(body.maxActiveAds) || 3)), countries: cleanCountries(body.countries), ageMin: Math.max(18, Number(body.ageMin) || 18),
    ageMax: Math.max(Math.max(18, Number(body.ageMin) || 18), Number(body.ageMax) || 55), minCtr: round(Number(body.minCtr) || 0),
    maxCpc: body.maxCpc ? round(Number(body.maxCpc)) : null, fxRate: body.fxRate ? Number(body.fxRate) : null,
  });
  if (wasOff && x.autopilotEnabled) x.lastRunAt = null; // first check happens on the next visit
  return settingsView(x);
});
on("POST", "/api/ads/autopilot/run", ({ token }) => {
  const s = storeOf(auth(token));
  if (!settingsOf(s).autopilotEnabled) throw bad("Turn on the autopilot first.");
  return runAutopilot(s);
});

// ── Admin ─────────────────────────────────────────────────────────────────────

const admin = (token: string | null) => {
  const u = auth(token);
  if (u.role !== "ADMIN") throw new HttpError(403, "FORBIDDEN", "You don't have access to this.");
  return u;
};
const sellerRow = (s: DStore): SellerRow => {
  const u = db.users.find((x) => x.id === s.ownerId)!;
  return {
    storeId: s.id, userId: u.id, storeName: s.name, slug: s.slug, email: u.email, whatsapp: s.whatsapp, currency: s.currency, commissionDue: Math.max(0, due(s)), whatsappPaused: whatsappPaused(s),
    products: db.products.filter((x) => x.storeId === s.id).length, status: u.status, role: u.role, createdAt: s.createdAt, flutterwaveSubaccount: s.flutterwaveSubaccount,
    paystackSubaccount: s.paystackSubaccount, stripeAccount: s.stripeAccount, shopUrl: shopUrl(s),
  };
};
// The real backend leaves demo payments out of these totals; the browser demo includes them so there is something to see.
on("GET", "/api/admin/overview", ({ token }): AdminOverview => {
  admin(token);
  const sum = (st: CommissionStatus) => round(db.commission.filter((c) => c.status === st).reduce((n, c) => n + c.amount, 0));
  return {
    users: db.users.length, stores: db.stores.length, products: db.products.length, orders: db.orders.length, commissionEarned: sum("SETTLED"), commissionDue: Math.max(0, sum("DUE")),
    orderVolume: round(db.payments.filter((p) => p.purpose === "ORDER" && p.status === "SUCCESS").reduce((n, p) => n + p.amount, 0)), owedToSellers: 0, currency: "GHS", aiOnline: true,
    providers: PROVIDERS, demoPayments: true, commissionPercent: PERCENT, emailEnabled: false,
  };
});
on("GET", "/api/admin/sellers", ({ token, query }) => {
  admin(token);
  const q = (query.get("q") ?? "").toLowerCase();
  return db.stores.filter((s) => !q || `${s.name} ${s.slug} ${s.whatsapp} ${db.users.find((u) => u.id === s.ownerId)?.email}`.toLowerCase().includes(q)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(sellerRow);
});
on("POST", "/api/admin/sellers/:id/commission/paid", ({ token, params }) => {
  admin(token);
  const s = db.stores.find((x) => x.id === Number(params[0]));
  if (!s) throw new HttpError(404, "NOT_FOUND", "Store not found.");
  const d = due(s);
  if (d <= 0) throw bad("This seller doesn't owe any commission.");
  const p: DPayment = { reference: `MAN-${code(12)}`, purpose: "COMMISSION", provider: "manual", status: "SUCCESS", amount: d, currency: s.currency, storeId: s.id, orderId: null, paid: true, payerEmail: null, note: "Paid directly (marked by admin)", settlement: "NONE", platformFee: null, sellerAmount: null, createdAt: iso(), paidAt: iso() };
  db.payments.push(p);
  settle(s.id, d, p.reference);
  return sellerRow(s);
});
on("POST", "/api/admin/sellers/:id/status", ({ token, params, body }) => {
  const me = admin(token);
  const s = db.stores.find((x) => x.id === Number(params[0]))!;
  if (s.ownerId === me.id) throw bad("You can't suspend yourself.");
  db.users.find((u) => u.id === s.ownerId)!.status = body.status;
  return sellerRow(s);
});
on("PUT", "/api/admin/sellers/:id/split", ({ token, params, body }) => {
  admin(token);
  const s = db.stores.find((x) => x.id === Number(params[0]))!;
  Object.assign(s, { paystackSubaccount: body.paystackSubaccount || null, flutterwaveSubaccount: body.flutterwaveSubaccount || null, stripeAccount: body.stripeAccount || null });
  return sellerRow(s);
});
on("GET", "/api/admin/payments", ({ token }): AdminPayment[] => {
  admin(token);
  return [...db.payments].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map((p) => {
    const s = db.stores.find((x) => x.id === p.storeId)!;
    return { reference: p.reference, purpose: p.purpose, provider: p.provider, status: p.status, amount: p.amount, currency: p.currency, storeName: s.name, storeSlug: s.slug, payerEmail: p.payerEmail, settlement: p.settlement, platformFee: p.platformFee, sellerAmount: p.sellerAmount, createdAt: p.createdAt, paidAt: p.paidAt, note: p.note };
  });
});
on("GET", "/api/admin/payouts", ({ token }): PayoutRow[] => (admin(token), []));
on("POST", "/api/admin/payouts/:id/paid", ({ token }) => (admin(token), { updated: 0 }));

export async function mockFetch(method: string, rawPath: string, body: unknown, form: FormData | undefined, token: string | null): Promise<Response> {
  await new Promise((r) => setTimeout(r, 180 + Math.random() * 220)); // feel like a network
  db = load();
  const [path, search = ""] = rawPath.split("?");
  for (const [m, re, handler] of routes) {
    const match = m === method && re.exec(path!);
    if (!match) continue;
    try {
      if (method === "GET" && path === "/api/ads") autopilotTick();
      const result = await handler({ body: body ?? {}, token, params: match.slice(1), query: new URLSearchParams(search), form });
      persist();
      return json(result === undefined ? 204 : 200, result);
    } catch (e) {
      if (e instanceof HttpError) return json(e.status, { error: e.code, message: e.message });
      console.error(e);
      return json(500, { error: "SERVER_ERROR", message: "Something went wrong in the demo." });
    }
  }
  return json(404, { error: "NOT_FOUND", message: "Not found." });
}
