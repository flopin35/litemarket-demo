export const CATEGORIES = ["Food", "Drinks", "Snacks", "Clothes", "Shoes", "Bags", "Beauty", "Phones & gadgets", "Home", "Services", "Other"];

export const CURRENCIES = [
  { value: "GHS", label: "GHS · Ghana cedi" },
  { value: "NGN", label: "NGN · Naira" },
  { value: "KES", label: "KES · Kenyan shilling" },
  { value: "ZAR", label: "ZAR · Rand" },
  { value: "UGX", label: "UGX · Ugandan shilling" },
  { value: "XOF", label: "XOF · CFA franc" },
  { value: "USD", label: "USD · US dollar" },
  { value: "EUR", label: "EUR · Euro" },
  { value: "GBP", label: "GBP · Pound" },
];

export const TONES = [
  { value: "friendly", label: "Friendly" },
  { value: "exciting", label: "Exciting" },
  { value: "professional", label: "Professional" },
  { value: "luxury", label: "Luxury" },
];

export const LANGUAGES = ["English", "French", "Twi", "Ga", "Ewe", "Hausa", "Yoruba", "Igbo", "Pidgin", "Swahili", "Portuguese"];

export const ACCENTS = ["#0F9D7A", "#E8590C", "#7C3AED", "#DB2777", "#2563EB", "#CA8A04", "#0891B2", "#18181B"];
