// Shapes returned by the Java API (records in backend/src/main/java/com/litemarket/**/…Dtos.java).

export type Role = "SELLER" | "ADMIN";

export interface StoreView {
  id: number;
  name: string;
  slug: string;
  whatsapp: string;
  currency: string;
  about: string | null;
  accentColor: string | null;
  logoUrl: string | null;
  onlinePayments: boolean;
  whatsappOrders: boolean;
  publicLink: string | null;
  shopUrl: string;
}

/** Commission and allowances for the signed-in seller. */
export interface AccountView {
  commissionPercent: number;
  currency: string;
  commissionDue: number;
  dueLimit: number;
  whatsappPaused: boolean;
  aiCreditsUsed: number;
  aiCreditsLimit: number;
  productLimit: number | null;
}

export interface MeView {
  id: number;
  email: string;
  fullName: string | null;
  role: Role;
  store: StoreView | null;
  account: AccountView | null;
}

export interface AuthResponse {
  accessToken: string;
  expiresIn: number;
  me: MeView;
}

export interface ProviderOption {
  id: string;
  label: string;
}

export interface AdsConfig {
  meta: boolean;
  tiktok: boolean;
  demo: boolean;
}

export interface PublicConfig {
  brandName: string;
  supportEmail: string;
  currency: string;
  commissionPercent: number;
  commissionOnWhatsappOrders: boolean;
  aiMonthlyCredits: number;
  productLimit: number | null;
  providers: ProviderOption[];
  demoPayments: boolean;
  ads: AdsConfig;
}

export interface Product {
  id: number;
  name: string;
  price: number;
  category: string | null;
  description: string | null;
  imageUrl: string | null;
  inStock: boolean;
  stockQty: number | null;
  featured: boolean;
  available: boolean;
  createdAt: string;
}

export interface ProductInput {
  name: string;
  price: number;
  category: string | null;
  description: string | null;
  imageUrl: string | null;
  inStock: boolean;
  stockQty: number | null;
  featured: boolean;
}

export type OrderStatus = "NEW" | "PENDING_PAYMENT" | "PAID" | "DELIVERED" | "CANCELLED";
export type OrderChannel = "WHATSAPP" | "ONLINE" | "MANUAL";

export interface OrderItem {
  productId: number | null;
  name: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface Order {
  id: number;
  number: string;
  customerName: string;
  customerPhone: string | null;
  customerEmail: string | null;
  address: string | null;
  note: string | null;
  channel: OrderChannel;
  status: OrderStatus;
  total: number;
  currency: string;
  paymentProvider: string | null;
  itemsSummary: string | null;
  items: OrderItem[];
  fromAd: boolean;
  createdAt: string;
  paidAt: string | null;
}

export interface ManualOrderInput {
  customerName: string;
  customerPhone: string | null;
  itemsSummary: string | null;
  total: number;
  status: OrderStatus;
  address: string | null;
  note: string | null;
}

export interface DayPoint {
  date: string;
  total: number;
  orders: number;
}

export interface TopProduct {
  productId: number | null;
  name: string;
  quantity: number;
  revenue: number;
}

export interface Dashboard {
  currency: string;
  revenue: number;
  revenue30: number;
  paidOrders: number;
  newOrders: number;
  totalOrders: number;
  productCount: number;
  averageOrder: number;
  account: AccountView;
  last7: DayPoint[];
  last30: DayPoint[];
  topProducts: TopProduct[];
  recentOrders: Order[];
  shopUrl: string;
}

export interface StoreInput {
  name: string;
  slug: string;
  whatsapp: string;
  currency: string;
  about: string | null;
  accentColor: string | null;
  logoUrl: string | null;
  onlinePayments: boolean;
  whatsappOrders: boolean;
  publicLink: string | null;
}

export interface PublicProduct {
  id: number;
  name: string;
  price: number;
  category: string | null;
  description: string | null;
  imageUrl: string | null;
  available: boolean;
  featured: boolean;
  stockLeft: number | null;
}

export interface Shop {
  name: string;
  slug: string;
  about: string | null;
  whatsapp: string;
  currency: string;
  accentColor: string | null;
  logoUrl: string | null;
  whatsappOrders: boolean;
  onlinePayments: boolean;
  providers: ProviderOption[];
  categories: string[];
  products: PublicProduct[];
  assistant: boolean;
}

export interface CartLine {
  productId: number;
  quantity: number;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  email: string | null;
  address: string;
  note: string | null;
}

export interface CheckoutInput {
  items: CartLine[];
  customer: CustomerInfo;
  provider?: string;
  /** The ad the customer came from ("ad42"), for ad results. */
  ref?: string | null;
}

export interface WhatsAppOrder {
  orderNumber: string;
  total: number;
  currency: string;
  whatsappUrl: string;
}

export interface CheckoutStart {
  reference: string;
  checkoutUrl: string;
}

export interface PaymentStatus {
  reference: string;
  status: "PENDING" | "SUCCESS" | "FAILED";
  purpose: "ORDER" | "COMMISSION";
  provider: string;
  amount: number;
  currency: string;
  orderNumber: string | null;
  storeName: string;
  storeSlug: string;
  whatsappUrl: string | null;
  message: string;
}

export interface PaymentView {
  reference: string;
  purpose: string;
  provider: string;
  status: string;
  amount: number;
  currency: string;
  note: string | null;
  createdAt: string;
  paidAt: string | null;
}

// ── Earnings (commission) ───────────────────────────────────────────────────────

export type CommissionKind = "ONLINE" | "WHATSAPP" | "ADJUSTMENT";
export type CommissionStatus = "DUE" | "SETTLED" | "REVERSED" | "WAIVED";

export interface CommissionEntry {
  id: number;
  orderNumber: string | null;
  orderTotal: number;
  percent: number;
  amount: number;
  currency: string;
  kind: CommissionKind;
  status: CommissionStatus;
  createdAt: string;
  settledAt: string | null;
}

export interface Earnings {
  currency: string;
  percent: number;
  chargesWhatsappOrders: boolean;
  due: number;
  dueLimit: number;
  whatsappPaused: boolean;
  paidThisMonth: number;
  paidAllTime: number;
  salesThisMonth: number;
  owedToYou: number;
  providers: ProviderOption[];
  entries: CommissionEntry[];
  payments: PaymentView[];
}

// ── AI ──────────────────────────────────────────────────────────────────────────

export type Engine = "claude" | "openai" | "offline" | "none" | "demo";

export interface AiUsage {
  used: number;
  limit: number;
}

export interface ProductWriterResult {
  title: string;
  description: string;
  bullets: string[];
  caption: string;
  hashtags: string[];
  category: string | null;
  engine: Engine;
}

export interface ReplyDrafts {
  intent: string;
  drafts: { label: string; text: string }[];
  engine: Engine;
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface ChatReply {
  reply: string;
  suggestions: number[];
  engine: Engine;
}

export interface CoachInsight {
  title: string;
  detail: string;
  impact: "high" | "medium" | "low";
  kind: string;
}

export interface CoachReport {
  headline: string;
  summary: string;
  insights: CoachInsight[];
  actions: string[];
  stats: { label: string; value: string; trend: string | null }[];
  engine: Engine;
}

export interface BroadcastResult {
  message: string;
  short: string;
  engine: Engine;
}

// ── Admin ───────────────────────────────────────────────────────────────────────

export interface AdminOverview {
  users: number;
  stores: number;
  products: number;
  orders: number;
  commissionEarned: number;
  commissionDue: number;
  orderVolume: number;
  owedToSellers: number;
  currency: string;
  aiOnline: boolean;
  providers: ProviderOption[];
  demoPayments: boolean;
  commissionPercent: number;
  emailEnabled: boolean;
}

export interface SellerRow {
  storeId: number;
  userId: number;
  storeName: string;
  slug: string;
  email: string;
  whatsapp: string;
  currency: string;
  commissionDue: number;
  whatsappPaused: boolean;
  products: number;
  status: "ACTIVE" | "SUSPENDED";
  role: Role;
  createdAt: string;
  flutterwaveSubaccount: string | null;
  paystackSubaccount: string | null;
  stripeAccount: string | null;
  shopUrl: string;
}

export interface AdminPayment {
  reference: string;
  purpose: string;
  provider: string;
  status: string;
  amount: number;
  currency: string;
  storeName: string;
  storeSlug: string;
  payerEmail: string | null;
  settlement: string;
  platformFee: number | null;
  sellerAmount: number | null;
  createdAt: string;
  paidAt: string | null;
  note: string | null;
}

export interface PayoutRow {
  storeId: number;
  storeName: string;
  slug: string;
  whatsapp: string;
  email: string;
  owed: number;
  payments: number;
  currency: string;
}

// ── Ads ─────────────────────────────────────────────────────────────────────────

export type AdNetworkId = "meta" | "tiktok";
export type AdStatus = "DRAFT" | "LAUNCHING" | "IN_REVIEW" | "ACTIVE" | "PAUSED" | "REJECTED" | "ERROR" | "ENDED";
export type CallToAction = "SHOP_NOW" | "ORDER_NOW" | "LEARN_MORE" | "BUY_NOW";

export interface NetworkView {
  network: AdNetworkId;
  label: string;
  simulated: boolean;
  status: "DISCONNECTED" | "NEEDS_SETUP" | "CONNECTED" | "RECONNECT";
  accountName: string | null;
  currency: string | null;
  minDailyBudget: number | null;
  pageName: string | null;
  instagramUsername: string | null;
  identityName: string | null;
  tokenExpiresAt: string | null;
}

export interface OptionView {
  id: string;
  name: string;
  currency: string | null;
  minDailyBudget: number | null;
  linkedId: string | null;
  linkedName: string | null;
  type: string | null;
}

export interface AssetsView {
  adAccounts: OptionView[];
  pages: OptionView[];
  identities: OptionView[];
}

export interface SelectAccountInput {
  adAccountId: string;
  pageId?: string | null;
  identityId?: string | null;
}

export interface ConnectView {
  url: string;
}

export interface AdView {
  id: number;
  network: AdNetworkId;
  productId: number | null;
  productName: string | null;
  imageUrl: string | null;
  status: AdStatus;
  origin: "SELLER" | "AUTOPILOT";
  headline: string | null;
  primaryText: string | null;
  description: string | null;
  callToAction: CallToAction | null;
  dailyBudget: number;
  currency: string | null;
  countries: string[];
  ageMin: number | null;
  ageMax: number | null;
  endDate: string | null;
  reviewNote: string | null;
  lastError: string | null;
  aiReason: string | null;
  impressions: number;
  clicks: number;
  spend: number;
  visits: number;
  whatsappClicks: number;
  orders: number;
  revenue: number;
  ctr: number | null;
  cpc: number | null;
  createdAt: string;
  launchedAt: string | null;
  lastSyncedAt: string | null;
}

export interface LaunchInput {
  network: AdNetworkId;
  productId: number;
  headline: string;
  primaryText: string;
  description: string | null;
  callToAction: CallToAction;
  dailyBudget: number;
  days: number | null;
  countries: string[];
  ageMin: number;
  ageMax: number;
}

export interface AdCopyInput {
  productId: number;
  network: AdNetworkId;
  tone?: string;
  language?: string;
}

export interface AdVariant {
  angle: string;
  headline: string;
  primary_text: string;
  description: string | null;
  call_to_action: CallToAction;
}

export interface AdCopy {
  variants: AdVariant[];
  tips: string[];
  engine: Engine;
}

export interface AdSettingsView {
  autopilotEnabled: boolean;
  autoLaunch: boolean;
  networks: AdNetworkId[];
  dailyBudgetCap: number;
  perAdBudget: number;
  maxActiveAds: number;
  countries: string[];
  ageMin: number;
  ageMax: number;
  minCtr: number;
  maxCpc: number | null;
  fxRate: number | null;
  termsAccepted: boolean;
  lastRunAt: string | null;
  lastRunSummary: string | null;
}

export interface AdSettingsInput {
  autopilotEnabled: boolean;
  autoLaunch: boolean;
  networks: AdNetworkId[];
  dailyBudgetCap: number;
  perAdBudget: number;
  maxActiveAds: number;
  countries: string[];
  ageMin: number;
  ageMax: number;
  minCtr: number;
  maxCpc: number | null;
  fxRate: number | null;
  acceptTerms: boolean;
}

export interface AutopilotLogView {
  id: number;
  action: "LAUNCHED" | "SUGGESTED" | "PAUSED" | "BUDGET_UP" | "KEPT" | "SKIPPED" | "ERROR" | "INFO";
  message: string;
  adId: number | null;
  createdAt: string;
}

export interface AdsOverview {
  shopCurrency: string;
  maxDailyBudget: number | null;
  networks: NetworkView[];
  settings: AdSettingsView;
  ads: AdView[];
  activity: AutopilotLogView[];
}

export interface AdTotals {
  impressions: number;
  clicks: number;
  spend: number;
  visits: number;
  whatsappClicks: number;
  orders: number;
  revenue: number;
  ctr: number | null;
  cpc: number | null;
  roas: number | null;
  activeAds: number;
}

export interface AdStatDay {
  date: string;
  impressions: number;
  clicks: number;
  spend: number;
  orders: number;
  revenue: number;
}

export interface AdNetworkTotals {
  network: AdNetworkId;
  currency: string | null;
  impressions: number;
  clicks: number;
  spend: number;
  orders: number;
  revenue: number;
}

export interface AdStats {
  days: number;
  shopCurrency: string;
  spendCurrency: string;
  totals: AdTotals;
  daily: AdStatDay[];
  byNetwork: AdNetworkTotals[];
}

export interface AutopilotRun {
  summary: string;
  actions: AutopilotLogView[];
}

export interface TrackInput {
  ref: string;
  event: "visit" | "whatsapp";
}
