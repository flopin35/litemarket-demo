# Customizing and rebranding

## Name, logo and colours

| What | Where |
|---|---|
| Brand name (website) | `web/src/config.ts` → `BRAND`, and `<title>`/meta tags in `web/index.html` |
| Brand name (emails, payment pages) | `BRAND_NAME` in `.env` |
| Colours | `web/src/index.css` → the `--color-brand-*` scale in `@theme`. Change these 11 values and the whole site follows. |
| Logo | `Logo` in `web/src/components/bits.tsx` and `web/public/favicon.svg` |
| Font | Google Fonts link in `web/index.html` and `--font-sans` in `index.css` |
| Landing page text | `web/src/pages/landing/Landing.tsx` |

## Commission and limits

How you earn is set with environment variables (defaults in `backend/src/main/resources/application.yml` under `app.commission`):

| Variable | Default | Meaning |
|---|---|---|
| `COMMISSION_PERCENT` | `5` | Your share of every sale. `0` = a free platform |
| `COMMISSION_ON_WHATSAPP_ORDERS` | `true` | Also charge on WhatsApp / hand-added orders (sellers pay it from Earnings) |
| `COMMISSION_DUE_LIMIT` | `200` | Unpaid commission at which a shop's WhatsApp checkout pauses. `0` = never |
| `AI_MONTHLY_CREDITS` | `300` | AI credits per shop per month |
| `PRODUCT_LIMIT` | `0` | Max products per shop. `0` = unlimited |

The pricing section on the landing page and the seller's Earnings page read these from the API, so they update by themselves (the fallback in `Landing.tsx` is only used if the API is unreachable). See [PAYMENTS.md](PAYMENTS.md#commission-how-you-earn) for how commission is collected.

## Ads

Ad networks, budget caps and how often the autopilot runs are set in `.env` (`ADS_*`, `META_*`, `TIKTOK_*`). The autopilot's pause/boost rules are plain Java in `backend/src/main/java/com/litemarket/ads/AutopilotRules.java`; the product scoring and ad writer are in `ai-service/app/ads.py`. See [ADS.md](ADS.md).

## Currency and country

- `DEFAULT_CURRENCY` is the currency new shops start with (default `GHS`); commission is charged in each shop's own currency.
- Each shop picks its own currency in **My shop** (GHS, NGN, KES, ZAR, UGX, XOF, USD, EUR, GBP). Add more in `web/src/lib/constants.ts`. Make sure your payment gateway supports it.
- `DEFAULT_COUNTRY_CODE` turns local phone numbers into WhatsApp numbers (`024 123 4567` → `233241234567`).

## Product categories and AI languages

`web/src/lib/constants.ts` holds the category list, the AI tones and languages. If you add a category, also add keywords for it in `ai-service/app/offline.py` (`CATEGORY_KEYWORDS` and `COPY`) so the built-in engine recognises it.

## Emails

Email texts are short strings in `AuthService` (welcome, password reset), `OrderService` (new order) and `AdminService` (commission payment received). Set `MAIL_HOST`, `MAIL_PORT`, `MAIL_USER`, `MAIL_PASSWORD` and `MAIL_FROM` to send them (any SMTP provider: Brevo, Mailgun, Gmail app password…).

## Demo data

- Server: `backend/src/main/java/com/litemarket/config/DemoDataSeeder.java`
- Server ads demo: `backend/src/main/java/com/litemarket/ads/AdsDemoSeeder.java` (needs `ADS_DEMO_MODE=true`)
- Browser demo mode: `web/src/lib/demo/mockApi.ts` (`seed()` and `seedAds()`)

## Adding a page to the seller dashboard

1. Create `web/src/pages/app/MyPage.tsx` (copy a small page such as `Earnings.tsx`).
2. Add it to the `lazy` imports, the `nav` list and the `page` switch in `web/src/pages/app/AppShell.tsx`.
3. Add the API endpoint in a controller under `backend/src/main/java/com/litemarket/`.
