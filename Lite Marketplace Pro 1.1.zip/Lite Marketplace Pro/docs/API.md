# API reference

Base path: `/api`. JSON in and out. Errors look like `{"error": "CODE", "message": "Readable text", "fields": {...}}`.

Authenticated routes need `Authorization: Bearer <accessToken>`. Access tokens last 15 minutes; get a new one with `POST /api/auth/refresh` (uses the HttpOnly refresh cookie).

## Public

| Method | Path | Body / notes |
|---|---|---|
| GET | `/api/config` | Brand, commission %, AI credits, product limit, payment options, which ad networks are on |
| GET | `/api/health` | `{"status":"ok"}` |
| POST | `/api/auth/signup` | `{email, password, storeName, whatsapp, fullName?}` → `{accessToken, expiresIn, me}` + cookie |
| POST | `/api/auth/login` | `{email, password}` |
| POST | `/api/auth/refresh` | Cookie only. Rotates the refresh token |
| POST | `/api/auth/logout` | Revokes the refresh token |
| POST | `/api/auth/forgot-password` | `{email}`. Always succeeds |
| POST | `/api/auth/reset-password` | `{token, password}` |
| GET | `/api/shops/{slug}` | Public shop: products, categories, payment options |
| POST | `/api/shops/{slug}/orders` | WhatsApp order: `{items:[{productId, quantity}], customer:{name, phone, email?, address, note?}, ref?}` → `{orderNumber, total, currency, whatsappUrl}`. `ref` is the ad the customer came from (`ad42`). `400` while the shop's WhatsApp checkout is paused for unpaid commission |
| POST | `/api/shops/{slug}/checkout` | Same body + `provider` → `{reference, checkoutUrl}` |
| POST | `/api/shops/{slug}/track` | `{ref: "ad42", event: "visit"\|"whatsapp"}` → `204`. Counts shop visits and WhatsApp taps from an ad (rate-limited) |
| POST | `/api/shops/{slug}/assistant` | `{messages:[{role, content}], cartProductIds?}` → `{reply, suggestions, engine}` |
| POST | `/api/payments/verify` | `{reference}` → payment status (asks the gateway) |
| POST | `/api/payments/demo/{reference}/complete` | Demo mode only |
| POST | `/api/webhooks/{paystack\|flutterwave\|stripe}` | Raw provider webhooks (signature checked) |
| GET | `/api/ads/oauth/{meta\|tiktok}/callback` | Facebook / TikTok send the seller back here after sign-in (signed `state`); redirects to `/app/ads` |

## Seller (logged in)

| Method | Path | Notes |
|---|---|---|
| GET | `/api/me` | User, shop and `account` (commission %, commission due, AI credits, product limit) |
| PUT | `/api/me/password` | `{currentPassword, newPassword}` |
| GET / PUT | `/api/store` | Shop settings |
| GET / POST | `/api/products` | List / create (`400` once `PRODUCT_LIMIT` is reached, if set) |
| PUT / DELETE | `/api/products/{id}` | |
| POST | `/api/uploads` | multipart `file` (JPEG/PNG/WebP/GIF, 5 MB) → `{url}` |
| GET | `/api/orders?status=NEW` | |
| POST | `/api/orders` | Manual order |
| GET / PUT | `/api/orders/{id}` | |
| PATCH | `/api/orders/{id}/status` | `{status}`: NEW, PAID, DELIVERED, CANCELLED |
| GET | `/api/dashboard` | Totals, 7/30-day series, best sellers, recent orders |
| GET | `/api/earnings` | Commission due, paid this month / all time, sales this month, money owed to the seller, commission history, commission payments |
| POST | `/api/earnings/pay` | `{provider}` → `{reference, checkoutUrl}` to pay everything due |
| GET | `/api/ai/usage` | `{used, limit}` |
| POST | `/api/ai/product-writer` | `{name, category?, price?, notes?, tone?, language?, imageUrl?}` |
| POST | `/api/ai/reply-drafts` | `{message, orderId?, tone?, language?}` |
| POST | `/api/ai/broadcast` | `{goal?, productIds?, tone?, language?}` |
| POST | `/api/ai/coach` | |

AI routes return `402 AI_CREDITS` when the month's credits are used up.

### Ads (the seller's own; never visible to other sellers or the admin)

| Method | Path | Notes |
|---|---|---|
| GET | `/api/ads` | Networks (connection status), autopilot settings, all ads with their numbers, autopilot activity |
| GET | `/api/ads/stats?days=7\|30\|90` | Totals (spend, views, clicks, CTR, CPC, visits, WhatsApp taps, orders, sales, ROAS), a daily series and per-network totals |
| POST | `/api/ads/sync` | Pull the latest results from the networks now |
| POST | `/api/ads/accounts/{meta\|tiktok}/connect` | → `{url}`: the Facebook / TikTok sign-in page (demo network: connects straight away) |
| GET | `/api/ads/accounts/{network}/options?adAccountId=` | Ad accounts, Facebook Pages (+ linked Instagram) or TikTok identities to choose from |
| PUT | `/api/ads/accounts/{network}` | `{adAccountId, pageId?, identityId?}` |
| DELETE | `/api/ads/accounts/{network}` | Disconnect |
| POST | `/api/ads/copy` | `{productId, network, tone?, language?}` → three ad versions (uses one AI credit) |
| POST | `/api/ads` | `{network, productId, headline, primaryText, description?, callToAction, dailyBudget, days?, countries, ageMin, ageMax}` → the ad (`IN_REVIEW`, or `ERROR` with the reason) |
| POST | `/api/ads/{id}/approve` | Launch an autopilot suggestion (or retry a failed ad) |
| POST | `/api/ads/{id}/pause` · `/resume` · `/end` | `end` on a suggestion discards it |
| PUT | `/api/ads/{id}/budget` | `{dailyBudget}` |
| PUT | `/api/ads/settings` | Autopilot: `{autopilotEnabled, autoLaunch, networks, dailyBudgetCap, perAdBudget, maxActiveAds, countries, ageMin, ageMax, minCtr, maxCpc?, fxRate?, acceptTerms}` |
| POST | `/api/ads/autopilot/run` | Run the autopilot now → `{summary, actions}` |

## Admin (role ADMIN)

| Method | Path | Notes |
|---|---|---|
| GET | `/api/admin/overview` | Totals and system status |
| GET | `/api/admin/sellers?q=` | |
| POST | `/api/admin/sellers/{storeId}/commission/paid` | The seller paid their commission directly: clears what they owe |
| POST | `/api/admin/sellers/{storeId}/status` | `{status: ACTIVE\|SUSPENDED}` |
| PUT | `/api/admin/sellers/{storeId}/split` | `{paystackSubaccount, flutterwaveSubaccount, stripeAccount}` |
| GET | `/api/admin/payments` | Latest 200 |
| GET | `/api/admin/payouts` | Money owed per shop |
| POST | `/api/admin/payouts/{storeId}/paid` | Mark as paid out |
