# Ads: Facebook, Instagram & TikTok

Sellers can advertise their products on **Facebook & Instagram** (Meta Marketing API) and **TikTok** (TikTok API for Business) from the **Ads** page, and let an **AI autopilot** run their ads for them. Every ad links straight to the product in the seller's shop, so customers land ready to order on WhatsApp or pay online.

- Ads are paid from the **seller's own ad account** (their card or balance at Meta/TikTok). The platform never handles ad money.
- Ad accounts and ad results are visible **only to that seller**. The admin panel never shows them.
- With `ADS_DEMO_MODE=true` and no keys, a **simulated network** is used: connecting is instant, ads "pass review" after a minute and results are generated from the budget. Nothing is published and nothing is charged. This is what the live demo uses.

## What sellers get

| | |
|---|---|
| **Connect** | "Connect Facebook & Instagram" / "Connect TikTok" opens the network's sign-in page. They pick their ad account and the Facebook Page (its linked Instagram account is used for Instagram) or TikTok account the ads come from. If there's only one of each, it's picked automatically. |
| **New ad** | Pick a product, press **Write with AI** for three versions of the text (Benefit, Price, Popular), set a daily budget, run time, countries and ages, check the preview, launch. |
| **AI autopilot** | Picks the products most likely to sell, writes and launches ads (or leaves them as suggestions to approve), pauses ads that don't work and gives winners more budget, within the seller's daily limit. |
| **Results** | Spend, views, clicks, click rate, cost per click, shop visits, WhatsApp chats, orders and sales from ads, return on ad spend, a daily chart, per-network totals and a timeline of what the autopilot did. |

## How an ad is built

| | Meta | TikTok |
|---|---|---|
| Campaign | Traffic objective (`OUTCOME_TRAFFIC`), no special ad category | Traffic objective |
| Budget | Daily budget on the ad set, in the ad account's currency | Daily budget on the ad group (minimum about **20 USD/day**, `TIKTOK_MIN_DAILY_BUDGET`) |
| Audience | Countries, ages 18–65, Advantage audience off | Countries (GeoNames IDs), age groups |
| Placements | Facebook and Instagram feeds, Stories, Reels (Instagram only when the Page has a linked Instagram account) | TikTok |
| Creative | Link ad: product photo, main text, headline, description, button | Photo carousel: the product photo plus up to 4 other in-stock product photos, with music, from the seller's TikTok account |
| Link | `https://your-site/s/{shop}?p={productId}&ref=ad{id}&utm_source=facebook\|tiktok&utm_medium=paid_social&utm_campaign=lm-ad{id}` | same |

The `ref` in the link is remembered by the shop for 7 days. Visits and WhatsApp taps are counted (`POST /api/shops/{slug}/track`) and orders carry the ref, so they show as **Ad** orders and count towards that ad's results.

New ads start **in review** at the network. Results are pulled every 2 hours (`ADS_SYNC_CRON`) or when the seller presses **Update results**.

## The AI autopilot

Runs every 6 hours (`ADS_AUTOPILOT_CRON`) for shops that turned it on, or when the seller presses **Run now**. Turning it on requires the seller to confirm that it may spend up to their daily limit.

1. **Judges its own running ads** (plain rules in `AutopilotRules.java`, unit-tested):

   | Rule | Default | Action |
   |---|---|---|
   | Click rate below the seller's target after 1,500 views | 0.8% | Pause |
   | Cost per click above the seller's limit (after 20 clicks) | off | Pause |
   | 4 days of budget spent without an order | – | Pause |
   | 2+ orders, 2+ days running, and 2x return on ad spend (or a high click rate when ROAS can't be computed) | – | Budget +20%, never above the daily limit or `ADS_MAX_DAILY_BUDGET` |

2. **Fills free slots** (up to "ads at the same time"): products are scored in code from sales in the last 7 and 30 days, featured status, stock and earlier ad results (nearly sold-out products are skipped, and products it paused are left alone for 14 days). The AI chooses among the best and writes the ads. With **Launch new ads by itself** off, they wait as suggestions for the seller to approve.

The autopilot only manages ads it created; ads made by the seller are never paused or changed by it. It never starts an ad that would push the total daily budget of its running ads over the seller's limit.

## Setting up Meta (Facebook & Instagram)

1. Go to [developers.facebook.com](https://developers.facebook.com) → **My Apps → Create app**, type **Business**, connected to your business portfolio.
2. Add the **Marketing API** and **Facebook Login for Business** products.
3. In Facebook Login settings, add the **Valid OAuth Redirect URI**: `https://YOUR-DOMAIN/api/ads/oauth/meta/callback` (must match `WEB_BASE_URL`).
4. **App settings → Basic**: copy the App ID and App Secret into `META_APP_ID` and `META_APP_SECRET`. Restart the API: the **Connect Facebook & Instagram** button now opens Facebook.
5. The app asks sellers for: `ads_management`, `ads_read`, `business_management`, `pages_show_list`, `pages_read_engagement`, `instagram_basic`.
6. **Going live for other people**: while the app is in development, only people with a role on the app (admins, developers, testers) can connect. To let any seller connect, complete **Business Verification** and request **Advanced Access** for the permissions above through **App Review** (Meta asks for a screen recording of the flow and a privacy policy URL). Requirements change from time to time, so follow what the App Review screen asks for.

Notes:
- Sign-ins last about **60 days** (long-lived token). The Ads page reminds sellers to reconnect in the last week; reconnecting keeps their choices.
- Meta ad accounts can't use every currency (Ghanaian cedi accounts aren't offered, for example), so many sellers will have a **USD** account. Results then come back in USD; the seller can enter the exchange rate under **Autopilot → Advanced rules** to see return on ad spend in their shop's currency.
- Sellers need a **Facebook Page** for their shop. If an Instagram professional account is linked to it, Instagram placements use it.
- `META_API_VERSION` (default `v26.0`): Meta retires API versions about two years after release. Update it when Meta announces a newer one; the code uses stable fields.

## Setting up TikTok

1. Create a developer account at [business-api.tiktok.com](https://business-api.tiktok.com) and **create an app**.
2. Set the **Advertiser redirect URL** to `https://YOUR-DOMAIN/api/ads/oauth/tiktok/callback`.
3. Request the scopes for ad account management, ads management, reporting, creative/file management and identity (TikTok groups them under "Ads Management", "Reporting", "Creative Management" and "Identity" in the app form). Submit the app for review.
4. Copy the App ID and Secret into `TIKTOK_APP_ID` and `TIKTOK_APP_SECRET`, then restart the API.

Notes:
- The minimum ad group budget is about **20 USD a day** (`TIKTOK_MIN_DAILY_BUDGET`). The autopilot falls back to Facebook & Instagram when the seller's limit is too small for TikTok.
- Photo ads on TikTok are carousels: they need **2 or more photos** (the product plus other in-stock products from the shop) and **music**. The music is picked from TikTok's library automatically, or set one with `TIKTOK_MUSIC_ID`.
- New TikTok ads must come from the seller's **own TikTok account**, linked to their ad account in TikTok Ads Manager (**Assets → Identities**).

## Settings

| Variable | Default | Meaning |
|---|---|---|
| `ADS_DEMO_MODE` | `true` | Simulated network for any network without keys. **Turn off in production.** |
| `ADS_MAX_DAILY_BUDGET` | `100` | Most any single ad may spend per day (ad account currency) |
| `ADS_TOKEN_KEY` | derived from `JWT_SECRET` | Key that encrypts sellers' ad tokens (AES-256-GCM). Set your own: `openssl rand -base64 32` |
| `ADS_SYNC_CRON` | every 2 h | When results are pulled |
| `ADS_AUTOPILOT_CRON` | every 6 h | When the autopilot runs |
| `META_APP_ID`, `META_APP_SECRET`, `META_API_VERSION` | – / – / `v26.0` | Meta app |
| `TIKTOK_APP_ID`, `TIKTOK_APP_SECRET`, `TIKTOK_MIN_DAILY_BUDGET`, `TIKTOK_MUSIC_ID` | – / – / `20` / auto | TikTok app |

Changing `ADS_TOKEN_KEY` (or `JWT_SECRET` when it's empty) makes stored tokens unreadable: sellers just reconnect.

## Rules for advertisers

Ads are reviewed by Meta and TikTok against their advertising policies, and a rejected ad shows the reason on its card. Ads are created **without a special ad category**, so sellers must not use them for housing, jobs, credit or financial products, or social and political issues; those need a different setup. Tell your sellers this in your terms.

## Troubleshooting

| What you see | Why |
|---|---|
| "Connect … first" / "Finish setting up …" | The seller hasn't chosen an ad account (and Page / TikTok account) yet. |
| "Your … connection expired. Reconnect it first." | The token expired or was revoked (Meta error 190, TikTok 40105). Press Reconnect. |
| The Ads page shows "Demo ad network" | `ADS_DEMO_MODE=true` and `META_APP_ID`/`TIKTOK_APP_ID` isn't set, so the simulated network is used. |
| "Upload a photo for … first" | Real networks need a product photo. |
| An ad stays "In review" | Normal for up to a day at the network. |
| Sales from ads stay at 0 | Customers must arrive through the ad link; orders placed later in another browser can't be matched. |
