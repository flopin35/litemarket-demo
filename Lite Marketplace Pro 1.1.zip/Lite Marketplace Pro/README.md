# Lite Marketplace

**A complete WhatsApp-commerce platform: online shops, WhatsApp orders, Mobile Money & card payments, Facebook/Instagram/TikTok ads on AI autopilot, and an AI sales assistant.**

Sellers sign up, add products and get a beautiful shop at `yourdomain.com/s/their-shop`. Customers order on WhatsApp or pay online with Paystack, Flutterwave or Stripe. An AI assistant writes product listings (even from a photo), chats with shoppers, drafts replies to customers, writes broadcasts and coaches sellers on what to do next. Sellers can run Facebook, Instagram and TikTok ads that an AI autopilot manages for them, and see exactly which ads bring orders. You run it as a marketplace: sellers join free and you earn a commission on every sale.

| | |
|---|---|
| **Website** | React 19, TypeScript, Tailwind CSS 4, Vite. Animated, mobile-first, dark mode. |
| **API** | Java 21, Spring Boot 3.5, Spring Security, JPA. PostgreSQL in production, H2 for zero-setup local runs. |
| **AI service** | Python 3.11+, Flask, Pydantic. Claude (Anthropic), OpenAI or any OpenAI-compatible model, plus a built-in engine that works with no API key. |
| **Payments** | Paystack, Flutterwave, Stripe, with signed webhooks, split payments, commission tracking and a payouts ledger. |
| **Ads** | Meta Marketing API (Facebook & Instagram) and TikTok Marketing API, with a built-in simulated network for demos. |
| **Deploy** | One `docker compose up`. Or deploy the website alone in demo mode to Netlify for a free live demo. |

---

## Contents

- [Features](#features)
- [Quick start](#quick-start)
- [Demo accounts](#demo-accounts)
- [How it fits together](#how-it-fits-together)
- [Project structure](#project-structure)
- [Tests](#tests)
- [Security](#security)
- [Documentation](#documentation)

---

## Features

### For sellers
- **Shop in two minutes**: sign up with a shop name and WhatsApp number; the shop link is live immediately.
- **Products** with photo upload (drag & drop), categories, stock counts (auto-decrease on paid orders), "featured" and "sold out".
- **Orders inbox**: every WhatsApp and online order is saved automatically; status flow New → Paid → Delivered (or Cancelled, which puts stock back); add phone/walk-in orders by hand.
- **Dashboard**: total sales, this week, orders, average order, animated 7/30-day chart, best sellers, latest orders, ad results, commission and AI credits.
- **Shop branding**: logo, brand colour, about text, custom shop address, live preview, one-tap WhatsApp share.
- **Earnings**: no monthly fee. The platform's commission is taken automatically on online payments; on WhatsApp orders it adds up on the Earnings page and the seller pays it by MoMo or card in one tap. Cancelled orders are never charged.

### Ads on Facebook, Instagram & TikTok
- **Connect once**: sellers sign in with Facebook or TikTok and pick their ad account and Page / TikTok account. Tokens are encrypted at rest.
- **Create an ad in a minute**: pick a product, let the AI write three versions of the text, set a daily budget and audience, see a live preview, launch.
- **AI autopilot**: every few hours it picks the products most likely to sell (recent sales, stock, past ad results), writes the ads and launches them (or leaves them for approval). It pauses ads with a low click rate, a high cost per click or no orders after 4 days of budget, and gives winners 20% more budget. It never spends more than the seller's daily limit and only touches ads it created.
- **Ad results, for the seller only**: spend, views, clicks, click rate, WhatsApp chats, shop visits, orders and sales from ads, return on ad spend, a daily chart and a timeline of what the autopilot did. Ad links carry a reference, so orders from ads are tagged automatically.
- **Demo network**: with `ADS_DEMO_MODE=true` and no keys, a simulated network gives believable results so everything can be tried without an ad account. See [docs/ADS.md](docs/ADS.md).

### AI assistant (Python service)
- **Product writer**: title, description, bullet points, WhatsApp/Instagram caption and hashtags, in 11 languages and 4 tones. Reads the product **photo** with vision models.
- **Shopper chat** on every shop: answers questions, finds products within a budget, suggests add-ons, with "Add to cart" buttons in the chat.
- **Reply helper**: paste a customer's message, get three replies (Quick, Friendly, Detailed) that use the order's details, and send with one tap.
- **Sales coach**: week-over-week trend, best sellers, items to restock, slow movers, waiting orders, best weekday, pricing hints, with a to-do list. All numbers are computed in code; the model only explains them.
- **Broadcast writer**: WhatsApp broadcast + Status text featuring your products and prices.
- **Ad writer & autopilot planner**: three ad versions per product (Benefit, Price, Popular), and product scoring for the autopilot done in code; the model only picks among the best and writes the words.
- **AI credits** per shop each month (`AI_MONTHLY_CREDITS`), refunded automatically if the AI call fails.
- **Works without an API key**: a rule-based engine answers every feature, and takes over if the AI provider is down.

### For customers
- Fast, animated storefront: search, categories, "Popular right now", product details, cart drawer, low-stock badges.
- **Checkout**: pay now (Paystack, Flutterwave, Stripe) or **send the order on WhatsApp** as a neat, numbered message.
- Thank-you page that confirms the payment with the provider and links straight to the seller's WhatsApp.

### For you (the platform owner)
- **Admin panel**: accounts, shops, commission earned, commission still to collect, order volume, money owed to sellers, system status checks.
- **Sellers**: search, see what each owes, mark commission paid by hand (cash/MoMo paid directly), suspend/activate, set split-payment sub-accounts.
- **Payments log** and **Payouts**: what the platform collected for each seller, and "mark as paid".
- **Commission** on every sale (`COMMISSION_PERCENT`, default 5%): kept automatically on online payments (Paystack/Flutterwave sub-accounts, Stripe Connect, or collected by you), billed to the seller for WhatsApp orders. If unpaid commission reaches `COMMISSION_DUE_LIMIT`, that shop's WhatsApp checkout pauses until it is paid (online payment keeps working).
- **Privacy**: sellers' ad accounts and ad results are visible only to that seller.
- **White-label**: brand name, colours, commission and limits come from config. See [docs/CUSTOMIZE.md](docs/CUSTOMIZE.md).

### Quality details
- Animations without heavy libraries: scroll reveals, count-ups, animated charts, page transitions, fly-to-cart, toasts, skeleton loaders. Respects "reduce motion".
- Dark mode, mobile bottom navigation, accessible focus states, readable error messages.
- **Demo mode**: the whole website runs in the browser with sample data and simulated payments, so you can host a free live demo.

---

## Quick start

### Option A: everything with Docker (recommended)

Needs [Docker Desktop](https://www.docker.com/products/docker-desktop/).

```bash
cp .env.example .env          # Windows: copy .env.example .env
docker compose up --build
```

Open **http://localhost:8080**. The first start downloads dependencies and takes a few minutes.

### Option B: just look at it (no backend)

Needs [Node.js 20.19+](https://nodejs.org).

```bash
cd web
npm install
npm run dev -- --mode demo     # http://localhost:5173, sample data, simulated payments
```

### Option C: the ready-made demo site

The `demo-site` folder delivered with this project is a finished demo build. Drag it onto [Netlify Drop](https://app.netlify.com/drop) to get a free public demo link in seconds. Rebuild it any time with `cd web && npm run build:demo`.

### Option D: run each part yourself

See [docs/SETUP.md](docs/SETUP.md) (Java 21 + Maven, Python 3.11+, Node 20.19+).

---

## Demo accounts

Created automatically on an empty database (`DEMO_SEED=true`):

| Role | Email | Password |
|---|---|---|
| Admin | `admin@litemarket.dev` | `admin12345` (set `ADMIN_EMAIL` / `ADMIN_PASSWORD`) |
| Seller (Ama's Kitchen) | `demo@litemarket.dev` | `demo12345` |

Demo shop: **/s/amas-kitchen**. With `PAYMENTS_DEMO_MODE=true`, a "Demo payment" option simulates paying so you can test checkout and commission payments end to end. With `ADS_DEMO_MODE=true`, Ama's Kitchen also has a connected demo ad account with ads, results and autopilot history. **Turn the demo modes and the demo seed off in production.**

---

## How it fits together

```
 Browser ──► web (React, nginx)
               │  /api, /uploads
               ▼
             api (Java, Spring Boot) ──► PostgreSQL
               │        ▲
               │        └── webhooks ◄── Paystack / Flutterwave / Stripe
               │ X-Internal-Key
               ▼
             ai (Python, Flask) ──► Claude / OpenAI (optional)

             api ──► Meta Marketing API / TikTok Marketing API (sellers' own ad accounts)
```

- The website only talks to the Java API. The AI service is private: provider keys never reach the browser.
- A payment only counts after the API **asks the provider directly** (server to server) and checks the amount and currency. Webhooks are verified with each provider's signature, and an atomic database update makes sure an order or commission payment is counted exactly once even if the redirect and the webhook arrive together.

---

## Project structure

```
backend/        Java 21 + Spring Boot API
  src/main/java/com/litemarket/
    auth/       sign up, log in, JWT, refresh tokens, password reset
    store/ product/ order/ shop/    shops, products, orders, public storefront
    payment/    PaymentService, webhooks, gateway/ (Paystack, Flutterwave, Stripe, Demo)
    ai/         calls the AI service and meters AI credits
    commission/ commission ledger, seller earnings
    ads/        ad accounts, ads, results sync, AI autopilot; network/ (Meta, TikTok, simulated)
    admin/      admin panel endpoints
    upload/ mail/ config/ common/
  src/test/     unit tests + a full end-to-end Spring test
ai-service/     Python AI service (Flask)
  app/          llm.py (providers), features.py, offline.py (built-in engine), analytics.py, ads.py, prompts.py
  tests/
web/            React website
  src/pages/    landing/, auth/, app/ (dashboard), shop/ (storefront), pay/
  src/components/  UI kit, animations, charts
  src/lib/      API client, auth, router, cart, demo/ (in-browser mock API)
docs/           setup, payments, AI, deploy, customize, API, selling guide
screenshots/    26 ready-made screenshots for your sales listing
docker-compose.yml
.env.example
```

---

## Tests

```bash
cd backend && mvn test                                   # Java: 50 unit tests + full journey on an in-memory DB
cd ai-service && python -m unittest discover -s tests    # Python: 32 tests, providers mocked
cd web && npm run typecheck && npm run build             # TypeScript strict mode + production build
```

The Java suite includes `FullFlowTest`, which boots the real application and walks the main journey: sign up → add products → customer orders on WhatsApp → customer pays online → stock goes down → commission is recorded and paid → seller connects the demo ad network, launches, pauses and resumes an ad → a shopper arrives from the ad and orders (the order is tagged) → the autopilot runs → admin endpoints, and one seller can never see another's ads. Payment gateway and ad network tests check request building, response parsing and webhook signatures for every provider (and the Meta/TikTok request flow) without calling the internet.

---

## Security

- Passwords hashed with **BCrypt**. Short-lived **JWT** access tokens (15 min) in memory; refresh tokens are random, stored as SHA-256 hashes, kept in an **HttpOnly, SameSite** cookie and **rotated** on every use. Reusing an old refresh token ends all of that user's sessions.
- Rate limits on login, sign-up, password reset, checkout, uploads and the AI chat.
- Uploads are checked by their file signature (JPEG/PNG/WebP/GIF only, 5 MB max) and saved under random names.
- Prices always come from the database, never from the browser. Payments are verified with the provider, amount and currency included.
- Webhook signatures: Paystack HMAC-SHA512, Flutterwave secret hash (and HMAC-SHA256), Stripe HMAC-SHA256 with timestamp tolerance.
- Admin routes are role-protected; the public shop API never exposes emails, keys or commission details.
- Ad-account tokens are encrypted (AES-GCM) in the database, the Facebook/TikTok sign-in uses a signed, expiring `state`, and the autopilot can never exceed the seller's daily limit or `ADS_MAX_DAILY_BUDGET`.

Before going live, follow the checklist in [docs/DEPLOY.md](docs/DEPLOY.md#go-live-checklist).

---

## Documentation

| Guide | What's in it |
|---|---|
| [docs/SETUP.md](docs/SETUP.md) | Run each part locally (Windows, macOS, Linux) |
| [docs/PAYMENTS.md](docs/PAYMENTS.md) | Paystack, Flutterwave and Stripe keys, webhooks, test cards, split payments, commission |
| [docs/ADS.md](docs/ADS.md) | Facebook/Instagram and TikTok ads: app setup, permissions, limits, the autopilot rules |
| [docs/AI.md](docs/AI.md) | Claude/OpenAI setup, models, credits, the built-in engine, editing prompts |
| [docs/DEPLOY.md](docs/DEPLOY.md) | Deploy to a VPS with HTTPS, free demo on Netlify, go-live checklist |
| [docs/CUSTOMIZE.md](docs/CUSTOMIZE.md) | Rebrand, change the commission and limits, currencies, add a payment gateway |
| [docs/API.md](docs/API.md) | Every endpoint |
| [docs/SELLING.md](docs/SELLING.md) | How to package, demo and sell this template |

---

Originally created by **Wilson Makafui** as Lite Marketplace (HTML + Firebase, then Plain), rebuilt as a full-stack platform.
See [LICENSE.md](LICENSE.md).
