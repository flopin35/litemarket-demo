package com.litemarket.payment;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.Instant;

public final class PaymentDtos {

    private PaymentDtos() {}

    public record VerifyRequest(@NotBlank @Size(max = 60) String reference) {}

    public record CheckoutView(String reference, String checkoutUrl) {}

    public record PaymentView(
            String reference,
            String purpose,
            String provider,
            String status,
            BigDecimal amount,
            String currency,
            String note,
            Instant createdAt,
            Instant paidAt) {}

    /** What the callback / thank-you page shows after the gateway sends the customer back. */
    public record PaymentStatusView(
            String reference,
            String status,
            String purpose,
            String provider,
            BigDecimal amount,
            String currency,
            String orderNumber,
            String storeName,
            String storeSlug,
            String whatsappUrl,
            String message) {}
}
