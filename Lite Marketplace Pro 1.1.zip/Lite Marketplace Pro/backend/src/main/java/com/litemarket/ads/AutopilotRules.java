package com.litemarket.ads;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * The autopilot's decisions about running ads, as plain rules with no framework dependencies
 * (unit-tested in AutopilotRulesTest). The AI picks products and writes the ads; these rules decide
 * what to pause and what to give more budget, so money decisions are predictable and explainable.
 */
public final class AutopilotRules {

    /** Views an ad needs before its click-through rate is judged. */
    public static final long MIN_IMPRESSIONS = 1500;
    /** Clicks an ad needs before its cost per click is judged. */
    public static final long MIN_CLICKS_FOR_CPC = 20;

    public enum Verdict { KEEP, PAUSE, BUDGET_UP }

    /**
     * One ad's numbers. revenueInAdCurrency is sales converted to the ad account's currency (null when we can't
     * convert), so return on ad spend can be judged.
     */
    public record Performance(long impressions, long clicks, BigDecimal spend, long orders,
                              BigDecimal revenueInAdCurrency, BigDecimal dailyBudget, long daysRunning) {}

    public record Decision(Verdict verdict, String reason, BigDecimal newBudget) {}

    private AutopilotRules() {}

    public static Decision judge(Performance p, BigDecimal minCtrPercent, BigDecimal maxCpc, BigDecimal maxBudget,
                                 String currency) {
        double ctr = p.impressions() > 0 ? p.clicks() * 100.0 / p.impressions() : 0;
        BigDecimal spend = p.spend() == null ? BigDecimal.ZERO : p.spend();
        BigDecimal budget = p.dailyBudget() == null ? BigDecimal.ZERO : p.dailyBudget();
        double minCtr = minCtrPercent == null ? 0 : minCtrPercent.doubleValue();

        if (p.impressions() >= MIN_IMPRESSIONS && ctr < minCtr) {
            return new Decision(Verdict.PAUSE, String.format(
                    "Only %.2f%% of the %d people who saw it clicked (your target is %.2f%%).",
                    ctr, p.impressions(), minCtr), null);
        }
        if (maxCpc != null && maxCpc.signum() > 0 && p.clicks() >= MIN_CLICKS_FOR_CPC) {
            BigDecimal cpc = spend.divide(BigDecimal.valueOf(p.clicks()), 2, RoundingMode.HALF_UP);
            if (cpc.compareTo(maxCpc) > 0) {
                return new Decision(Verdict.PAUSE, "Each click cost " + cpc.toPlainString() + " " + currency
                        + ", above your limit of " + maxCpc.toPlainString() + ".", null);
            }
        }
        if (budget.signum() > 0 && p.orders() == 0 && spend.compareTo(budget.multiply(BigDecimal.valueOf(4))) >= 0) {
            return new Decision(Verdict.PAUSE, "Spent " + spend.setScale(2, RoundingMode.HALF_UP).toPlainString() + " "
                    + currency + " (4 days of budget) without an order.", null);
        }

        Double roas = p.revenueInAdCurrency() != null && spend.signum() > 0
                ? p.revenueInAdCurrency().divide(spend, 4, RoundingMode.HALF_UP).doubleValue() : null;
        boolean winner = p.orders() >= 2 && p.daysRunning() >= 2
                && (roas != null ? roas >= 2.0 : ctr >= Math.max(1.0, minCtr * 2));
        if (winner && maxBudget != null) {
            BigDecimal raised = budget.multiply(new BigDecimal("1.2")).setScale(2, RoundingMode.HALF_UP);
            if (raised.compareTo(maxBudget) > 0) raised = maxBudget.setScale(2, RoundingMode.HALF_UP);
            if (raised.compareTo(budget) > 0) {
                String why = roas != null
                        ? String.format("It brought %d orders, %.1fx what it cost.", p.orders(), roas)
                        : String.format("It brought %d orders and %.2f%% of viewers clicked.", p.orders(), ctr);
                return new Decision(Verdict.BUDGET_UP, why + " Daily budget raised to " + raised.toPlainString()
                        + " " + currency + ".", raised);
            }
        }
        if (p.impressions() < MIN_IMPRESSIONS) {
            return new Decision(Verdict.KEEP, "Still learning (" + p.impressions() + " views so far).", null);
        }
        return new Decision(Verdict.KEEP, String.format("Doing fine: %.2f%% click rate, %d orders.", ctr, p.orders()), null);
    }

    /** Free spots for new ads. */
    public static int openSlots(int maxActive, int running) {
        return Math.max(0, maxActive - running);
    }

    /**
     * Daily budget for a new ad: the per-ad amount, limited by what's left of the daily cap.
     * Returns null when that is below the network's minimum (so no new ad is started).
     */
    public static BigDecimal budgetForNew(BigDecimal cap, BigDecimal runningBudgets, BigDecimal perAd, BigDecimal min) {
        BigDecimal left = cap.subtract(runningBudgets == null ? BigDecimal.ZERO : runningBudgets);
        BigDecimal b = perAd.min(left).setScale(2, RoundingMode.HALF_UP);
        if (min != null && b.compareTo(min) < 0) return null;
        return b.signum() > 0 ? b : null;
    }
}
