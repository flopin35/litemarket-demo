package com.litemarket.ads;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AdDailyStatRepository extends JpaRepository<AdDailyStat, Long> {

    Optional<AdDailyStat> findByAdCampaignIdAndStatDate(Long adCampaignId, LocalDate statDate);

    List<AdDailyStat> findByAdCampaignId(Long adCampaignId);

    List<AdDailyStat> findByStoreIdAndStatDateGreaterThanEqual(Long storeId, LocalDate since);
}
