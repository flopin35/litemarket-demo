package com.litemarket.ads;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AdAccountRepository extends JpaRepository<AdAccount, Long> {

    List<AdAccount> findByStoreId(Long storeId);

    Optional<AdAccount> findByStoreIdAndNetwork(Long storeId, String network);
}
