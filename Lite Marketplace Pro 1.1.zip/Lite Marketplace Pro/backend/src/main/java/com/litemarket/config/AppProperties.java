package com.litemarket.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;
import java.util.List;

/** Everything under "app:" in application.yml, bound into typed records. */
@ConfigurationProperties(prefix = "app")
public record AppProperties(
        Brand brand,
        Web web,
        Security security,
        Commission commission,
        Payments payments,
        Ads ads,
        Ai ai,
        Storage storage,
        Demo demo,
        Mail mail) {

    public record Brand(String name, String supportEmail, String defaultCountryCode, String defaultCurrency) {}

    public record Web(String baseUrl, List<String> corsOrigins) {
        /** Base URL without a trailing slash. */
        public String base() {
            String b = baseUrl == null ? "" : baseUrl.trim();
            while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
            return b;
        }
    }

    public record Security(String jwtSecret, int accessTokenMinutes, int refreshTokenDays, boolean secureCookies) {}

    /**
     * How the platform earns: a percentage of every sale.
     *
     * @param percent          commission on each order, e.g. 5 = 5%
     * @param onWhatsappOrders also charge commission on WhatsApp and hand-added orders (the seller pays it
     *                         from the dashboard); online payments always pay it automatically
     * @param dueLimit         unpaid commission at which WhatsApp checkout pauses until it is paid (0 = never)
     * @param aiMonthlyCredits AI credits every shop gets per month
     * @param productLimit     max products per shop (0 = unlimited)
     */
    public record Commission(BigDecimal percent, boolean onWhatsappOrders, BigDecimal dueLimit,
                             int aiMonthlyCredits, int productLimit) {}

    public record Payments(boolean demoMode, Flutterwave flutterwave, Paystack paystack, Stripe stripe) {}

    public record Flutterwave(String secretKey, String webhookHash, String baseUrl) {}

    public record Paystack(String secretKey, String baseUrl) {}

    public record Stripe(String secretKey, String webhookSecret, String baseUrl) {}

    /**
     * Social ads (Facebook/Instagram through Meta, and TikTok).
     *
     * @param demoMode       adds a simulated ad network so the whole flow can be tried without real accounts
     * @param tokenKey       secret used to encrypt sellers' ad-account tokens (falls back to the JWT secret)
     * @param maxDailyBudget hard cap per ad per day, in the ad account's currency (protects sellers from typos)
     */
    public record Ads(boolean demoMode, String tokenKey, String syncCron, String autopilotCron,
                      BigDecimal maxDailyBudget, Meta meta, TikTok tiktok) {}

    public record Meta(String appId, String appSecret, String apiVersion, String graphUrl, String dialogUrl) {
        public boolean enabled() {
            return notBlank(appId) && notBlank(appSecret);
        }
    }

    public record TikTok(String appId, String secret, String baseUrl, String authUrl,
                         BigDecimal minDailyBudget, String musicId) {
        public boolean enabled() {
            return notBlank(appId) && notBlank(secret);
        }
    }

    public record Ai(String baseUrl, String internalKey, int timeoutSeconds) {}

    public record Storage(String uploadDir) {}

    public record Demo(boolean seed, String adminEmail, String adminPassword) {}

    public record Mail(String from) {}

    static boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }
}
