package com.litemarket.ai;

import com.litemarket.common.ApiException;
import com.litemarket.config.AppProperties;
import com.litemarket.store.Store;
import com.litemarket.store.StoreRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

/** Monthly AI allowance. Every shop gets app.commission.ai-monthly-credits; they reset on the 1st. */
@Service
public class AiCredits {

    private final StoreRepository stores;
    private final AppProperties props;

    public AiCredits(StoreRepository stores, AppProperties props) {
        this.stores = stores;
        this.props = props;
    }

    public int limit() {
        return Math.max(0, props.commission().aiMonthlyCredits());
    }

    public int used(Store s) {
        return CreditMath.used(s.getAiPeriodStart(), s.getAiCreditsUsed(), Instant.now());
    }

    /** Uses one credit. Throws 402 AI_CREDITS when the shop has used them all this month. */
    @Transactional
    public int consume(Long storeId) {
        Store s = stores.findById(storeId).orElseThrow(() -> ApiException.notFound("Store not found"));
        Instant now = Instant.now();
        int used = CreditMath.used(s.getAiPeriodStart(), s.getAiCreditsUsed(), now);
        int limit = limit();
        if (used >= limit) {
            throw ApiException.paymentRequired("AI_CREDITS",
                    "You've used all " + limit + " AI credits this month. They refill on the 1st.");
        }
        s.setAiPeriodStart(CreditMath.periodStart(now));
        s.setAiCreditsUsed(used + 1);
        return limit - used - 1;
    }

    /** Gives a credit back when the AI call failed after the credit was taken. */
    @Transactional
    public void refund(Long storeId) {
        stores.findById(storeId).ifPresent(s -> {
            if (s.getAiCreditsUsed() > 0) s.setAiCreditsUsed(s.getAiCreditsUsed() - 1);
        });
    }
}
