package com.litemarket.commission;

import com.litemarket.commission.CommissionEntry.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public interface CommissionRepository extends JpaRepository<CommissionEntry, Long> {

    List<CommissionEntry> findByOrderId(Long orderId);

    List<CommissionEntry> findByStoreIdAndStatusOrderByCreatedAtAsc(Long storeId, Status status);

    List<CommissionEntry> findTop100ByStoreIdOrderByCreatedAtDesc(Long storeId);

    @Query("select coalesce(sum(c.amount), 0) from CommissionEntry c where c.store.id = :storeId and c.status = :status")
    BigDecimal sumByStore(@Param("storeId") Long storeId, @Param("status") Status status);

    @Query("select coalesce(sum(c.amount), 0) from CommissionEntry c where c.store.id = :storeId "
            + "and c.status = :status and c.settledAt >= :since")
    BigDecimal sumSettledSince(@Param("storeId") Long storeId, @Param("status") Status status,
                               @Param("since") Instant since);

    /** Platform totals for the admin overview (demo payments excluded). */
    @Query("select coalesce(sum(c.amount), 0) from CommissionEntry c where c.status = :status and c.demo = false")
    BigDecimal sumAll(@Param("status") Status status);
}
