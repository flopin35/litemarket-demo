package com.litemarket.commission;

import com.litemarket.auth.AuthUser;
import com.litemarket.commission.CommissionDtos.EarningsView;
import com.litemarket.commission.CommissionDtos.PayCommissionRequest;
import com.litemarket.payment.PaymentDtos.CheckoutView;
import com.litemarket.payment.PaymentService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** The seller's Earnings page: sales, commission and paying what's due. */
@RestController
@RequestMapping("/api/earnings")
public class EarningsController {

    private final CommissionService commission;
    private final PaymentService payments;

    public EarningsController(CommissionService commission, PaymentService payments) {
        this.commission = commission;
        this.payments = payments;
    }

    @GetMapping
    public EarningsView earnings(@AuthenticationPrincipal AuthUser me) {
        return commission.earnings(me.id());
    }

    @PostMapping("/pay")
    public CheckoutView pay(@AuthenticationPrincipal AuthUser me, @Valid @RequestBody PayCommissionRequest req) {
        return payments.startCommissionPayment(me, req.provider());
    }
}
