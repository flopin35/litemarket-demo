package com.litemarket.ads;

/** Where an ad is in its life. */
public enum AdStatus {
    /** Suggested by the AI autopilot, waiting for the seller to approve. */
    DRAFT,
    /** Being created at Meta/TikTok right now. */
    LAUNCHING,
    /** Created; the network is reviewing it. */
    IN_REVIEW,
    ACTIVE,
    PAUSED,
    /** The network rejected it (see reviewNote). */
    REJECTED,
    /** Creating or running it failed (see lastError). */
    ERROR,
    /** Stopped for good. */
    ENDED;

    /** Counts toward the seller's running ads and daily budget. */
    public boolean running() {
        return this == LAUNCHING || this == IN_REVIEW || this == ACTIVE;
    }

    /** Still exists at the network, so it can be synced, paused or ended. */
    public boolean live() {
        return this == IN_REVIEW || this == ACTIVE || this == PAUSED;
    }
}
