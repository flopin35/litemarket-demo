package com.litemarket.ads;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * One ad's results for one day. Views, clicks and spend come from the network; shop visits and
 * WhatsApp taps come from our own tracking (customers arriving with ?ref=ad42).
 */
@Entity
@Table(name = "ad_daily_stats", uniqueConstraints = @UniqueConstraint(columnNames = {"ad_campaign_id", "stat_date"}))
public class AdDailyStat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ad_campaign_id", nullable = false)
    private Long adCampaignId;

    @Column(nullable = false)
    private Long storeId;

    @Column(name = "stat_date", nullable = false)
    private LocalDate statDate;

    private long impressions;

    private long reach;

    private long clicks;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal spend = BigDecimal.ZERO;

    private long visits;

    private long whatsappClicks;

    public AdDailyStat() {}

    public AdDailyStat(Long adCampaignId, Long storeId, LocalDate statDate) {
        this.adCampaignId = adCampaignId;
        this.storeId = storeId;
        this.statDate = statDate;
    }

    public Long getId() { return id; }
    public Long getAdCampaignId() { return adCampaignId; }
    public Long getStoreId() { return storeId; }
    public LocalDate getStatDate() { return statDate; }
    public long getImpressions() { return impressions; }
    public void setImpressions(long impressions) { this.impressions = impressions; }
    public long getReach() { return reach; }
    public void setReach(long reach) { this.reach = reach; }
    public long getClicks() { return clicks; }
    public void setClicks(long clicks) { this.clicks = clicks; }
    public BigDecimal getSpend() { return spend; }
    public void setSpend(BigDecimal spend) { this.spend = spend; }
    public long getVisits() { return visits; }
    public void setVisits(long visits) { this.visits = visits; }
    public long getWhatsappClicks() { return whatsappClicks; }
    public void setWhatsappClicks(long whatsappClicks) { this.whatsappClicks = whatsappClicks; }
}
