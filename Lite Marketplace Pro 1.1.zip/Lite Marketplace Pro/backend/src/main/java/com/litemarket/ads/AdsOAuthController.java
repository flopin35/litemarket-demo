package com.litemarket.ads;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Where Facebook and TikTok send the seller after they allow access. Public (the browser arrives without our
 * login header); the signed state says which shop it is for. Register this URL in your Meta and TikTok apps:
 * {WEB_BASE_URL}/api/ads/oauth/meta/callback and {WEB_BASE_URL}/api/ads/oauth/tiktok/callback
 */
@RestController
public class AdsOAuthController {

    private final AdsService ads;

    public AdsOAuthController(AdsService ads) {
        this.ads = ads;
    }

    @GetMapping("/api/ads/oauth/{network}/callback")
    public ResponseEntity<Void> callback(@PathVariable("network") String network,
                                         @RequestParam(name = "code", required = false) String code,
                                         @RequestParam(name = "auth_code", required = false) String authCode,
                                         @RequestParam(name = "state", required = false) String state,
                                         @RequestParam(name = "error", required = false) String error) {
        String target = ads.finishConnect(network, code != null ? code : authCode, state, error);
        return ResponseEntity.status(302).header("Location", target).build();
    }
}
