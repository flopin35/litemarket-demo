package com.litemarket.ads;

import com.litemarket.ads.AdsDtos.NetworkTotals;
import com.litemarket.ads.AdsDtos.StatDay;
import com.litemarket.ads.AdsDtos.StatsView;
import com.litemarket.ads.AdsDtos.Totals;
import com.litemarket.common.Money;
import com.litemarket.order.ShopOrder;
import com.litemarket.order.ShopOrderRepository;
import com.litemarket.store.Store;
import com.litemarket.store.StoreService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ad results for the seller (never shown to the admin): views, clicks and spend from the networks; shop visits,
 * WhatsApp taps, orders and sales from our own data (customers who arrived through an ad link).
 */
@Service
public class AdsStats {

    private final AdCampaignRepository campaigns;
    private final AdDailyStatRepository daily;
    private final AdSettingsRepository settings;
    private final ShopOrderRepository orders;
    private final StoreService stores;

    public AdsStats(AdCampaignRepository campaigns, AdDailyStatRepository daily, AdSettingsRepository settings,
                    ShopOrderRepository orders, StoreService stores) {
        this.campaigns = campaigns;
        this.daily = daily;
        this.settings = settings;
        this.orders = orders;
        this.stores = stores;
    }

    @Transactional(readOnly = true)
    public StatsView stats(Long ownerId, int requestedDays) {
        int days = requestedDays <= 7 ? 7 : requestedDays <= 30 ? 30 : 90;
        Store s = stores.requireStore(ownerId);
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        LocalDate since = today.minusDays(days - 1L);

        List<AdCampaign> ads = campaigns.findByStoreIdOrderByCreatedAtDesc(s.getId());
        Map<Long, AdCampaign> byId = new HashMap<>();
        for (AdCampaign c : ads) byId.put(c.getId(), c);

        String spendCurrency = ads.stream().filter(c -> c.getStatus() != AdStatus.DRAFT && c.getCurrency() != null)
                .map(AdCampaign::getCurrency).findFirst().orElse(s.getCurrency());
        BigDecimal fx = settings.findByStoreId(s.getId()).map(AdSettings::getFxRate).orElse(null);

        Map<LocalDate, long[]> dayCounts = new LinkedHashMap<>();       // impressions, clicks, orders
        Map<LocalDate, BigDecimal[]> dayMoney = new LinkedHashMap<>();  // spend, revenue
        for (LocalDate d = since; !d.isAfter(today); d = d.plusDays(1)) {
            dayCounts.put(d, new long[3]);
            dayMoney.put(d, new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO});
        }
        Map<String, Object[]> net = new LinkedHashMap<>(); // network -> {currency, long[impr,clicks,orders], BigDecimal[spend,rev]}

        long impressions = 0, clicks = 0, visits = 0, whatsapp = 0;
        BigDecimal spend = BigDecimal.ZERO;
        for (AdDailyStat st : daily.findByStoreIdAndStatDateGreaterThanEqual(s.getId(), since)) {
            AdCampaign c = byId.get(st.getAdCampaignId());
            if (c == null || st.getStatDate().isAfter(today)) continue;
            impressions += st.getImpressions();
            clicks += st.getClicks();
            visits += st.getVisits();
            whatsapp += st.getWhatsappClicks();
            spend = spend.add(st.getSpend());
            long[] dc = dayCounts.get(st.getStatDate());
            dc[0] += st.getImpressions();
            dc[1] += st.getClicks();
            BigDecimal[] dm = dayMoney.get(st.getStatDate());
            dm[0] = dm[0].add(st.getSpend());
            Object[] n = net.computeIfAbsent(c.getNetwork(),
                    k -> new Object[]{c.getCurrency(), new long[3], new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO}});
            ((long[]) n[1])[0] += st.getImpressions();
            ((long[]) n[1])[1] += st.getClicks();
            ((BigDecimal[]) n[2])[0] = ((BigDecimal[]) n[2])[0].add(st.getSpend());
        }

        long orderCount = 0;
        BigDecimal revenue = BigDecimal.ZERO;
        for (ShopOrder o : orders.findByStoreIdAndAdCampaignIdIsNotNullAndCreatedAtAfter(s.getId(),
                since.atStartOfDay().toInstant(ZoneOffset.UTC))) {
            AdCampaign c = byId.get(o.getAdCampaignId());
            if (c == null || !o.getStatus().countsAsSale()) continue;
            orderCount++;
            revenue = revenue.add(o.getTotal());
            LocalDate d = LocalDate.ofInstant(o.getPaidAt() != null ? o.getPaidAt() : o.getCreatedAt(), ZoneOffset.UTC);
            if (dayCounts.containsKey(d)) {
                dayCounts.get(d)[2]++;
                dayMoney.get(d)[1] = dayMoney.get(d)[1].add(o.getTotal());
            }
            Object[] n = net.computeIfAbsent(c.getNetwork(),
                    k -> new Object[]{c.getCurrency(), new long[3], new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO}});
            ((long[]) n[1])[2]++;
            ((BigDecimal[]) n[2])[1] = ((BigDecimal[]) n[2])[1].add(o.getTotal());
        }

        Double ctr = impressions > 0 ? AdsService.round2(clicks * 100.0 / impressions) : null;
        BigDecimal cpc = clicks > 0 ? spend.divide(BigDecimal.valueOf(clicks), 2, RoundingMode.HALF_UP) : null;
        Double roas = roas(revenue, spend, spendCurrency, s.getCurrency(), fx);
        int active = (int) ads.stream().filter(c -> c.getStatus() == AdStatus.ACTIVE).count();

        List<StatDay> series = new ArrayList<>();
        dayCounts.forEach((d, c) -> series.add(new StatDay(d, c[0], c[1], Money.round(dayMoney.get(d)[0]), c[2],
                Money.round(dayMoney.get(d)[1]))));
        List<NetworkTotals> byNetwork = new ArrayList<>();
        net.forEach((k, v) -> {
            long[] c = (long[]) v[1];
            BigDecimal[] m = (BigDecimal[]) v[2];
            byNetwork.add(new NetworkTotals(k, (String) v[0], c[0], c[1], Money.round(m[0]), c[2], Money.round(m[1])));
        });

        return new StatsView(days, s.getCurrency(), spendCurrency,
                new Totals(impressions, clicks, Money.round(spend), visits, whatsapp, orderCount, Money.round(revenue),
                        ctr, cpc, roas, active),
                series, byNetwork);
    }

    /** Sales per unit of ad spend, converting spend to the shop's currency when needed (null if we can't). */
    static Double roas(BigDecimal revenue, BigDecimal spend, String spendCurrency, String shopCurrency, BigDecimal fx) {
        if (spend == null || spend.signum() <= 0) return null;
        BigDecimal spendInShop;
        if (spendCurrency == null || spendCurrency.equalsIgnoreCase(shopCurrency)) {
            spendInShop = spend;
        } else if (fx != null && fx.signum() > 0) {
            spendInShop = spend.multiply(fx);
        } else {
            return null;
        }
        return AdsService.round2(revenue.divide(spendInShop, 4, RoundingMode.HALF_UP).doubleValue());
    }
}
