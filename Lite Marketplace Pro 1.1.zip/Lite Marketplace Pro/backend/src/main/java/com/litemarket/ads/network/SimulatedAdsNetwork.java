package com.litemarket.ads.network;

import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.Assets;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Option;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdModels.TokenGrant;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The demo ad network (ADS_DEMO_MODE=true and no real keys for that network). Connecting is instant, ads
 * "pass review" after a minute and results are generated from the budget, so the whole Ads page, the stats
 * and the AI autopilot can be tried without a Meta or TikTok account. Nothing real is created or paid for.
 */
public class SimulatedAdsNetwork implements AdNetwork {

    /** One generated day of results, including the shop visits and WhatsApp taps our tracking would see. */
    public record SimDay(LocalDate day, long impressions, long reach, long clicks, BigDecimal spend,
                         long visits, long whatsappClicks) {}

    private static final Set<String> STRONG_CURRENCIES = Set.of("USD", "EUR", "GBP", "CAD", "AUD", "CHF");

    private final String id;
    private final String label;

    public SimulatedAdsNetwork(String id, String label) {
        this.id = id;
        this.label = label;
    }

    @Override public String id() { return id; }

    @Override public String label() { return label; }

    @Override public boolean enabled() { return true; }

    @Override public boolean simulated() { return true; }

    @Override public BigDecimal minDailyBudget(AccountRef account) { return BigDecimal.ONE; }

    @Override
    public String authorizeUrl(String state, String redirectUri) {
        return null; // connects instantly, see AdsService.connect
    }

    @Override
    public TokenGrant exchangeCode(String code, String redirectUri) {
        Instant expires = "meta".equals(id) ? Instant.now().plus(Duration.ofDays(60)) : null;
        return new TokenGrant("sim-" + UUID.randomUUID(), expires, List.of("sim-1001"));
    }

    @Override
    public Assets assets(String token, List<String> granted, String selected, String currencyHint) {
        String currency = currencyHint == null ? "USD" : currencyHint;
        Option account = new Option("sim-1001", "Demo ad account", currency, BigDecimal.ONE, null, null, "ACTIVE");
        if ("meta".equals(id)) {
            return new Assets(List.of(account),
                    List.of(new Option("sim-page-1", "Your shop's Facebook Page (demo)", null, null,
                            "sim-ig-1", "yourshop.demo", "PAGE")),
                    List.of());
        }
        return new Assets(List.of(account), List.of(),
                List.of(new Option("sim-tt-1", "@yourshop (demo)", null, null, "sim-1001", null, "TT_USER")));
    }

    @Override
    public Launched launch(AccountRef account, LaunchSpec spec) {
        // No photo check here: demo products often have none, and nothing is uploaded anywhere.
        String key = Long.toString(Instant.now().getEpochSecond()) + "-" + Integer.toHexString(new Random().nextInt(1 << 20));
        return new Launched("sim-c-" + key, "sim-s-" + key, "sim-cr-" + key, "sim-ad-" + key);
    }

    @Override public void setActive(AccountRef account, Launched ids, boolean active) { }

    @Override public void end(AccountRef account, Launched ids) { }

    @Override public void updateBudget(AccountRef account, Launched ids, BigDecimal dailyBudget) { }

    /** "Approves" an ad one minute after it was created. */
    @Override
    public Review review(AccountRef account, Launched ids) {
        long created = createdEpoch(ids.adId());
        return Instant.now().getEpochSecond() - created >= 60 ? new Review("ACTIVE", null) : new Review("IN_REVIEW", null);
    }

    @Override
    public Map<String, List<DayRow>> results(AccountRef account, List<Launched> ads, LocalDate from, LocalDate to) {
        return Map.of(); // AdsSync calls simulate() instead, which knows the budget and running dates
    }

    /**
     * Results for one ad between {@code activeFrom} and {@code activeUntil} (inclusive), shaped like a real
     * small-business ad: a few hundred to a few thousand views a day, a click-through rate between 0.5% and 3%
     * that depends on the ad, and most of the daily budget spent.
     */
    public List<SimDay> simulate(String adId, BigDecimal dailyBudget, String currency,
                                 Instant activeFrom, Instant activeUntil, Instant now) {
        long seed = adId == null ? 1 : adId.hashCode();
        Random adRandom = new Random(seed);
        double ctr = 0.005 + adRandom.nextDouble() * 0.025;            // this ad's click-through rate
        double perUnit = STRONG_CURRENCIES.contains(currency) ? 650 : 48; // views per unit of budget
        double budget = dailyBudget == null ? 0 : dailyBudget.doubleValue();
        LocalDate first = LocalDate.ofInstant(activeFrom, ZoneOffset.UTC);
        LocalDate last = LocalDate.ofInstant(activeUntil.isBefore(now) ? activeUntil : now, ZoneOffset.UTC);
        java.util.ArrayList<SimDay> days = new java.util.ArrayList<>();
        for (LocalDate d = first; !d.isAfter(last); d = d.plusDays(1)) {
            Random r = new Random(seed * 31 + d.toEpochDay());
            double share = 1.0;
            Instant dayStart = d.atStartOfDay().toInstant(ZoneOffset.UTC);
            Instant dayEnd = dayStart.plus(Duration.ofDays(1));
            Instant from = activeFrom.isAfter(dayStart) ? activeFrom : dayStart;
            Instant until = activeUntil.isBefore(dayEnd) ? activeUntil : dayEnd;
            if (until.isAfter(now)) until = now;
            if (!until.isAfter(from)) continue;
            share = Math.min(1.0, Duration.between(from, until).toSeconds() / 86400.0);
            double spend = budget * share * (0.82 + r.nextDouble() * 0.17);
            long impressions = Math.round(spend * perUnit * (0.85 + r.nextDouble() * 0.3));
            long clicks = Math.round(impressions * ctr * (0.8 + r.nextDouble() * 0.4));
            long visits = Math.round(clicks * (0.7 + r.nextDouble() * 0.2));
            long whatsapp = Math.round(visits * (0.08 + r.nextDouble() * 0.1));
            days.add(new SimDay(d, impressions, Math.round(impressions * 0.72), clicks,
                    BigDecimal.valueOf(spend).setScale(2, RoundingMode.HALF_UP), visits, whatsapp));
        }
        return days;
    }

    private static long createdEpoch(String adId) {
        try {
            return Long.parseLong(adId.substring("sim-ad-".length()).split("-")[0]);
        } catch (RuntimeException e) {
            return 0; // seeded demo ads: long approved
        }
    }
}
