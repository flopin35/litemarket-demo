package com.litemarket.ads.network;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.Assets;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.Image;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Option;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdModels.TokenGrant;
import com.litemarket.common.Money;
import com.litemarket.payment.gateway.GatewayException;
import com.litemarket.payment.gateway.HttpJson;
import com.litemarket.payment.gateway.HttpJson.Response;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Facebook + Instagram ads through the Meta Marketing API (Graph API v26). One ad = a traffic campaign,
 * an ad set (budget, audience, placements), a link-ad creative and the ad.
 * Docs: https://developers.facebook.com/docs/marketing-api
 */
public class MetaAdsNetwork implements AdNetwork {

    public static final String SCOPES = String.join(",",
            "ads_management", "ads_read", "business_management", "pages_show_list", "pages_read_engagement",
            "instagram_basic");

    private static final DateTimeFormatter META_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ")
            .withZone(ZoneOffset.UTC);

    private final String appId;
    private final String appSecret;
    private final String version;
    private final String graph;
    private final String dialog;
    private final HttpJson http;

    public MetaAdsNetwork(String appId, String appSecret, String version, String graphUrl, String dialogUrl,
                          HttpJson http) {
        this.appId = appId == null ? "" : appId.trim();
        this.appSecret = appSecret == null ? "" : appSecret.trim();
        this.version = version == null || version.isBlank() ? "v26.0" : version.trim();
        this.graph = trim(graphUrl, "https://graph.facebook.com") + "/" + this.version;
        this.dialog = trim(dialogUrl, "https://www.facebook.com") + "/" + this.version;
        this.http = http;
    }

    @Override public String id() { return "meta"; }

    @Override public String label() { return "Facebook & Instagram"; }

    @Override public boolean enabled() { return !appId.isEmpty() && !appSecret.isEmpty(); }

    @Override public BigDecimal minDailyBudget(AccountRef account) { return null; }

    // ── Sign-in ────────────────────────────────────────────────────────────────

    @Override
    public String authorizeUrl(String state, String redirectUri) {
        return dialog + "/dialog/oauth?client_id=" + HttpJson.enc(appId)
                + "&redirect_uri=" + HttpJson.enc(redirectUri)
                + "&state=" + HttpJson.enc(state)
                + "&response_type=code"
                + "&scope=" + HttpJson.enc(SCOPES);
    }

    @Override
    public TokenGrant exchangeCode(String code, String redirectUri) {
        JsonNode shortLived = ok(get(graph + "/oauth/access_token?client_id=" + HttpJson.enc(appId)
                + "&redirect_uri=" + HttpJson.enc(redirectUri)
                + "&client_secret=" + HttpJson.enc(appSecret)
                + "&code=" + HttpJson.enc(code), null));
        String shortToken = shortLived.path("access_token").asText("");
        if (shortToken.isEmpty()) throw new AdsException("Facebook didn't return an access token. Try connecting again.");
        // Swap for a long-lived token (about 60 days). Facebook has no refresh token: the seller reconnects later.
        JsonNode longLived = ok(get(graph + "/oauth/access_token?grant_type=fb_exchange_token"
                + "&client_id=" + HttpJson.enc(appId)
                + "&client_secret=" + HttpJson.enc(appSecret)
                + "&fb_exchange_token=" + HttpJson.enc(shortToken), null));
        String token = longLived.path("access_token").asText(shortToken);
        long seconds = longLived.path("expires_in").asLong(shortLived.path("expires_in").asLong(0));
        Instant expires = Instant.now().plus(Duration.ofSeconds(seconds > 0 ? seconds : 60L * 24 * 3600));
        return new TokenGrant(token, expires, List.of());
    }

    @Override
    public Assets assets(String token, List<String> granted, String selectedAccount, String currencyHint) {
        List<Option> accounts = new ArrayList<>();
        JsonNode acc = ok(get(graph + "/me/adaccounts?fields=id,account_id,name,currency,account_status,min_daily_budget"
                + "&limit=50", token));
        for (JsonNode a : acc.path("data")) {
            String currency = a.path("currency").asText("USD");
            BigDecimal min = a.hasNonNull("min_daily_budget")
                    ? Money.fromMinor(a.path("min_daily_budget").asLong(), currency) : null;
            boolean active = a.path("account_status").asInt(1) == 1;
            accounts.add(new Option(a.path("id").asText(), a.path("name").asText(a.path("account_id").asText()),
                    currency, min, null, null, active ? "ACTIVE" : "INACTIVE"));
        }
        List<Option> pages = new ArrayList<>();
        JsonNode pg = ok(get(graph + "/me/accounts?fields=id,name,instagram_business_account%7Bid,username%7D&limit=50", token));
        for (JsonNode p : pg.path("data")) {
            JsonNode ig = p.path("instagram_business_account");
            pages.add(new Option(p.path("id").asText(), p.path("name").asText(), null, null,
                    ig.hasNonNull("id") ? ig.path("id").asText() : null,
                    ig.hasNonNull("username") ? ig.path("username").asText() : null, "PAGE"));
        }
        return new Assets(accounts, pages, List.of());
    }

    // ── Creating ads ───────────────────────────────────────────────────────────

    @Override
    public Launched launch(AccountRef a, LaunchSpec spec) {
        if (a.pageId() == null || a.pageId().isBlank()) {
            throw new AdsException("Choose the Facebook Page your ads will come from (Ads > Facebook & Instagram > Change).");
        }
        if (spec.images().isEmpty()) throw new AdsException("This product needs a photo before it can be advertised.");
        String act = actId(a.adAccountId());
        String imageHash = uploadImage(a, act, spec.images().get(0));

        String campaignId = post(a, graph + "/" + act + "/campaigns", form(
                kv("name", spec.name()),
                kv("objective", "OUTCOME_TRAFFIC"),
                kv("status", "ACTIVE"),
                kv("special_ad_categories", "[]"),
                kv("is_adset_budget_sharing_enabled", "false"))).path("id").asText();
        try {
            List<String[]> adSet = new ArrayList<>(form(
                    kv("name", spec.name()),
                    kv("campaign_id", campaignId),
                    kv("daily_budget", String.valueOf(Money.toMinor(spec.dailyBudget(), a.currency()))),
                    kv("billing_event", "IMPRESSIONS"),
                    kv("optimization_goal", "LINK_CLICKS"),
                    kv("bid_strategy", "LOWEST_COST_WITHOUT_CAP"),
                    kv("destination_type", "WEBSITE"),
                    kv("start_time", META_TIME.format(spec.start())),
                    kv("status", "ACTIVE"),
                    kv("targeting", targeting(a, spec).toString())));
            if (spec.endDate() != null) {
                adSet.add(kv("end_time", META_TIME.format(spec.endDate().plusDays(1).atStartOfDay().toInstant(ZoneOffset.UTC))));
            }
            String adSetId = post(a, graph + "/" + act + "/adsets", adSet).path("id").asText();
            String creativeId = post(a, graph + "/" + act + "/adcreatives", form(
                    kv("name", spec.name()),
                    kv("object_story_spec", storySpec(a, spec, imageHash).toString()),
                    kv("degrees_of_freedom_spec", "{\"creative_features_spec\":{"
                            + "\"image_touchups\":{\"enroll_status\":\"OPT_OUT\"},"
                            + "\"text_optimizations\":{\"enroll_status\":\"OPT_OUT\"}}}"))).path("id").asText();
            String adId = post(a, graph + "/" + act + "/ads", form(
                    kv("name", spec.name()),
                    kv("adset_id", adSetId),
                    kv("creative", "{\"creative_id\":\"" + creativeId + "\"}"),
                    kv("status", "ACTIVE"))).path("id").asText();
            return new Launched(campaignId, adSetId, creativeId, adId);
        } catch (AdsException e) {
            try {
                post(a, graph + "/" + campaignId, form(kv("status", "DELETED")));
            } catch (AdsException ignored) {
                // best effort clean-up; the original error is what matters
            }
            throw e;
        }
    }

    ObjectNode targeting(AccountRef a, LaunchSpec spec) {
        ObjectNode t = http.mapper().createObjectNode();
        ArrayNode countries = t.putObject("geo_locations").putArray("countries");
        spec.countries().forEach(countries::add);
        t.put("age_min", Math.max(18, spec.ageMin()));
        t.put("age_max", Math.min(65, spec.ageMax()));
        ArrayNode platforms = t.putArray("publisher_platforms");
        platforms.add("facebook");
        t.putArray("facebook_positions").add("feed").add("story").add("facebook_reels");
        if (a.instagramUserId() != null && !a.instagramUserId().isBlank()) {
            platforms.add("instagram");
            // No "explore": Meta rejects it from Oct 2026.
            t.putArray("instagram_positions").add("stream").add("story").add("reels");
        }
        // Since v23 new ad sets default to Advantage+ audience, which ignores a lower age limit. Keep the seller's.
        t.putObject("targeting_automation").put("advantage_audience", 0);
        return t;
    }

    ObjectNode storySpec(AccountRef a, LaunchSpec spec, String imageHash) {
        ObjectNode s = http.mapper().createObjectNode();
        s.put("page_id", a.pageId());
        if (a.instagramUserId() != null && !a.instagramUserId().isBlank()) s.put("instagram_user_id", a.instagramUserId());
        ObjectNode link = s.putObject("link_data");
        link.put("link", spec.landingUrl());
        link.put("message", spec.primaryText());
        link.put("name", spec.headline());
        if (spec.description() != null && !spec.description().isBlank()) link.put("description", spec.description());
        link.put("image_hash", imageHash);
        ObjectNode cta = link.putObject("call_to_action");
        cta.put("type", spec.callToAction() == null ? "SHOP_NOW" : spec.callToAction());
        cta.putObject("value").put("link", spec.landingUrl());
        return s;
    }

    private String uploadImage(AccountRef a, String act, Image image) {
        JsonNode r = post(a, graph + "/" + act + "/adimages", form(
                kv("bytes", Base64.getEncoder().encodeToString(image.bytes())),
                kv("name", image.fileName())));
        Iterator<JsonNode> it = r.path("images").elements();
        if (!it.hasNext()) throw new AdsException("Facebook didn't accept the product photo. Try a JPG or PNG.");
        String hash = it.next().path("hash").asText("");
        if (hash.isEmpty()) throw new AdsException("Facebook didn't accept the product photo. Try a JPG or PNG.");
        return hash;
    }

    // ── Managing ───────────────────────────────────────────────────────────────

    @Override
    public void setActive(AccountRef a, Launched ids, boolean active) {
        post(a, graph + "/" + ids.campaignId(), form(kv("status", active ? "ACTIVE" : "PAUSED")));
    }

    @Override
    public void end(AccountRef a, Launched ids) {
        post(a, graph + "/" + ids.campaignId(), form(kv("status", "ARCHIVED")));
    }

    @Override
    public void updateBudget(AccountRef a, Launched ids, BigDecimal dailyBudget) {
        post(a, graph + "/" + ids.adSetId(), form(
                kv("daily_budget", String.valueOf(Money.toMinor(dailyBudget, a.currency())))));
    }

    @Override
    public Review review(AccountRef a, Launched ids) {
        JsonNode ad = ok(get(graph + "/" + ids.adId() + "?fields=effective_status,ad_review_feedback", a.accessToken()));
        String s = ad.path("effective_status").asText("");
        String note = reviewNote(ad.path("ad_review_feedback"));
        return switch (s) {
            case "ACTIVE" -> new Review("ACTIVE", null);
            case "PENDING_REVIEW", "IN_PROCESS", "PREAPPROVED" -> new Review("IN_REVIEW", null);
            case "DISAPPROVED" -> new Review("REJECTED", note == null ? "Facebook didn't approve this ad." : note);
            case "PAUSED", "CAMPAIGN_PAUSED", "ADSET_PAUSED" -> new Review("PAUSED", null);
            case "DELETED", "ARCHIVED" -> new Review("ENDED", null);
            case "PENDING_BILLING_INFO" -> new Review("ERROR", "Add a payment method to your Facebook ad account.");
            case "WITH_ISSUES" -> new Review("ERROR", note == null ? "Facebook reports a problem with this ad." : note);
            default -> new Review("IN_REVIEW", null);
        };
    }

    private static String reviewNote(JsonNode feedback) {
        List<String> reasons = new ArrayList<>();
        feedback.path("global").fields().forEachRemaining(e -> reasons.add(e.getValue().asText(e.getKey())));
        return reasons.isEmpty() ? null : String.join(" ", reasons);
    }

    @Override
    public Map<String, List<DayRow>> results(AccountRef a, List<Launched> ads, LocalDate from, LocalDate to) {
        Map<String, List<DayRow>> out = new LinkedHashMap<>();
        String range = HttpJson.enc("{\"since\":\"" + from + "\",\"until\":\"" + to + "\"}");
        for (Launched ad : ads) {
            JsonNode r = ok(get(graph + "/" + ad.adId() + "/insights?fields=impressions,reach,clicks,inline_link_clicks,spend"
                    + "&time_increment=1&time_range=" + range + "&limit=100", a.accessToken()));
            List<DayRow> rows = new ArrayList<>();
            for (JsonNode d : r.path("data")) {
                long clicks = d.hasNonNull("inline_link_clicks") ? d.path("inline_link_clicks").asLong()
                        : d.path("clicks").asLong();
                rows.add(new DayRow(LocalDate.parse(d.path("date_start").asText()),
                        d.path("impressions").asLong(), d.path("reach").asLong(), clicks,
                        new BigDecimal(d.path("spend").asText("0"))));
            }
            out.put(ad.adId(), rows);
        }
        return out;
    }

    // ── HTTP ───────────────────────────────────────────────────────────────────

    private Response get(String url, String token) {
        try {
            return http.get(url, token == null ? Map.of() : Map.of("Authorization", "Bearer " + token));
        } catch (GatewayException e) {
            throw new AdsException("We couldn't reach Facebook. Try again in a moment.");
        }
    }

    private JsonNode post(AccountRef a, String url, List<String[]> form) {
        try {
            return ok(http.postForm(url, Map.of("Authorization", "Bearer " + a.accessToken()), form));
        } catch (GatewayException e) {
            throw new AdsException("We couldn't reach Facebook. Try again in a moment.");
        }
    }

    /** Returns the JSON, or throws a seller-friendly error (code 190 = token expired: reconnect). */
    static JsonNode ok(Response r) {
        JsonNode err = r.json().path("error");
        if (r.ok() && err.isMissingNode()) return r.json();
        int code = err.path("code").asInt(0);
        String msg = err.path("error_user_msg").asText("");
        if (msg.isBlank()) msg = err.path("message").asText("Facebook returned an error (" + r.status() + ").");
        if (code == 190) return reconnect();
        if (code == 4 || code == 17 || code == 613 || (code >= 80000 && code <= 80014)) {
            throw new AdsException("Facebook is limiting requests right now. We'll try again shortly.");
        }
        throw new AdsException("Facebook: " + msg);
    }

    private static JsonNode reconnect() {
        throw new AdsException("Your Facebook connection expired. Reconnect it on the Ads page.", true);
    }

    static String actId(String id) {
        return id.startsWith("act_") ? id : "act_" + id;
    }

    private static List<String[]> form(String[]... pairs) {
        return new ArrayList<>(java.util.Arrays.asList(pairs));
    }

    private static String[] kv(String k, String v) {
        return new String[]{k, v};
    }

    private static String trim(String url, String fallback) {
        String u = url == null || url.isBlank() ? fallback : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }
}
