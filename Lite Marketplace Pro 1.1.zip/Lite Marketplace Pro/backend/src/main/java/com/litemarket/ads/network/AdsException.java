package com.litemarket.ads.network;

/** A network said no. The message is safe to show the seller; reconnect=true means sign in again. */
public class AdsException extends RuntimeException {

    private final boolean reconnect;

    public AdsException(String message) {
        this(message, false);
    }

    public AdsException(String message, boolean reconnect) {
        super(message);
        this.reconnect = reconnect;
    }

    public boolean reconnect() {
        return reconnect;
    }
}
