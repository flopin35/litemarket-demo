package com.litemarket.commission;

import com.litemarket.ai.AiCredits;
import com.litemarket.ai.CreditMath;
import com.litemarket.commission.CommissionDtos.EarningsView;
import com.litemarket.commission.CommissionDtos.EntryView;
import com.litemarket.commission.CommissionEntry.Kind;
import com.litemarket.commission.CommissionEntry.Status;
import com.litemarket.common.Money;
import com.litemarket.config.AppProperties;
import com.litemarket.order.OrderStatus;
import com.litemarket.order.ShopOrder;
import com.litemarket.order.ShopOrderRepository;
import com.litemarket.payment.Payment;
import com.litemarket.payment.PaymentFulfillment;
import com.litemarket.payment.PaymentPurpose;
import com.litemarket.payment.PaymentRepository;
import com.litemarket.payment.PaymentStatus;
import com.litemarket.payment.Settlement;
import com.litemarket.payment.gateway.GatewayRegistry;
import com.litemarket.store.Store;
import com.litemarket.store.StoreDtos.AccountView;
import com.litemarket.store.StoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;

/**
 * How the platform earns: a percentage of every sale.
 * <ul>
 *   <li>Online payments: the commission is taken automatically (split payment, or kept from the money the
 *       platform collected) and recorded here as SETTLED.</li>
 *   <li>WhatsApp and hand-added orders: the seller is paid directly, so the commission becomes DUE when the
 *       order is marked Paid or Delivered. The seller pays it from the Earnings page. If it reaches the due
 *       limit, WhatsApp checkout pauses (online payment keeps working, so sales never stop).</li>
 * </ul>
 */
@Service
public class CommissionService {

    private static final Logger log = LoggerFactory.getLogger(CommissionService.class);
    private static final List<Kind> SELLER_KINDS = List.of(Kind.WHATSAPP, Kind.ADJUSTMENT);

    private final CommissionRepository entries;
    private final PaymentRepository payments;
    private final ShopOrderRepository orders;
    private final StoreService stores;
    private final AiCredits credits;
    private final GatewayRegistry gateways;
    private final AppProperties props;

    public CommissionService(CommissionRepository entries, PaymentRepository payments, ShopOrderRepository orders,
                             StoreService stores, AiCredits credits, GatewayRegistry gateways, AppProperties props) {
        this.entries = entries;
        this.payments = payments;
        this.orders = orders;
        this.stores = stores;
        this.credits = credits;
        this.gateways = gateways;
        this.props = props;
    }

    public BigDecimal percent() {
        BigDecimal p = props.commission().percent();
        return p == null ? BigDecimal.ZERO : p;
    }

    public BigDecimal feeFor(BigDecimal orderTotal) {
        return CommissionMath.fee(orderTotal, percent());
    }

    // ── Recording ──────────────────────────────────────────────────────────────

    /** Called by OrderService whenever an order changes status (inside its transaction). */
    public void onOrderStatus(ShopOrder o, OrderStatus previous, OrderStatus next) {
        if (o.getId() == null || percent().signum() <= 0) return;
        if (next.countsAsSale() && (previous == null || !previous.countsAsSale())) {
            if (o.getPaymentProvider() != null) return; // paid online: recordOnline() handles it
            if (!props.commission().onWhatsappOrders()) return;
            if (netCharged(o.getId()).signum() > 0) return; // already charged for this order
            BigDecimal fee = feeFor(o.getTotal());
            if (fee.signum() <= 0) return;
            CommissionEntry e = base(o);
            e.setKind(Kind.WHATSAPP);
            e.setAmount(fee);
            e.setStatus(Status.DUE);
            entries.save(e);
        } else if (next == OrderStatus.CANCELLED) {
            BigDecimal settled = BigDecimal.ZERO;
            for (CommissionEntry e : entries.findByOrderId(o.getId())) {
                if (!SELLER_KINDS.contains(e.getKind())) continue;
                if (e.getStatus() == Status.DUE) {
                    e.setStatus(Status.REVERSED);
                    e.setSettledAt(Instant.now());
                } else if (e.getStatus() == Status.SETTLED) {
                    settled = settled.add(e.getAmount());
                }
            }
            if (settled.signum() > 0) {
                // Commission already paid for an order that got cancelled: credit it against the next bill.
                CommissionEntry credit = base(o);
                credit.setKind(Kind.ADJUSTMENT);
                credit.setAmount(settled.negate());
                credit.setStatus(Status.DUE);
                entries.save(credit);
            }
        }
    }

    /** Called when an online order payment is confirmed: the commission was taken by the payment itself. */
    @Transactional
    public void recordOnline(Payment p, ShopOrder o) {
        BigDecimal fee = p.getPlatformFee() == null ? BigDecimal.ZERO : p.getPlatformFee();
        if (fee.signum() <= 0 || o == null) return;
        boolean exists = entries.findByOrderId(o.getId()).stream().anyMatch(e -> e.getKind() == Kind.ONLINE);
        if (exists) return;
        CommissionEntry e = base(o);
        e.setKind(Kind.ONLINE);
        e.setAmount(fee);
        e.setStatus(Status.SETTLED);
        e.setPaymentReference(p.getReference());
        e.setSettledAt(Instant.now());
        e.setDemo("demo".equals(p.getProvider()));
        entries.save(e);
    }

    /** The seller paid {@code paid}: settles the oldest due entries it covers. */
    @Transactional
    public int settle(Long storeId, BigDecimal paid, String reference, boolean demo) {
        List<CommissionEntry> due = entries.findByStoreIdAndStatusOrderByCreatedAtAsc(storeId, Status.DUE);
        int n = CommissionMath.coveredCount(due.stream().map(CommissionEntry::getAmount).toList(), paid);
        Instant now = Instant.now();
        for (int i = 0; i < n; i++) {
            CommissionEntry e = due.get(i);
            e.setStatus(Status.SETTLED);
            e.setSettledAt(now);
            e.setPaymentReference(reference);
            e.setDemo(demo);
        }
        log.info("Commission payment {} settled {} entr{} for store {}", reference, n, n == 1 ? "y" : "ies", storeId);
        return n;
    }

    // ── Reading ────────────────────────────────────────────────────────────────

    public BigDecimal due(Store s) {
        return Money.round(entries.sumByStore(s.getId(), Status.DUE));
    }

    public boolean whatsappPaused(Store s) {
        return props.commission().onWhatsappOrders()
                && CommissionMath.whatsappPaused(due(s), props.commission().dueLimit());
    }

    /** Small summary used by /me and the dashboard. */
    public AccountView account(Store s) {
        BigDecimal due = due(s);
        int productLimit = props.commission().productLimit();
        return new AccountView(
                percent(),
                s.getCurrency(),
                due.max(BigDecimal.ZERO),
                props.commission().dueLimit(),
                whatsappPaused(s),
                credits.used(s),
                credits.limit(),
                productLimit > 0 ? productLimit : null);
    }

    @Transactional(readOnly = true)
    public EarningsView earnings(Long ownerId) {
        Store s = stores.requireStore(ownerId);
        Instant monthStart = CreditMath.periodStart(Instant.now()).atStartOfDay().toInstant(ZoneOffset.UTC);
        BigDecimal paidMonth = entries.sumSettledSince(s.getId(), Status.SETTLED, monthStart);
        BigDecimal paidAll = entries.sumByStore(s.getId(), Status.SETTLED);
        BigDecimal sales = orders.findByStoreIdAndCreatedAtAfter(s.getId(), monthStart).stream()
                .filter(o -> o.getStatus().countsAsSale())
                .map(ShopOrder::getTotal).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal owed = payments.findByStoreIdAndSettlement(s.getId(), Settlement.OWED).stream()
                .filter(p -> p.getStatus() == PaymentStatus.SUCCESS)
                .map(p -> p.getSellerAmount() == null ? BigDecimal.ZERO : p.getSellerAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal due = due(s);
        return new EarningsView(
                s.getCurrency(),
                percent(),
                props.commission().onWhatsappOrders(),
                due.max(BigDecimal.ZERO),
                props.commission().dueLimit(),
                whatsappPaused(s),
                Money.round(paidMonth),
                Money.round(paidAll),
                Money.round(sales),
                Money.round(owed),
                gateways.options(),
                entries.findTop100ByStoreIdOrderByCreatedAtDesc(s.getId()).stream().map(CommissionService::view).toList(),
                payments.findTop50ByStoreIdAndPurposeOrderByCreatedAtDesc(s.getId(), PaymentPurpose.COMMISSION)
                        .stream().map(PaymentFulfillment::view).toList());
    }

    static EntryView view(CommissionEntry e) {
        return new EntryView(e.getId(), e.getOrderNumber(), e.getOrderTotal(), e.getPercent(), e.getAmount(),
                e.getCurrency(), e.getKind().name(), e.getStatus().name(), e.getCreatedAt(), e.getSettledAt());
    }

    private CommissionEntry base(ShopOrder o) {
        CommissionEntry e = new CommissionEntry();
        e.setStore(o.getStore());
        e.setOrderId(o.getId());
        e.setOrderNumber(o.getNumber());
        e.setOrderTotal(o.getTotal());
        e.setPercent(percent());
        e.setCurrency(o.getCurrency());
        return e;
    }

    /** Commission currently charged to the seller for an order (due or paid, minus credits). */
    private BigDecimal netCharged(Long orderId) {
        return entries.findByOrderId(orderId).stream()
                .filter(e -> SELLER_KINDS.contains(e.getKind()))
                .filter(e -> e.getStatus() == Status.DUE || e.getStatus() == Status.SETTLED)
                .map(CommissionEntry::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
