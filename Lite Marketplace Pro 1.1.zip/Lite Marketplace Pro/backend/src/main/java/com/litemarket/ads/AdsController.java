package com.litemarket.ads;

import com.fasterxml.jackson.databind.JsonNode;
import com.litemarket.ads.AdsDtos.AdCopyRequest;
import com.litemarket.ads.AdsDtos.AdView;
import com.litemarket.ads.AdsDtos.AdsOverview;
import com.litemarket.ads.AdsDtos.AssetsView;
import com.litemarket.ads.AdsDtos.BudgetRequest;
import com.litemarket.ads.AdsDtos.ConnectView;
import com.litemarket.ads.AdsDtos.LaunchRequest;
import com.litemarket.ads.AdsDtos.NetworkView;
import com.litemarket.ads.AdsDtos.RunResult;
import com.litemarket.ads.AdsDtos.SelectAccountRequest;
import com.litemarket.ads.AdsDtos.SettingsRequest;
import com.litemarket.ads.AdsDtos.SettingsView;
import com.litemarket.ads.AdsDtos.StatsView;
import com.litemarket.auth.AuthUser;
import com.litemarket.common.RateLimiter;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.Map;

/** The seller's Ads page. Only the shop owner sees their ads and numbers (there are no admin ad endpoints). */
@RestController
@RequestMapping("/api/ads")
public class AdsController {

    private final AdsService ads;
    private final AdsStats stats;
    private final AdsSync sync;
    private final AutopilotService autopilot;
    private final RateLimiter launchLimiter = new RateLimiter(20, Duration.ofHours(1));
    private final RateLimiter runLimiter = new RateLimiter(6, Duration.ofHours(1));

    public AdsController(AdsService ads, AdsStats stats, AdsSync sync, AutopilotService autopilot) {
        this.ads = ads;
        this.stats = stats;
        this.sync = sync;
        this.autopilot = autopilot;
    }

    @GetMapping
    public AdsOverview overview(@AuthenticationPrincipal AuthUser me) {
        return ads.overview(me.id());
    }

    @GetMapping("/stats")
    public StatsView stats(@AuthenticationPrincipal AuthUser me, @RequestParam(name = "days", defaultValue = "30") int days) {
        return stats.stats(me.id(), days);
    }

    @PostMapping("/sync")
    public Map<String, Integer> syncNow(@AuthenticationPrincipal AuthUser me) {
        runLimiter.check("sync|" + me.id(), "Results were refreshed a moment ago. Try again later.");
        return Map.of("updated", sync.syncStore(ads.storeId(me.id())));
    }

    // ── Accounts ───────────────────────────────────────────────────────────────

    @PostMapping("/accounts/{network}/connect")
    public ConnectView connect(@AuthenticationPrincipal AuthUser me, @PathVariable("network") String network) {
        return ads.connect(me.id(), network);
    }

    @GetMapping("/accounts/{network}/options")
    public AssetsView options(@AuthenticationPrincipal AuthUser me, @PathVariable("network") String network,
                              @RequestParam(name = "adAccountId", required = false) String adAccountId) {
        return ads.assets(me.id(), network, adAccountId);
    }

    @PutMapping("/accounts/{network}")
    public NetworkView select(@AuthenticationPrincipal AuthUser me, @PathVariable("network") String network,
                              @Valid @RequestBody SelectAccountRequest req) {
        return ads.select(me.id(), network, req);
    }

    @DeleteMapping("/accounts/{network}")
    public ResponseEntity<Void> disconnect(@AuthenticationPrincipal AuthUser me, @PathVariable("network") String network) {
        ads.disconnect(me.id(), network);
        return ResponseEntity.noContent().build();
    }

    // ── Ads ────────────────────────────────────────────────────────────────────

    @PostMapping("/copy")
    public JsonNode copy(@AuthenticationPrincipal AuthUser me, @Valid @RequestBody AdCopyRequest req) {
        return ads.adCopy(me.id(), req);
    }

    @PostMapping
    public AdView launch(@AuthenticationPrincipal AuthUser me, @Valid @RequestBody LaunchRequest req) {
        launchLimiter.check("launch|" + me.id(), "That's a lot of new ads in one hour. Try again later.");
        return ads.launch(me.id(), req);
    }

    @PostMapping("/{id}/approve")
    public AdView approve(@AuthenticationPrincipal AuthUser me, @PathVariable("id") Long id) {
        launchLimiter.check("launch|" + me.id(), "That's a lot of new ads in one hour. Try again later.");
        return ads.approve(me.id(), id);
    }

    @PostMapping("/{id}/pause")
    public AdView pause(@AuthenticationPrincipal AuthUser me, @PathVariable("id") Long id) {
        return ads.pause(me.id(), id);
    }

    @PostMapping("/{id}/resume")
    public AdView resume(@AuthenticationPrincipal AuthUser me, @PathVariable("id") Long id) {
        return ads.resume(me.id(), id);
    }

    @PostMapping("/{id}/end")
    public AdView end(@AuthenticationPrincipal AuthUser me, @PathVariable("id") Long id) {
        return ads.end(me.id(), id);
    }

    @PutMapping("/{id}/budget")
    public AdView budget(@AuthenticationPrincipal AuthUser me, @PathVariable("id") Long id,
                         @Valid @RequestBody BudgetRequest req) {
        return ads.budget(me.id(), id, req.dailyBudget());
    }

    // ── Autopilot ──────────────────────────────────────────────────────────────

    @PutMapping("/settings")
    public SettingsView settings(@AuthenticationPrincipal AuthUser me, @Valid @RequestBody SettingsRequest req) {
        return ads.saveSettings(me.id(), req);
    }

    @PostMapping("/autopilot/run")
    public RunResult runAutopilot(@AuthenticationPrincipal AuthUser me) {
        runLimiter.check("autopilot|" + me.id(), "The autopilot ran a moment ago. Try again later.");
        return autopilot.runNow(me.id());
    }
}
