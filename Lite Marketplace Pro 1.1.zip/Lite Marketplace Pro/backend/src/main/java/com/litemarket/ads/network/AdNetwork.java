package com.litemarket.ads.network;

import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.Assets;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdModels.TokenGrant;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * One ad network (Meta for Facebook + Instagram, or TikTok). Every call is made with the seller's own
 * token, so ads are billed to the seller's ad account. Add a network by implementing this interface and
 * registering it in AdNetworks.
 */
public interface AdNetwork {

    /** "meta" or "tiktok". */
    String id();

    String label();

    /** True when it can be used (keys configured, or the demo network). */
    boolean enabled();

    /** True for the demo network: nothing real is created and no money is spent. */
    default boolean simulated() {
        return false;
    }

    /** Smallest daily budget allowed, in the account currency (null = ask the account). */
    BigDecimal minDailyBudget(AccountRef account);

    /** The sign-in page the seller is sent to. */
    String authorizeUrl(String state, String redirectUri);

    /** Turns the code from the sign-in redirect into a token. */
    TokenGrant exchangeCode(String code, String redirectUri);

    /** Ad accounts, pages and identities the token can use. selectedAccount narrows TikTok identities. */
    Assets assets(String accessToken, List<String> grantedAccountIds, String selectedAccount, String currencyHint);

    Launched launch(AccountRef account, LaunchSpec spec);

    void setActive(AccountRef account, Launched ids, boolean active);

    void end(AccountRef account, Launched ids);

    void updateBudget(AccountRef account, Launched ids, BigDecimal dailyBudget);

    Review review(AccountRef account, Launched ids);

    /** Daily results for the given ads (by network ad id) between the two dates, inclusive. */
    Map<String, List<DayRow>> results(AccountRef account, List<Launched> ads, LocalDate from, LocalDate to);
}
