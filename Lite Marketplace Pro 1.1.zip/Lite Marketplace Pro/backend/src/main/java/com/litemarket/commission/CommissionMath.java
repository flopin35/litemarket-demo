package com.litemarket.commission;

import com.litemarket.common.Money;

import java.math.BigDecimal;
import java.util.List;

/** Commission rules with no framework dependencies (unit-tested in CommissionMathTest). */
public final class CommissionMath {

    private CommissionMath() {}

    /** The platform's share of a sale: percent% of the total, rounded to 2 places. */
    public static BigDecimal fee(BigDecimal orderTotal, BigDecimal percent) {
        return Money.percentOf(orderTotal, percent);
    }

    /**
     * How many of the oldest due entries a payment of {@code paid} covers: the longest prefix whose running
     * total stays within the amount paid (credits, which are negative, make room for later entries).
     */
    public static int coveredCount(List<BigDecimal> dueOldestFirst, BigDecimal paid) {
        BigDecimal limit = Money.round(paid).add(new BigDecimal("0.005"));
        BigDecimal running = BigDecimal.ZERO;
        int covered = 0;
        for (int i = 0; i < dueOldestFirst.size(); i++) {
            running = running.add(dueOldestFirst.get(i));
            if (running.compareTo(limit) <= 0) covered = i + 1;
        }
        return covered;
    }

    /** WhatsApp checkout pauses once unpaid commission reaches the limit (a limit of 0 never pauses). */
    public static boolean whatsappPaused(BigDecimal due, BigDecimal limit) {
        if (limit == null || limit.signum() <= 0 || due == null) return false;
        return due.compareTo(limit) >= 0;
    }
}
