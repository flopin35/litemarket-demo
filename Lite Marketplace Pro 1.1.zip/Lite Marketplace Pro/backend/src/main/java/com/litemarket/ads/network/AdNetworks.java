package com.litemarket.ads.network;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.litemarket.common.ApiException;
import com.litemarket.config.AppProperties;
import com.litemarket.payment.gateway.HttpJson;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * The ad networks sellers can use. A network with keys configured is real; without keys it is replaced by the
 * demo network while ADS_DEMO_MODE=true, and hidden otherwise.
 */
@Component
public class AdNetworks {

    private final Map<String, AdNetwork> active = new LinkedHashMap<>();
    private final Map<String, SimulatedAdsNetwork> simulated = new LinkedHashMap<>();

    public AdNetworks(AppProperties props, ObjectMapper mapper) {
        this(props, new HttpJson(mapper));
    }

    public AdNetworks(AppProperties props, HttpJson http) {
        AppProperties.Ads ads = props.ads();
        AppProperties.Meta m = ads.meta();
        AppProperties.TikTok t = ads.tiktok();
        simulated.put("meta", new SimulatedAdsNetwork("meta", "Facebook & Instagram"));
        simulated.put("tiktok", new SimulatedAdsNetwork("tiktok", "TikTok"));
        register(new MetaAdsNetwork(m.appId(), m.appSecret(), m.apiVersion(), m.graphUrl(), m.dialogUrl(), http),
                ads.demoMode());
        register(new TikTokAdsNetwork(t.appId(), t.secret(), t.baseUrl(), t.authUrl(), t.minDailyBudget(), t.musicId(), http),
                ads.demoMode());
    }

    private void register(AdNetwork real, boolean demoMode) {
        if (real.enabled()) {
            active.put(real.id(), real);
        } else if (demoMode) {
            active.put(real.id(), simulated.get(real.id()));
        }
    }

    /** Networks sellers can connect, in display order. */
    public List<AdNetwork> available() {
        return List.copyOf(active.values());
    }

    public Optional<AdNetwork> find(String id) {
        return Optional.ofNullable(active.get(id));
    }

    public AdNetwork require(String id) {
        return find(id).orElseThrow(() -> ApiException.badRequest("That ad network isn't available on this site."));
    }

    /** The network an existing account talks to (demo accounts always use the demo network). */
    public AdNetwork forAccount(String networkId, boolean simulatedAccount) {
        if (simulatedAccount) return simulated.get(networkId);
        return require(networkId);
    }

    public static String label(String id) {
        return "tiktok".equals(id) ? "TikTok" : "Facebook & Instagram";
    }
}
