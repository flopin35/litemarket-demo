package com.litemarket.user;

public enum Role {
    SELLER,
    ADMIN
}
