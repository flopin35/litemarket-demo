package com.litemarket.ads;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AutopilotLogRepository extends JpaRepository<AutopilotLog, Long> {

    List<AutopilotLog> findTop40ByStoreIdOrderByCreatedAtDesc(Long storeId);
}
