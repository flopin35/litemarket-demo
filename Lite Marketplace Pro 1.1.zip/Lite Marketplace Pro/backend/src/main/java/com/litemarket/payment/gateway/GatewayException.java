package com.litemarket.payment.gateway;

/** The payment provider refused a request or could not be reached. */
public class GatewayException extends RuntimeException {

    public GatewayException(String message) {
        super(message);
    }

    public GatewayException(String message, Throwable cause) {
        super(message, cause);
    }
}
