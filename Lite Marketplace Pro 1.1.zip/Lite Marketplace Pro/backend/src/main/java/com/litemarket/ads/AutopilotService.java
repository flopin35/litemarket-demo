package com.litemarket.ads;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.litemarket.ads.AdCampaign.Origin;
import com.litemarket.ads.AdsDtos.RunResult;
import com.litemarket.ads.AutopilotLog.Action;
import com.litemarket.ads.AutopilotRules.Decision;
import com.litemarket.ads.AutopilotRules.Performance;
import com.litemarket.ai.AiContext.Prepared;
import com.litemarket.ai.AiService;
import com.litemarket.common.ApiException;
import com.litemarket.config.AppProperties;
import com.litemarket.order.OrderItem;
import com.litemarket.order.ShopOrder;
import com.litemarket.order.ShopOrderRepository;
import com.litemarket.product.Product;
import com.litemarket.product.ProductRepository;
import com.litemarket.store.Store;
import com.litemarket.store.StoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The AI ads autopilot. Every few hours (ADS_AUTOPILOT_CRON), for each shop that turned it on:
 * <ol>
 *   <li>refreshes the ad results,</li>
 *   <li>pauses autopilot ads that aren't working and gives winners more budget (AutopilotRules),</li>
 *   <li>fills free slots: the AI picks the products most likely to sell and writes the ads, which are launched
 *       straight away or left as suggestions for the seller to approve.</li>
 * </ol>
 * It never spends more than the seller's daily limit and only manages ads it created itself.
 */
@Service
public class AutopilotService {

    private static final Logger log = LoggerFactory.getLogger(AutopilotService.class);

    private final AdSettingsRepository settingsRepo;
    private final AdCampaignRepository campaigns;
    private final AdAccountRepository accounts;
    private final AutopilotLogRepository logs;
    private final AdsService ads;
    private final AdsSync sync;
    private final ProductRepository products;
    private final ShopOrderRepository orders;
    private final StoreService stores;
    private final AiService ai;
    private final AppProperties props;

    public AutopilotService(AdSettingsRepository settingsRepo, AdCampaignRepository campaigns,
                            AdAccountRepository accounts, AutopilotLogRepository logs, AdsService ads, AdsSync sync,
                            ProductRepository products, ShopOrderRepository orders, StoreService stores, AiService ai,
                            AppProperties props) {
        this.settingsRepo = settingsRepo;
        this.campaigns = campaigns;
        this.accounts = accounts;
        this.logs = logs;
        this.ads = ads;
        this.sync = sync;
        this.products = products;
        this.orders = orders;
        this.stores = stores;
        this.ai = ai;
        this.props = props;
    }

    @Scheduled(cron = "${app.ads.autopilot-cron:0 40 */6 * * *}")
    public void runAll() {
        for (AdSettings x : settingsRepo.findByAutopilotEnabledTrue()) {
            try {
                run(x.getStore());
            } catch (RuntimeException e) {
                log.warn("Autopilot failed for store {}: {}", x.getStore().getSlug(), e.getMessage());
            }
        }
    }

    public RunResult runNow(Long ownerId) {
        Store s = stores.requireStore(ownerId);
        AdSettings x = ads.settings(s);
        if (!x.isAutopilotEnabled()) throw ApiException.badRequest("Turn on the autopilot first.");
        return run(s);
    }

    RunResult run(Store s) {
        AdSettings x = ads.settings(s);
        List<AutopilotLog> made = new ArrayList<>();
        int paused = 0, raised = 0, launched = 0, suggested = 0;

        try {
            sync.syncStore(s.getId());
        } catch (RuntimeException e) {
            log.info("Autopilot sync for {} failed: {}", s.getSlug(), e.getMessage());
        }

        List<AdCampaign> all = campaigns.findByStoreIdOrderByCreatedAtDesc(s.getId());
        Map<Long, long[]> adOrders = new HashMap<>();
        Map<Long, BigDecimal> adRevenue = new HashMap<>();
        for (ShopOrder o : orders.findByStoreIdAndAdCampaignIdIsNotNullAndCreatedAtAfter(s.getId(), Instant.EPOCH)) {
            if (!o.getStatus().countsAsSale()) continue;
            adOrders.computeIfAbsent(o.getAdCampaignId(), k -> new long[1])[0]++;
            adRevenue.merge(o.getAdCampaignId(), o.getTotal(), BigDecimal::add);
        }

        // 1) Judge the autopilot's running ads.
        BigDecimal maxBudget = props.ads().maxDailyBudget() == null ? x.getPerAdBudget().multiply(BigDecimal.valueOf(3))
                : props.ads().maxDailyBudget();
        BigDecimal running = runningBudget(all);
        for (AdCampaign c : all) {
            if (c.getOrigin() != Origin.AUTOPILOT || c.getStatus() != AdStatus.ACTIVE) continue;
            long ordersCount = adOrders.getOrDefault(c.getId(), new long[1])[0];
            Performance p = new Performance(c.getImpressions(), c.getClicks(), c.getSpend(), ordersCount,
                    inAdCurrency(adRevenue.get(c.getId()), c.getCurrency(), s.getCurrency(), x.getFxRate()),
                    c.getDailyBudget(),
                    c.getLaunchedAt() == null ? 0 : Duration.between(c.getLaunchedAt(), Instant.now()).toDays());
            Decision d = AutopilotRules.judge(p, x.getMinCtr(), x.getMaxCpc(), maxBudget.min(x.getDailyBudgetCap()),
                    c.getCurrency());
            try {
                switch (d.verdict()) {
                    case PAUSE -> {
                        ads.setActive(c, false, true);
                        running = running.subtract(c.getDailyBudget());
                        made.add(note(s, c, Action.PAUSED, "Paused \"" + c.getHeadline() + "\": " + d.reason()));
                        paused++;
                    }
                    case BUDGET_UP -> {
                        BigDecimal extra = d.newBudget().subtract(c.getDailyBudget());
                        if (running.add(extra).compareTo(x.getDailyBudgetCap()) <= 0) {
                            ads.budget(s.getOwner().getId(), c.getId(), d.newBudget());
                            running = running.add(extra);
                            made.add(note(s, c, Action.BUDGET_UP, "\"" + c.getHeadline() + "\" is a winner. " + d.reason()));
                            raised++;
                        }
                    }
                    case KEEP -> { }
                }
            } catch (ApiException e) {
                made.add(note(s, c, Action.ERROR, "Couldn't update \"" + c.getHeadline() + "\": " + e.getMessage()));
            }
        }

        // 2) Fill free slots with new ads written by the AI.
        List<String> networks = new ArrayList<>();
        for (String n : AdsService.split(x.getNetworks())) {
            try {
                ads.readyAccount(s, n);
                networks.add(n);
            } catch (ApiException e) {
                // not connected / not set up: skip this network
            }
        }
        all = campaigns.findByStoreIdOrderByCreatedAtDesc(s.getId());
        int busy = (int) all.stream().filter(c -> c.getOrigin() == Origin.AUTOPILOT
                && (c.getStatus().running() || c.getStatus() == AdStatus.DRAFT)).count();
        int slots = AutopilotRules.openSlots(x.getMaxActiveAds(), busy);
        if (networks.isEmpty()) {
            made.add(note(s, null, Action.SKIPPED,
                    "Connect Facebook & Instagram or TikTok on this page so the autopilot can run ads."));
        } else if (slots > 0) {
            BigDecimal min = ads.minBudget(ads.readyAccount(s, networks.get(0)));
            BigDecimal budget = AutopilotRules.budgetForNew(x.getDailyBudgetCap(), runningBudget(all), x.getPerAdBudget(), min);
            List<Product> candidates = candidates(s, all, networks);
            if (budget == null) {
                made.add(note(s, null, Action.SKIPPED, "Your daily ad limit is already in use, so no new ads were started."));
            } else if (candidates.isEmpty()) {
                made.add(note(s, null, Action.SKIPPED,
                        "No products to advertise: add photos and keep products in stock."));
            } else {
                try {
                    JsonNode res = ai.metered(new Prepared(s.getId(), s.isWhatsappOrders(),
                            body(s, x, candidates, all, adOrders, slots, networks, budget)), "/v1/ads-autopilot");
                    BigDecimal used = runningBudget(all);
                    for (JsonNode pick : res.path("picks")) {
                        if (launched + suggested >= slots) break;
                        // The AI's network if it fits the budget (TikTok needs a bigger daily minimum), else another one.
                        List<String> order = new ArrayList<>(networks);
                        String wanted = pick.path("network").asText();
                        if (order.remove(wanted)) order.add(0, wanted);
                        String network = null;
                        BigDecimal b = null;
                        for (String n : order) {
                            b = AutopilotRules.budgetForNew(x.getDailyBudgetCap(), used, x.getPerAdBudget(),
                                    ads.minBudget(ads.readyAccount(s, n)));
                            if (b != null) {
                                network = n;
                                break;
                            }
                        }
                        if (network == null) {
                            made.add(note(s, null, Action.SKIPPED, "The daily limit left isn't enough for another ad."));
                            break;
                        }
                        try {
                            AdCampaign c = ads.prepare(s, network, pick.path("product_id").asLong(),
                                    pick.path("headline").asText(), pick.path("primary_text").asText(),
                                    pick.path("description").asText(null), pick.path("call_to_action").asText("SHOP_NOW"),
                                    b, null, AdsService.split(x.getCountries()), x.getAgeMin(), x.getAgeMax(),
                                    Origin.AUTOPILOT, AdsService.cut(pick.path("reason").asText(null), 500));
                            used = used.add(b);
                            if (x.isAutoLaunch()) {
                                c = ads.doLaunch(c);
                                if (c.getStatus() == AdStatus.ERROR) {
                                    made.add(note(s, c, Action.ERROR, "Couldn't launch \"" + c.getHeadline() + "\": " + c.getLastError()));
                                } else {
                                    made.add(note(s, c, Action.LAUNCHED, "Launched \"" + c.getHeadline() + "\" for "
                                            + c.getProductName() + " at " + b.toPlainString() + " " + c.getCurrency() + "/day. "
                                            + nz(c.getAiReason())));
                                    launched++;
                                }
                            } else {
                                made.add(note(s, c, Action.SUGGESTED, "Suggested an ad for " + c.getProductName()
                                        + ". Approve it below to launch. " + nz(c.getAiReason())));
                                suggested++;
                            }
                        } catch (ApiException e) {
                            made.add(note(s, null, Action.ERROR, "Skipped a product: " + e.getMessage()));
                        }
                    }
                } catch (ApiException e) {
                    made.add(note(s, null, Action.ERROR, "The AI couldn't plan new ads: " + e.getMessage()));
                }
            }
        }

        String summary = paused + raised + launched + suggested == 0 ? "Checked your ads: nothing needed changing."
                : String.join(", ", parts(paused, "paused", raised, "budget raised", launched, "launched", suggested, "suggested")) + ".";
        x.setLastRunAt(Instant.now());
        x.setLastRunSummary(summary);
        settingsRepo.save(x);
        log.info("Autopilot for {}: {}", s.getSlug(), summary);
        return new RunResult(summary, made.stream().map(AdsService::logView).toList());
    }

    private static List<String> parts(Object... pairs) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < pairs.length; i += 2) {
            int n = (Integer) pairs[i];
            if (n > 0) out.add(n + " " + pairs[i + 1]);
        }
        return out;
    }

    /** Products worth advertising: available, with a photo (real networks), not already running in an ad. */
    private List<Product> candidates(Store s, List<AdCampaign> all, List<String> networks) {
        Set<Long> busy = new HashSet<>();
        Instant cooldown = Instant.now().minus(Duration.ofDays(14));
        for (AdCampaign c : all) {
            if (c.getStatus().running() || c.getStatus() == AdStatus.DRAFT) busy.add(c.getProductId());
            if (c.isPausedByAutopilot() && c.getPausedAt() != null && c.getPausedAt().isAfter(cooldown)) {
                busy.add(c.getProductId());
            }
        }
        boolean needsPhoto = networks.stream().noneMatch(n -> accounts.findByStoreIdAndNetwork(s.getId(), n)
                .map(AdAccount::isSimulated).orElse(false));
        return products.findByStoreIdOrderByCreatedAtDesc(s.getId()).stream()
                .filter(Product::isAvailable)
                .filter(p -> !busy.contains(p.getId()))
                .filter(p -> !needsPhoto || p.getImageUrl() != null)
                .limit(40)
                .toList();
    }

    private ObjectNode body(Store s, AdSettings x, List<Product> candidates, List<AdCampaign> all,
                            Map<Long, long[]> adOrders, int slots, List<String> networks, BigDecimal budget) {
        Map<Long, int[]> units = new HashMap<>();
        Map<Long, BigDecimal> revenue = new HashMap<>();
        Instant since30 = Instant.now().minus(Duration.ofDays(30));
        Instant since7 = Instant.now().minus(Duration.ofDays(7));
        for (ShopOrder o : orders.findByStoreIdAndCreatedAtAfter(s.getId(), since30)) {
            if (!o.getStatus().countsAsSale()) continue;
            Instant when = o.getPaidAt() != null ? o.getPaidAt() : o.getCreatedAt();
            for (OrderItem i : o.getItems()) {
                if (i.getProductId() == null) continue;
                int[] u = units.computeIfAbsent(i.getProductId(), k -> new int[2]);
                u[0] += i.getQuantity();
                if (when.isAfter(since7)) u[1] += i.getQuantity();
                revenue.merge(i.getProductId(), i.lineTotal(), BigDecimal::add);
            }
        }
        ObjectNode body = ads.storeNode(s);
        ArrayNode ps = body.putArray("products");
        for (Product p : candidates) {
            ObjectNode n = ads.productNode(p);
            int[] u = units.getOrDefault(p.getId(), new int[2]);
            n.put("units_30", u[0]);
            n.put("units_7", u[1]);
            n.put("revenue_30", revenue.getOrDefault(p.getId(), BigDecimal.ZERO));
            double bestCtr = 0;
            int pastAds = 0;
            for (AdCampaign c : all) {
                if (!p.getId().equals(c.getProductId()) || c.getImpressions() == 0) continue;
                pastAds++;
                bestCtr = Math.max(bestCtr, c.getClicks() * 100.0 / c.getImpressions());
            }
            n.put("past_ads", pastAds);
            n.put("best_ctr", AdsService.round2(bestCtr));
            ps.add(n);
        }
        ArrayNode current = body.putArray("running_ads");
        for (AdCampaign c : all) {
            if (!c.getStatus().running() && c.getStatus() != AdStatus.PAUSED) continue;
            ObjectNode n = current.addObject();
            n.put("product_id", c.getProductId());
            n.put("product_name", c.getProductName());
            n.put("network", c.getNetwork());
            n.put("status", c.getStatus().name());
            n.put("ctr", c.getImpressions() > 0 ? AdsService.round2(c.getClicks() * 100.0 / c.getImpressions()) : 0);
            n.put("orders", adOrders.getOrDefault(c.getId(), new long[1])[0]);
        }
        body.put("slots", slots);
        ArrayNode nets = body.putArray("networks");
        networks.forEach(nets::add);
        body.put("budget_per_ad", budget);
        body.put("ad_currency", ads.readyAccount(s, networks.get(0)).getCurrency());
        ObjectNode audience = body.putObject("audience");
        ArrayNode countries = audience.putArray("countries");
        AdsService.split(x.getCountries()).forEach(countries::add);
        audience.put("age_min", x.getAgeMin());
        audience.put("age_max", x.getAgeMax());
        body.put("language", "English");
        return body;
    }

    static BigDecimal runningBudget(List<AdCampaign> all) {
        return all.stream().filter(c -> c.getOrigin() == Origin.AUTOPILOT && c.getStatus().running())
                .map(AdCampaign::getDailyBudget).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /** Sales converted to the ad account's currency, or null when the currencies differ and no rate is set. */
    static BigDecimal inAdCurrency(BigDecimal revenue, String adCurrency, String shopCurrency, BigDecimal fx) {
        if (revenue == null) return BigDecimal.ZERO;
        if (adCurrency == null || adCurrency.equalsIgnoreCase(shopCurrency)) return revenue;
        if (fx == null || fx.signum() <= 0) return null;
        return revenue.divide(fx, 2, RoundingMode.HALF_UP);
    }

    private AutopilotLog note(Store s, AdCampaign c, Action action, String message) {
        return logs.save(new AutopilotLog(s.getId(), c == null ? null : c.getId(), action, message));
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
