package com.litemarket.ads;

import com.litemarket.store.Store;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;

/** A seller's AI autopilot settings and spending limits. */
@Entity
@Table(name = "ad_settings")
public class AdSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    @JoinColumn(name = "store_id", unique = true)
    private Store store;

    private boolean autopilotEnabled;

    /** true: the autopilot launches ads by itself. false: it suggests them and the seller approves. */
    private boolean autoLaunch = true;

    /** Comma-separated networks the autopilot may use, e.g. "meta,tiktok". */
    @Column(length = 40)
    private String networks = "meta";

    /** Most the autopilot may have running per day across all ads (ad account currency). */
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal dailyBudgetCap = new BigDecimal("10.00");

    /** Daily budget the autopilot gives each new ad. */
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal perAdBudget = new BigDecimal("5.00");

    private int maxActiveAds = 3;

    @Column(length = 100)
    private String countries = "GH";

    private int ageMin = 18;

    private int ageMax = 55;

    /** Pause ads whose click-through rate (percent) stays below this after enough views. */
    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal minCtr = new BigDecimal("0.80");

    /** Pause ads whose cost per click goes above this (ad account currency). Empty = no limit. */
    @Column(precision = 12, scale = 2)
    private BigDecimal maxCpc;

    /** Shop-currency value of 1 unit of the ad account currency (e.g. 1 USD = 15.5 GHS), for return on ad spend. */
    @Column(precision = 14, scale = 4)
    private BigDecimal fxRate;

    private Instant termsAcceptedAt;

    private Instant lastRunAt;

    @Column(length = 600)
    private String lastRunSummary;

    public Long getId() { return id; }
    public Store getStore() { return store; }
    public void setStore(Store store) { this.store = store; }
    public boolean isAutopilotEnabled() { return autopilotEnabled; }
    public void setAutopilotEnabled(boolean autopilotEnabled) { this.autopilotEnabled = autopilotEnabled; }
    public boolean isAutoLaunch() { return autoLaunch; }
    public void setAutoLaunch(boolean autoLaunch) { this.autoLaunch = autoLaunch; }
    public String getNetworks() { return networks; }
    public void setNetworks(String networks) { this.networks = networks; }
    public BigDecimal getDailyBudgetCap() { return dailyBudgetCap; }
    public void setDailyBudgetCap(BigDecimal dailyBudgetCap) { this.dailyBudgetCap = dailyBudgetCap; }
    public BigDecimal getPerAdBudget() { return perAdBudget; }
    public void setPerAdBudget(BigDecimal perAdBudget) { this.perAdBudget = perAdBudget; }
    public int getMaxActiveAds() { return maxActiveAds; }
    public void setMaxActiveAds(int maxActiveAds) { this.maxActiveAds = maxActiveAds; }
    public String getCountries() { return countries; }
    public void setCountries(String countries) { this.countries = countries; }
    public int getAgeMin() { return ageMin; }
    public void setAgeMin(int ageMin) { this.ageMin = ageMin; }
    public int getAgeMax() { return ageMax; }
    public void setAgeMax(int ageMax) { this.ageMax = ageMax; }
    public BigDecimal getMinCtr() { return minCtr; }
    public void setMinCtr(BigDecimal minCtr) { this.minCtr = minCtr; }
    public BigDecimal getMaxCpc() { return maxCpc; }
    public void setMaxCpc(BigDecimal maxCpc) { this.maxCpc = maxCpc; }
    public BigDecimal getFxRate() { return fxRate; }
    public void setFxRate(BigDecimal fxRate) { this.fxRate = fxRate; }
    public Instant getTermsAcceptedAt() { return termsAcceptedAt; }
    public void setTermsAcceptedAt(Instant termsAcceptedAt) { this.termsAcceptedAt = termsAcceptedAt; }
    public Instant getLastRunAt() { return lastRunAt; }
    public void setLastRunAt(Instant lastRunAt) { this.lastRunAt = lastRunAt; }
    public String getLastRunSummary() { return lastRunSummary; }
    public void setLastRunSummary(String lastRunSummary) { this.lastRunSummary = lastRunSummary; }
}
