package com.litemarket.ads;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

/** What the autopilot did and why, shown on the seller's Ads page. */
@Entity
@Table(name = "autopilot_log")
public class AutopilotLog {

    public enum Action { LAUNCHED, SUGGESTED, PAUSED, BUDGET_UP, KEPT, SKIPPED, ERROR, INFO }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long storeId;

    private Long adCampaignId;

    @Column(nullable = false, length = 20)
    private String action;

    @Column(nullable = false, length = 500)
    private String message;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    public AutopilotLog() {}

    public AutopilotLog(Long storeId, Long adCampaignId, Action action, String message) {
        this.storeId = storeId;
        this.adCampaignId = adCampaignId;
        this.action = action.name();
        this.message = message == null ? "" : message.length() > 500 ? message.substring(0, 500) : message;
    }

    public Long getId() { return id; }
    public Long getStoreId() { return storeId; }
    public Long getAdCampaignId() { return adCampaignId; }
    public String getAction() { return action; }
    public String getMessage() { return message; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
