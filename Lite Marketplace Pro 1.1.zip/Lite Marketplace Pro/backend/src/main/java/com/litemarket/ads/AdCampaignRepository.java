package com.litemarket.ads;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface AdCampaignRepository extends JpaRepository<AdCampaign, Long> {

    List<AdCampaign> findByStoreIdOrderByCreatedAtDesc(Long storeId);

    Optional<AdCampaign> findByIdAndStoreId(Long id, Long storeId);

    List<AdCampaign> findByStatusIn(Collection<AdStatus> statuses);

    List<AdCampaign> findByStoreIdAndStatusIn(Long storeId, Collection<AdStatus> statuses);
}
