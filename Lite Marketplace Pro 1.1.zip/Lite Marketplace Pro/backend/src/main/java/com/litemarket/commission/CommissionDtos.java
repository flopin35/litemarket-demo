package com.litemarket.commission;

import com.litemarket.payment.PaymentDtos.PaymentView;
import com.litemarket.payment.gateway.GatewayModels.ProviderOption;
import jakarta.validation.constraints.NotBlank;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public final class CommissionDtos {

    private CommissionDtos() {}

    public record EntryView(
            Long id,
            String orderNumber,
            BigDecimal orderTotal,
            BigDecimal percent,
            BigDecimal amount,
            String currency,
            String kind,
            String status,
            Instant createdAt,
            Instant settledAt) {}

    /** The seller's Earnings page. */
    public record EarningsView(
            String currency,
            BigDecimal percent,
            boolean chargesWhatsappOrders,
            BigDecimal due,
            BigDecimal dueLimit,
            boolean whatsappPaused,
            BigDecimal paidThisMonth,
            BigDecimal paidAllTime,
            BigDecimal salesThisMonth,
            BigDecimal owedToYou,
            List<ProviderOption> providers,
            List<EntryView> entries,
            List<PaymentView> payments) {}

    public record PayCommissionRequest(@NotBlank String provider) {}
}
