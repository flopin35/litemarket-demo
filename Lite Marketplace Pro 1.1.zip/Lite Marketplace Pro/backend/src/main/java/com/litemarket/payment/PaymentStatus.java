package com.litemarket.payment;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED
}
