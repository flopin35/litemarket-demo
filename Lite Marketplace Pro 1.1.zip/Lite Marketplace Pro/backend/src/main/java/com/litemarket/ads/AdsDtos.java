package com.litemarket.ads;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

/** Ads API shapes. Everything here is only ever shown to the seller who owns the ads. */
public final class AdsDtos {

    private AdsDtos() {}

    /** One network card on the Ads page. status: DISCONNECTED, NEEDS_SETUP, CONNECTED or RECONNECT. */
    public record NetworkView(
            String network,
            String label,
            boolean simulated,
            String status,
            String accountName,
            String currency,
            BigDecimal minDailyBudget,
            String pageName,
            String instagramUsername,
            String identityName,
            Instant tokenExpiresAt) {}

    public record OptionView(String id, String name, String currency, BigDecimal minDailyBudget,
                             String linkedId, String linkedName, String type) {}

    public record AssetsView(List<OptionView> adAccounts, List<OptionView> pages, List<OptionView> identities) {}

    public record SelectAccountRequest(
            @NotBlank @Size(max = 64) String adAccountId,
            @Size(max = 64) String pageId,
            @Size(max = 64) String identityId) {}

    public record ConnectView(String url) {}

    public record AdView(
            Long id,
            String network,
            Long productId,
            String productName,
            String imageUrl,
            String status,
            String origin,
            String headline,
            String primaryText,
            String description,
            String callToAction,
            BigDecimal dailyBudget,
            String currency,
            List<String> countries,
            Integer ageMin,
            Integer ageMax,
            LocalDate endDate,
            String reviewNote,
            String lastError,
            String aiReason,
            long impressions,
            long clicks,
            BigDecimal spend,
            long visits,
            long whatsappClicks,
            long orders,
            BigDecimal revenue,
            Double ctr,
            BigDecimal cpc,
            Instant createdAt,
            Instant launchedAt,
            Instant lastSyncedAt) {}

    public record LaunchRequest(
            @NotBlank @Pattern(regexp = "meta|tiktok") String network,
            @NotNull Long productId,
            @NotBlank @Size(max = 40) String headline,
            @NotBlank @Size(max = 500) String primaryText,
            @Size(max = 60) String description,
            @Pattern(regexp = "SHOP_NOW|ORDER_NOW|LEARN_MORE|BUY_NOW") String callToAction,
            @NotNull @DecimalMin("0.5") BigDecimal dailyBudget,
            @Min(1) @Max(90) Integer days,
            @Size(max = 10) List<@Pattern(regexp = "[A-Za-z]{2}|\\d{3,10}") String> countries,
            @Min(13) @Max(65) Integer ageMin,
            @Min(13) @Max(65) Integer ageMax) {}

    public record BudgetRequest(@NotNull @DecimalMin("0.5") BigDecimal dailyBudget) {}

    public record AdCopyRequest(
            @NotNull Long productId,
            @NotBlank @Pattern(regexp = "meta|tiktok") String network,
            @Size(max = 20) String tone,
            @Size(max = 20) String language) {}

    public record SettingsView(
            boolean autopilotEnabled,
            boolean autoLaunch,
            List<String> networks,
            BigDecimal dailyBudgetCap,
            BigDecimal perAdBudget,
            int maxActiveAds,
            List<String> countries,
            int ageMin,
            int ageMax,
            BigDecimal minCtr,
            BigDecimal maxCpc,
            BigDecimal fxRate,
            boolean termsAccepted,
            Instant lastRunAt,
            String lastRunSummary) {}

    public record SettingsRequest(
            boolean autopilotEnabled,
            boolean autoLaunch,
            @NotNull @Size(min = 1, max = 2) List<@Pattern(regexp = "meta|tiktok") String> networks,
            @NotNull @DecimalMin("0") BigDecimal dailyBudgetCap,
            @NotNull @DecimalMin("0.5") BigDecimal perAdBudget,
            @Min(1) @Max(10) int maxActiveAds,
            @Size(max = 10) List<@Pattern(regexp = "[A-Za-z]{2}|\\d{3,10}") String> countries,
            @Min(13) @Max(65) int ageMin,
            @Min(13) @Max(65) int ageMax,
            @NotNull @DecimalMin("0") BigDecimal minCtr,
            @DecimalMin("0") BigDecimal maxCpc,
            @DecimalMin("0") BigDecimal fxRate,
            boolean acceptTerms) {}

    public record LogView(Long id, String action, String message, Long adId, Instant createdAt) {}

    /** Everything the Ads page needs in one call. */
    public record AdsOverview(
            String shopCurrency,
            BigDecimal maxDailyBudget,
            List<NetworkView> networks,
            SettingsView settings,
            List<AdView> ads,
            List<LogView> activity) {}

    public record Totals(
            long impressions,
            long clicks,
            BigDecimal spend,
            long visits,
            long whatsappClicks,
            long orders,
            BigDecimal revenue,
            Double ctr,
            BigDecimal cpc,
            Double roas,
            int activeAds) {}

    public record StatDay(LocalDate date, long impressions, long clicks, BigDecimal spend, long orders,
                          BigDecimal revenue) {}

    public record NetworkTotals(String network, String currency, long impressions, long clicks, BigDecimal spend,
                                long orders, BigDecimal revenue) {}

    /**
     * Ad results for the last {@code days} days. Spend is in {@code spendCurrency} (the ad accounts' currency);
     * sales are in the shop's currency. roas = sales / spend, using fxRate when the currencies differ.
     */
    public record StatsView(
            int days,
            String shopCurrency,
            String spendCurrency,
            Totals totals,
            List<StatDay> daily,
            List<NetworkTotals> byNetwork) {}

    public record RunResult(String summary, List<LogView> actions) {}

    public record TrackRequest(
            @NotBlank @Pattern(regexp = "ad\\d{1,15}") String ref,
            @NotBlank @Pattern(regexp = "visit|whatsapp") String event) {}
}
