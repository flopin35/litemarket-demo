package com.litemarket.payment;

public enum PaymentPurpose {
    /** A customer paying for an order. */
    ORDER,
    /** A seller paying the commission owed on WhatsApp and hand-added orders. */
    COMMISSION
}
