package com.litemarket.ads;

import com.litemarket.store.Store;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.math.BigDecimal;
import java.time.Instant;

/** A seller's connected ad account on one network (meta or tiktok). The access token is stored encrypted. */
@Entity
@Table(name = "ad_accounts", uniqueConstraints = @UniqueConstraint(columnNames = {"store_id", "network"}))
public class AdAccount {

    public enum State { NEEDS_SETUP, CONNECTED, RECONNECT }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "store_id")
    private Store store;

    @Column(nullable = false, length = 20)
    private String network;

    @Column(nullable = false, length = 20)
    private String state = State.NEEDS_SETUP.name();

    /** True for the demo ad network (nothing real is created). */
    private boolean simulated;

    @Column(length = 4000)
    private String tokenEncrypted;

    private Instant tokenExpiresAt;

    /** Ad accounts the seller allowed during sign-in (TikTok returns them with the token). */
    @Column(length = 1000)
    private String grantedAccountIds;

    @Column(length = 64)
    private String adAccountId;

    @Column(length = 160)
    private String adAccountName;

    @Column(length = 3)
    private String currency;

    @Column(precision = 12, scale = 2)
    private BigDecimal minDailyBudget;

    @Column(length = 64)
    private String pageId;

    @Column(length = 160)
    private String pageName;

    @Column(length = 64)
    private String instagramUserId;

    @Column(length = 160)
    private String instagramUsername;

    @Column(length = 64)
    private String identityId;

    @Column(length = 30)
    private String identityType;

    @Column(length = 160)
    private String identityName;

    @Column(nullable = false)
    private Instant connectedAt = Instant.now();

    public Long getId() { return id; }
    public Store getStore() { return store; }
    public void setStore(Store store) { this.store = store; }
    public String getNetwork() { return network; }
    public void setNetwork(String network) { this.network = network; }
    public State getState() { return State.valueOf(state); }
    public void setState(State state) { this.state = state.name(); }
    public boolean isSimulated() { return simulated; }
    public void setSimulated(boolean simulated) { this.simulated = simulated; }
    public String getTokenEncrypted() { return tokenEncrypted; }
    public void setTokenEncrypted(String tokenEncrypted) { this.tokenEncrypted = tokenEncrypted; }
    public Instant getTokenExpiresAt() { return tokenExpiresAt; }
    public void setTokenExpiresAt(Instant tokenExpiresAt) { this.tokenExpiresAt = tokenExpiresAt; }
    public String getGrantedAccountIds() { return grantedAccountIds; }
    public void setGrantedAccountIds(String grantedAccountIds) { this.grantedAccountIds = grantedAccountIds; }
    public String getAdAccountId() { return adAccountId; }
    public void setAdAccountId(String adAccountId) { this.adAccountId = adAccountId; }
    public String getAdAccountName() { return adAccountName; }
    public void setAdAccountName(String adAccountName) { this.adAccountName = adAccountName; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public BigDecimal getMinDailyBudget() { return minDailyBudget; }
    public void setMinDailyBudget(BigDecimal minDailyBudget) { this.minDailyBudget = minDailyBudget; }
    public String getPageId() { return pageId; }
    public void setPageId(String pageId) { this.pageId = pageId; }
    public String getPageName() { return pageName; }
    public void setPageName(String pageName) { this.pageName = pageName; }
    public String getInstagramUserId() { return instagramUserId; }
    public void setInstagramUserId(String instagramUserId) { this.instagramUserId = instagramUserId; }
    public String getInstagramUsername() { return instagramUsername; }
    public void setInstagramUsername(String instagramUsername) { this.instagramUsername = instagramUsername; }
    public String getIdentityId() { return identityId; }
    public void setIdentityId(String identityId) { this.identityId = identityId; }
    public String getIdentityType() { return identityType; }
    public void setIdentityType(String identityType) { this.identityType = identityType; }
    public String getIdentityName() { return identityName; }
    public void setIdentityName(String identityName) { this.identityName = identityName; }
    public Instant getConnectedAt() { return connectedAt; }
    public void setConnectedAt(Instant connectedAt) { this.connectedAt = connectedAt; }
}
