package com.litemarket.ai;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;

/** AI credit period rules with no framework dependencies (unit-tested in CreditMathTest). */
public final class CreditMath {

    private CreditMath() {}

    /** First day of the month that {@code now} falls in (UTC). AI credits reset on this day. */
    public static LocalDate periodStart(Instant now) {
        return LocalDate.ofInstant(now, ZoneOffset.UTC).withDayOfMonth(1);
    }

    /** AI credits already used in the current period (0 when the stored period is older). */
    public static int used(LocalDate storedPeriodStart, int storedUsed, Instant now) {
        if (storedPeriodStart == null || storedPeriodStart.isBefore(periodStart(now))) return 0;
        return storedUsed;
    }
}
