package com.litemarket.ads;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AdSettingsRepository extends JpaRepository<AdSettings, Long> {

    Optional<AdSettings> findByStoreId(Long storeId);

    List<AdSettings> findByAutopilotEnabledTrue();
}
