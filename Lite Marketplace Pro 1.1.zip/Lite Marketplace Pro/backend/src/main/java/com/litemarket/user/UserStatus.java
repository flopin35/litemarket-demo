package com.litemarket.user;

public enum UserStatus {
    ACTIVE,
    SUSPENDED
}
