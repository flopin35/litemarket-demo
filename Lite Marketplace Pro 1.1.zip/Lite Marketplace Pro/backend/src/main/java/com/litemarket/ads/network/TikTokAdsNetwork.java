package com.litemarket.ads.network;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.Assets;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.Image;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Option;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdModels.TokenGrant;
import com.litemarket.payment.gateway.GatewayException;
import com.litemarket.payment.gateway.HttpJson;
import com.litemarket.payment.gateway.HttpJson.Response;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * TikTok ads through the TikTok API for Business (v1.3). One ad = a traffic campaign, an ad group (budget,
 * audience, TikTok placement) and a photo carousel ad that links to the product page.
 * <p>
 * TikTok specifics handled here: the TikTok placement doesn't run single-photo ads, so photo ads are carousels
 * (2+ photos plus music); since 2026 new ads must use the seller's own TikTok account as the identity; budgets
 * are in the account currency (major units) with a minimum of about 20 USD per ad group per day.
 * Docs: https://business-api.tiktok.com/portal/docs
 */
public class TikTokAdsNetwork implements AdNetwork {

    private static final DateTimeFormatter TT_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneOffset.UTC);

    /** GeoNames ids TikTok uses as location_ids for whole countries. */
    static final Map<String, String> COUNTRY_LOCATION_IDS = Map.ofEntries(
            Map.entry("GH", "2300660"), Map.entry("NG", "2328926"), Map.entry("KE", "192950"),
            Map.entry("ZA", "953987"), Map.entry("CI", "2287781"), Map.entry("SN", "2245662"),
            Map.entry("CM", "2233387"), Map.entry("UG", "226074"), Map.entry("TZ", "149590"),
            Map.entry("RW", "49518"), Map.entry("EG", "357994"), Map.entry("MA", "2542007"),
            Map.entry("US", "6252001"), Map.entry("GB", "2635167"), Map.entry("CA", "6251999"));

    private static final Set<String> CTAS = Set.of("SHOP_NOW", "LEARN_MORE", "ORDER_NOW", "CONTACT_US");

    private final String appId;
    private final String secret;
    private final String base;
    private final String authUrl;
    private final BigDecimal minDaily;
    private final String musicId;
    private final HttpJson http;

    public TikTokAdsNetwork(String appId, String secret, String baseUrl, String authUrl, BigDecimal minDaily,
                            String musicId, HttpJson http) {
        this.appId = appId == null ? "" : appId.trim();
        this.secret = secret == null ? "" : secret.trim();
        this.base = trim(baseUrl, "https://business-api.tiktok.com/open_api/v1.3");
        this.authUrl = trim(authUrl, "https://business-api.tiktok.com/portal/auth");
        this.minDaily = minDaily == null ? new BigDecimal("20") : minDaily;
        this.musicId = musicId == null ? "" : musicId.trim();
        this.http = http;
    }

    @Override public String id() { return "tiktok"; }

    @Override public String label() { return "TikTok"; }

    @Override public boolean enabled() { return !appId.isEmpty() && !secret.isEmpty(); }

    @Override public BigDecimal minDailyBudget(AccountRef account) { return minDaily; }

    // ── Sign-in ────────────────────────────────────────────────────────────────

    @Override
    public String authorizeUrl(String state, String redirectUri) {
        return authUrl + "?app_id=" + HttpJson.enc(appId) + "&state=" + HttpJson.enc(state)
                + "&redirect_uri=" + HttpJson.enc(redirectUri);
    }

    @Override
    public TokenGrant exchangeCode(String code, String redirectUri) {
        ObjectNode body = http.mapper().createObjectNode();
        body.put("app_id", appId);
        body.put("secret", secret);
        body.put("auth_code", code);
        JsonNode data = data(postJson(null, "/oauth2/access_token/", body));
        String token = data.path("access_token").asText("");
        if (token.isEmpty()) throw new AdsException("TikTok didn't return an access token. Try connecting again.");
        List<String> ids = new ArrayList<>();
        data.path("advertiser_ids").forEach(n -> ids.add(n.asText()));
        // TikTok advertiser tokens don't expire on their own; they stop working if the seller removes access.
        return new TokenGrant(token, null, ids);
    }

    @Override
    public Assets assets(String token, List<String> granted, String selectedAccount, String currencyHint) {
        List<String> ids = new ArrayList<>(granted == null ? List.of() : granted);
        if (ids.isEmpty()) {
            JsonNode d = data(get(token, "/oauth2/advertiser/get/?app_id=" + HttpJson.enc(appId)
                    + "&secret=" + HttpJson.enc(secret)));
            d.path("list").forEach(n -> ids.add(n.path("advertiser_id").asText()));
        }
        List<Option> accounts = new ArrayList<>();
        if (!ids.isEmpty()) {
            JsonNode info = data(get(token, "/advertiser/info/?advertiser_ids=" + jsonList(ids)
                    + "&fields=" + HttpJson.enc("[\"advertiser_id\",\"name\",\"currency\",\"status\"]")));
            for (JsonNode a : info.path("list")) {
                accounts.add(new Option(a.path("advertiser_id").asText(), a.path("name").asText(),
                        a.path("currency").asText("USD"), minDaily, null, null,
                        "STATUS_ENABLE".equals(a.path("status").asText()) ? "ACTIVE" : "INACTIVE"));
            }
        }
        List<Option> identities = new ArrayList<>();
        String advertiser = selectedAccount != null && !selectedAccount.isBlank() ? selectedAccount
                : accounts.isEmpty() ? null : accounts.get(0).id();
        if (advertiser != null) {
            JsonNode d = data(get(token, "/identity/get/?advertiser_id=" + HttpJson.enc(advertiser)
                    + "&identity_type=TT_USER"));
            for (JsonNode i : d.path("identity_list")) {
                identities.add(new Option(i.path("identity_id").asText(), i.path("display_name").asText("TikTok account"),
                        null, null, advertiser, null, i.path("identity_type").asText("TT_USER")));
            }
        }
        return new Assets(accounts, List.of(), identities);
    }

    // ── Creating ads ───────────────────────────────────────────────────────────

    @Override
    public Launched launch(AccountRef a, LaunchSpec spec) {
        if (a.identityId() == null || a.identityId().isBlank()) {
            throw new AdsException("Link your TikTok account to your TikTok ad account, then choose it on the Ads page.");
        }
        if (spec.images().size() < 2) {
            throw new AdsException("TikTok photo ads need at least 2 product photos. Add photos to more products.");
        }
        if (spec.dailyBudget().compareTo(minDaily) < 0) {
            throw new AdsException("TikTok needs a daily budget of at least " + minDaily.toPlainString() + " " + a.currency() + ".");
        }
        List<String> imageIds = new ArrayList<>();
        for (Image img : spec.images().subList(0, Math.min(5, spec.images().size()))) {
            imageIds.add(uploadImage(a, img));
        }
        String music = musicId.isEmpty() ? pickMusic(a) : musicId;

        ObjectNode campaign = body(a);
        campaign.put("campaign_name", spec.name());
        campaign.put("objective_type", "TRAFFIC");
        campaign.put("budget_mode", "BUDGET_MODE_INFINITE");
        campaign.put("operation_status", "ENABLE");
        String campaignId = data(postJson(a.accessToken(), "/campaign/create/", campaign)).path("campaign_id").asText();
        try {
            ObjectNode group = body(a);
            group.put("campaign_id", campaignId);
            group.put("adgroup_name", spec.name());
            group.put("promotion_type", "WEBSITE");
            group.put("placement_type", "PLACEMENT_TYPE_NORMAL");
            group.putArray("placements").add("PLACEMENT_TIKTOK");
            ArrayNode locations = group.putArray("location_ids");
            locationIds(spec.countries()).forEach(locations::add);
            ArrayNode ages = group.putArray("age_groups");
            ageGroups(spec.ageMin(), spec.ageMax()).forEach(ages::add);
            group.put("gender", "GENDER_UNLIMITED");
            group.put("budget_mode", "BUDGET_MODE_DAY");
            group.put("budget", spec.dailyBudget());
            group.put("schedule_start_time", TT_TIME.format(spec.start()));
            if (spec.endDate() != null) {
                group.put("schedule_type", "SCHEDULE_START_END");
                group.put("schedule_end_time", TT_TIME.format(spec.endDate().plusDays(1).atStartOfDay().toInstant(ZoneOffset.UTC)));
            } else {
                group.put("schedule_type", "SCHEDULE_FROM_NOW");
            }
            group.put("optimization_goal", "CLICK");
            group.put("billing_event", "CPC");
            group.put("bid_type", "BID_TYPE_NO_BID");
            group.put("pacing", "PACING_MODE_SMOOTH");
            group.put("operation_status", "ENABLE");
            String adGroupId = data(postJson(a.accessToken(), "/adgroup/create/", group)).path("adgroup_id").asText();

            ObjectNode ad = body(a);
            ad.put("adgroup_id", adGroupId);
            ObjectNode c = ad.putArray("creatives").addObject();
            c.put("ad_name", spec.name());
            c.put("ad_format", "CAROUSEL_ADS");
            ArrayNode imgs = c.putArray("image_ids");
            imageIds.forEach(imgs::add);
            c.put("music_id", music);
            c.put("ad_text", adText(spec));
            c.put("call_to_action", CTAS.contains(spec.callToAction()) ? spec.callToAction() : "SHOP_NOW");
            c.put("landing_page_url", spec.landingUrl());
            c.put("identity_type", a.identityType() == null ? "TT_USER" : a.identityType());
            c.put("identity_id", a.identityId());
            JsonNode d = data(postJson(a.accessToken(), "/ad/create/", ad));
            String adId = d.path("ad_ids").path(0).asText(d.path("creatives").path(0).path("ad_id").asText(""));
            if (adId.isEmpty()) throw new AdsException("TikTok didn't create the ad. Try again.");
            return new Launched(campaignId, adGroupId, null, adId);
        } catch (AdsException e) {
            try {
                campaignStatus(a, campaignId, "DELETE");
            } catch (AdsException ignored) {
                // best effort clean-up
            }
            throw e;
        }
    }

    /** TikTok ad text is a single line of 1–100 characters. */
    static String adText(LaunchSpec spec) {
        String t = spec.primaryText() == null || spec.primaryText().isBlank() ? spec.headline() : spec.primaryText();
        t = t.replaceAll("\\s+", " ").trim();
        return t.length() <= 100 ? t : t.substring(0, 97).trim() + "...";
    }

    static List<String> locationIds(List<String> countries) {
        List<String> ids = new ArrayList<>();
        for (String c : countries) {
            String code = c.trim().toUpperCase(Locale.ROOT);
            if (code.matches("\\d+")) {
                ids.add(code); // already a TikTok location id
            } else if (COUNTRY_LOCATION_IDS.containsKey(code)) {
                ids.add(COUNTRY_LOCATION_IDS.get(code));
            } else {
                throw new AdsException("TikTok ads here support these countries: "
                        + String.join(", ", COUNTRY_LOCATION_IDS.keySet().stream().sorted().toList())
                        + ". Remove " + code + " or use its TikTok location id.");
            }
        }
        if (ids.isEmpty()) ids.add(COUNTRY_LOCATION_IDS.get("GH"));
        return ids;
    }

    static List<String> ageGroups(int min, int max) {
        int[][] groups = {{18, 24}, {25, 34}, {35, 44}, {45, 54}, {55, 100}};
        String[] names = {"AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54", "AGE_55_100"};
        List<String> out = new ArrayList<>();
        int lo = Math.max(18, min);
        int hi = Math.max(lo, max);
        for (int i = 0; i < groups.length; i++) {
            if (groups[i][1] >= lo && groups[i][0] <= hi) out.add(names[i]);
        }
        return out;
    }

    private String uploadImage(AccountRef a, Image img) {
        String md5;
        try {
            md5 = HexFormat.of().formatHex(MessageDigest.getInstance("MD5").digest(img.bytes()));
        } catch (Exception e) {
            throw new AdsException("Couldn't prepare the photo for TikTok.");
        }
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("advertiser_id", a.adAccountId());
        fields.put("upload_type", "UPLOAD_BY_FILE");
        fields.put("image_signature", md5);
        fields.put("file_name", md5.substring(0, 12) + "-" + img.fileName());
        try {
            Response r = http.postMultipart(base + "/file/image/ad/upload/", Map.of("Access-Token", a.accessToken()),
                    fields, "image_file", img.fileName(), img.mediaType(), img.bytes());
            String id = data(r).path("image_id").asText("");
            if (id.isEmpty()) throw new AdsException("TikTok didn't accept a product photo. Try JPG or PNG photos.");
            return id;
        } catch (GatewayException e) {
            throw new AdsException("We couldn't reach TikTok. Try again in a moment.");
        }
    }

    private String pickMusic(AccountRef a) {
        JsonNode d = data(get(a.accessToken(), "/file/music/get/?advertiser_id=" + HttpJson.enc(a.adAccountId())
                + "&music_scene=CAROUSEL_ADS&page_size=20"));
        for (JsonNode m : d.path("musics")) {
            if (m.hasNonNull("music_id")) return m.path("music_id").asText();
        }
        for (JsonNode m : d.path("list")) {
            if (m.hasNonNull("music_id")) return m.path("music_id").asText();
        }
        throw new AdsException("TikTok photo ads need music. Ask the site owner to set TIKTOK_MUSIC_ID.");
    }

    // ── Managing ───────────────────────────────────────────────────────────────

    @Override
    public void setActive(AccountRef a, Launched ids, boolean active) {
        campaignStatus(a, ids.campaignId(), active ? "ENABLE" : "DISABLE");
    }

    @Override
    public void end(AccountRef a, Launched ids) {
        campaignStatus(a, ids.campaignId(), "DELETE");
    }

    private void campaignStatus(AccountRef a, String campaignId, String status) {
        ObjectNode b = body(a);
        b.putArray("campaign_ids").add(campaignId);
        b.put("operation_status", status);
        data(postJson(a.accessToken(), "/campaign/status/update/", b));
    }

    @Override
    public void updateBudget(AccountRef a, Launched ids, BigDecimal dailyBudget) {
        if (dailyBudget.compareTo(minDaily) < 0) {
            throw new AdsException("TikTok needs a daily budget of at least " + minDaily.toPlainString() + " " + a.currency() + ".");
        }
        ObjectNode b = body(a);
        ObjectNode row = b.putArray("budget").addObject();
        row.put("adgroup_id", ids.adSetId());
        row.put("budget", dailyBudget);
        data(postJson(a.accessToken(), "/adgroup/budget/update/", b));
    }

    @Override
    public Review review(AccountRef a, Launched ids) {
        JsonNode d = data(get(a.accessToken(), "/ad/get/?advertiser_id=" + HttpJson.enc(a.adAccountId())
                + "&filtering=" + HttpJson.enc("{\"ad_ids\":[\"" + ids.adId() + "\"]}")
                + "&fields=" + HttpJson.enc("[\"ad_id\",\"operation_status\",\"secondary_status\"]")));
        JsonNode ad = d.path("list").path(0);
        String secondary = ad.path("secondary_status").asText("");
        String op = ad.path("operation_status").asText("");
        if (secondary.contains("DELETE")) return new Review("ENDED", null);
        if (secondary.contains("NOT_APPROVE") || secondary.contains("REJECT")) {
            return new Review("REJECTED", rejectionReason(a, ids.adId()));
        }
        if (secondary.contains("AUDIT") || secondary.contains("REVIEW")) return new Review("IN_REVIEW", null);
        if ("DISABLE".equals(op) || secondary.contains("DISABLE")) return new Review("PAUSED", null);
        if (secondary.contains("BALANCE")) return new Review("ERROR", "Your TikTok ad account is out of balance. Add funds in TikTok Ads Manager.");
        if (secondary.contains("DELIVERY_OK") || "ENABLE".equals(op)) return new Review("ACTIVE", null);
        return new Review("IN_REVIEW", null);
    }

    private String rejectionReason(AccountRef a, String adId) {
        try {
            JsonNode d = data(get(a.accessToken(), "/ad/review_info/?advertiser_id=" + HttpJson.enc(a.adAccountId())
                    + "&ad_ids=" + jsonList(List.of(adId))));
            List<String> reasons = new ArrayList<>();
            d.findValues("reason").forEach(n -> reasons.add(n.asText()));
            d.findValues("reject_reason").forEach(n -> reasons.add(n.asText()));
            return reasons.isEmpty() ? "TikTok didn't approve this ad." : String.join(" ", reasons);
        } catch (AdsException e) {
            return "TikTok didn't approve this ad.";
        }
    }

    @Override
    public Map<String, List<DayRow>> results(AccountRef a, List<Launched> ads, LocalDate from, LocalDate to) {
        Map<String, List<DayRow>> out = new LinkedHashMap<>();
        Set<String> wanted = new java.util.HashSet<>();
        for (Launched l : ads) {
            wanted.add(l.adId());
            out.put(l.adId(), new ArrayList<>());
        }
        // TikTok allows 30 days per request when grouping by day.
        LocalDate start = from.isBefore(to.minusDays(29)) ? to.minusDays(29) : from;
        JsonNode d = data(get(a.accessToken(), "/report/integrated/get/?advertiser_id=" + HttpJson.enc(a.adAccountId())
                + "&report_type=BASIC&data_level=AUCTION_AD"
                + "&dimensions=" + HttpJson.enc("[\"ad_id\",\"stat_time_day\"]")
                + "&metrics=" + HttpJson.enc("[\"spend\",\"impressions\",\"clicks\",\"reach\"]")
                + "&start_date=" + start + "&end_date=" + to + "&page=1&page_size=1000"));
        for (JsonNode row : d.path("list")) {
            String adId = row.path("dimensions").path("ad_id").asText();
            if (!wanted.contains(adId)) continue;
            JsonNode m = row.path("metrics");
            String day = row.path("dimensions").path("stat_time_day").asText("").split(" ")[0];
            if (day.isEmpty()) continue;
            out.get(adId).add(new DayRow(LocalDate.parse(day),
                    asLong(m.path("impressions")), asLong(m.path("reach")), asLong(m.path("clicks")),
                    new BigDecimal(m.path("spend").asText("0"))));
        }
        return out;
    }

    // ── HTTP ───────────────────────────────────────────────────────────────────

    private ObjectNode body(AccountRef a) {
        ObjectNode b = http.mapper().createObjectNode();
        b.put("advertiser_id", a.adAccountId());
        return b;
    }

    private Response get(String token, String pathAndQuery) {
        try {
            return http.get(base + pathAndQuery, token == null ? Map.of() : Map.of("Access-Token", token));
        } catch (GatewayException e) {
            throw new AdsException("We couldn't reach TikTok. Try again in a moment.");
        }
    }

    private Response postJson(String token, String path, ObjectNode body) {
        try {
            return http.postJson(base + path, token == null ? Map.of() : Map.of("Access-Token", token), body);
        } catch (GatewayException e) {
            throw new AdsException("We couldn't reach TikTok. Try again in a moment.");
        }
    }

    /** TikTok answers HTTP 200 even for errors: code 0 means success. */
    static JsonNode data(Response r) {
        JsonNode j = r.json();
        int code = j.path("code").asInt(r.ok() ? 0 : -1);
        if (code == 0 && r.ok()) return j.path("data");
        String msg = j.path("message").asText("TikTok returned an error (" + r.status() + ").");
        if (code == 40105 || code == 40104) {
            throw new AdsException("Your TikTok connection stopped working. Reconnect it on the Ads page.", true);
        }
        if (code == 40100 || code == 51010) {
            throw new AdsException("TikTok is limiting requests right now. We'll try again shortly.");
        }
        throw new AdsException("TikTok: " + msg);
    }

    private static long asLong(JsonNode n) {
        try {
            return new BigDecimal(n.asText("0")).longValue();
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String jsonList(List<String> ids) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < ids.size(); i++) b.append(i == 0 ? "" : ",").append('"').append(ids.get(i)).append('"');
        return HttpJson.enc(b.append(']').toString());
    }

    private static String trim(String url, String fallback) {
        String u = url == null || url.isBlank() ? fallback : url.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }
}
