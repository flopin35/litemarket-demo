package com.litemarket.ads;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.litemarket.ads.AdCampaign.Origin;
import com.litemarket.ads.AdsDtos.AdCopyRequest;
import com.litemarket.ads.AdsDtos.AdView;
import com.litemarket.ads.AdsDtos.AdsOverview;
import com.litemarket.ads.AdsDtos.AssetsView;
import com.litemarket.ads.AdsDtos.ConnectView;
import com.litemarket.ads.AdsDtos.LaunchRequest;
import com.litemarket.ads.AdsDtos.LogView;
import com.litemarket.ads.AdsDtos.NetworkView;
import com.litemarket.ads.AdsDtos.OptionView;
import com.litemarket.ads.AdsDtos.SelectAccountRequest;
import com.litemarket.ads.AdsDtos.SettingsRequest;
import com.litemarket.ads.AdsDtos.SettingsView;
import com.litemarket.ads.AdsDtos.TrackRequest;
import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.Assets;
import com.litemarket.ads.network.AdModels.Image;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Option;
import com.litemarket.ads.network.AdModels.TokenGrant;
import com.litemarket.ads.network.AdNetwork;
import com.litemarket.ads.network.AdNetworks;
import com.litemarket.ads.network.AdsException;
import com.litemarket.ai.AiContext.Prepared;
import com.litemarket.ai.AiService;
import com.litemarket.common.ApiException;
import com.litemarket.common.Money;
import com.litemarket.config.AppProperties;
import com.litemarket.order.OrderService;
import com.litemarket.order.ShopOrder;
import com.litemarket.order.ShopOrderRepository;
import com.litemarket.product.Product;
import com.litemarket.product.ProductRepository;
import com.litemarket.shop.PublicShopService;
import com.litemarket.store.Store;
import com.litemarket.store.StoreRepository;
import com.litemarket.store.StoreService;
import com.litemarket.upload.StorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Sellers' social ads: connecting Facebook/Instagram and TikTok ad accounts, creating ads for products,
 * pausing/resuming them, and the numbers. Network calls happen outside database transactions; each save
 * is its own short transaction.
 */
@Service
public class AdsService {

    private static final Logger log = LoggerFactory.getLogger(AdsService.class);
    static final List<AdStatus> LIVE = List.of(AdStatus.IN_REVIEW, AdStatus.ACTIVE, AdStatus.PAUSED);

    private final AdAccountRepository accounts;
    private final AdCampaignRepository campaigns;
    private final AdDailyStatRepository daily;
    private final AdSettingsRepository settingsRepo;
    private final AutopilotLogRepository logs;
    private final AdNetworks networks;
    private final TokenCipher cipher;
    private final StoreService stores;
    private final StoreRepository storeRepo;
    private final ProductRepository products;
    private final ShopOrderRepository orders;
    private final PublicShopService shops;
    private final StorageService storage;
    private final AiService ai;
    private final ObjectMapper mapper;
    private final AppProperties props;

    public AdsService(AdAccountRepository accounts, AdCampaignRepository campaigns, AdDailyStatRepository daily,
                      AdSettingsRepository settingsRepo, AutopilotLogRepository logs, AdNetworks networks,
                      TokenCipher cipher, StoreService stores, StoreRepository storeRepo, ProductRepository products,
                      ShopOrderRepository orders, PublicShopService shops, StorageService storage, AiService ai,
                      ObjectMapper mapper, AppProperties props) {
        this.accounts = accounts;
        this.campaigns = campaigns;
        this.daily = daily;
        this.settingsRepo = settingsRepo;
        this.logs = logs;
        this.networks = networks;
        this.cipher = cipher;
        this.stores = stores;
        this.storeRepo = storeRepo;
        this.products = products;
        this.orders = orders;
        this.shops = shops;
        this.storage = storage;
        this.ai = ai;
        this.mapper = mapper;
        this.props = props;
    }

    // ── Overview ───────────────────────────────────────────────────────────────

    public AdsOverview overview(Long ownerId) {
        Store s = stores.requireStore(ownerId);
        List<AdCampaign> ads = campaigns.findByStoreIdOrderByCreatedAtDesc(s.getId());
        Map<Long, long[]> orderCounts = new HashMap<>();
        Map<Long, BigDecimal> revenue = new HashMap<>();
        for (ShopOrder o : orders.findByStoreIdAndAdCampaignIdIsNotNullAndCreatedAtAfter(s.getId(), Instant.EPOCH)) {
            if (!o.getStatus().countsAsSale()) continue;
            orderCounts.computeIfAbsent(o.getAdCampaignId(), k -> new long[1])[0]++;
            revenue.merge(o.getAdCampaignId(), o.getTotal(), BigDecimal::add);
        }
        return new AdsOverview(
                s.getCurrency(),
                props.ads().maxDailyBudget(),
                networkViews(s),
                settingsView(settings(s)),
                ads.stream().map(c -> view(c, orderCounts.getOrDefault(c.getId(), new long[1])[0],
                        revenue.getOrDefault(c.getId(), BigDecimal.ZERO))).toList(),
                logs.findTop40ByStoreIdOrderByCreatedAtDesc(s.getId()).stream().map(AdsService::logView).toList());
    }

    List<NetworkView> networkViews(Store s) {
        List<NetworkView> out = new ArrayList<>();
        for (AdNetwork n : networks.available()) {
            Optional<AdAccount> acc = accounts.findByStoreIdAndNetwork(s.getId(), n.id());
            if (acc.isEmpty()) {
                out.add(new NetworkView(n.id(), n.label(), n.simulated(), "DISCONNECTED",
                        null, null, null, null, null, null, null));
                continue;
            }
            AdAccount a = acc.get();
            String status = a.getState().name();
            if (a.getTokenExpiresAt() != null && a.getTokenExpiresAt().isBefore(Instant.now())) status = "RECONNECT";
            out.add(new NetworkView(n.id(), n.label(), a.isSimulated(), status, a.getAdAccountName(), a.getCurrency(),
                    minBudget(a), a.getPageName(), a.getInstagramUsername(), a.getIdentityName(), a.getTokenExpiresAt()));
        }
        return out;
    }

    // ── Connecting accounts ────────────────────────────────────────────────────

    public ConnectView connect(Long ownerId, String networkId) {
        AdNetwork n = networks.require(networkId);
        Store s = stores.requireStore(ownerId);
        if (n.simulated()) {
            saveGrant(s, n, n.exchangeCode("demo", null), true);
            return new ConnectView(props.web().base() + "/app/ads?connected=" + n.id());
        }
        String state = OAuthState.create(stateSecret(), s.getId(), n.id(), Instant.now());
        return new ConnectView(n.authorizeUrl(state, redirectUri(n.id())));
    }

    /** Facebook/TikTok send the seller back here. Returns where to send the browser next. */
    public String finishConnect(String networkId, String code, String state, String error) {
        String back = props.web().base() + "/app/ads";
        Optional<OAuthState.Payload> p = OAuthState.verify(stateSecret(), state, Instant.now());
        if (p.isEmpty() || !p.get().network().equals(networkId)) return back + "?adsError=expired";
        if (error != null || code == null || code.isBlank()) return back + "?adsError=cancelled";
        Optional<AdNetwork> n = networks.find(networkId);
        Optional<Store> s = storeRepo.findById(p.get().storeId());
        if (n.isEmpty() || s.isEmpty()) return back + "?adsError=unavailable";
        try {
            saveGrant(s.get(), n.get(), n.get().exchangeCode(code, redirectUri(networkId)), false);
            return back + "?connected=" + networkId;
        } catch (AdsException e) {
            log.warn("{} sign-in failed for store {}: {}", networkId, p.get().storeId(), e.getMessage());
            return back + "?adsError=" + com.litemarket.payment.gateway.HttpJson.enc(e.getMessage());
        }
    }

    void saveGrant(Store s, AdNetwork n, TokenGrant g, boolean simulated) {
        AdAccount a = accounts.findByStoreIdAndNetwork(s.getId(), n.id()).orElseGet(AdAccount::new);
        a.setStore(s);
        a.setNetwork(n.id());
        a.setSimulated(simulated);
        a.setTokenEncrypted(cipher.encrypt(g.accessToken()));
        a.setTokenExpiresAt(g.expiresAt());
        a.setGrantedAccountIds(g.accountIds() == null || g.accountIds().isEmpty() ? null : String.join(",", g.accountIds()));
        a.setConnectedAt(Instant.now());
        if (a.getAdAccountId() != null) {
            a.setState(AdAccount.State.CONNECTED); // reconnected: keep the earlier choices
        } else {
            a.setState(AdAccount.State.NEEDS_SETUP);
            try {
                autoSelect(a, n.assets(g.accessToken(), granted(a), null, s.getCurrency()));
            } catch (AdsException e) {
                log.info("Couldn't list {} assets for {} yet: {}", n.id(), s.getSlug(), e.getMessage());
            }
        }
        accounts.save(a);
    }

    /** Picks the only ad account (and first Page / TikTok identity) so most sellers skip the setup step. */
    private void autoSelect(AdAccount a, Assets assets) {
        List<Option> active = assets.adAccounts().stream().filter(o -> "ACTIVE".equals(o.type())).toList();
        if (active.size() != 1) return;
        applyAccount(a, active.get(0));
        if ("meta".equals(a.getNetwork())) {
            if (assets.pages().isEmpty()) return;
            applyPage(a, assets.pages().get(0));
        } else if (!assets.identities().isEmpty()) {
            applyIdentity(a, assets.identities().get(0));
        }
        a.setState(AdAccount.State.CONNECTED);
    }

    public AssetsView assets(Long ownerId, String networkId, String selectedAccount) {
        Store s = stores.requireStore(ownerId);
        AdAccount a = account(s, networkId);
        AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
        Assets x = call(a, () -> n.assets(token(a), granted(a), selectedAccount, s.getCurrency()));
        return new AssetsView(options(x.adAccounts()), options(x.pages()), options(x.identities()));
    }

    public NetworkView select(Long ownerId, String networkId, SelectAccountRequest req) {
        Store s = stores.requireStore(ownerId);
        AdAccount a = account(s, networkId);
        AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
        Assets x = call(a, () -> n.assets(token(a), granted(a), req.adAccountId(), s.getCurrency()));
        Option acc = x.adAccounts().stream().filter(o -> o.id().equals(req.adAccountId())).findFirst()
                .orElseThrow(() -> ApiException.badRequest("That ad account isn't available. Pick another one."));
        applyAccount(a, acc);
        if ("meta".equals(a.getNetwork())) {
            if (req.pageId() == null || req.pageId().isBlank()) {
                throw ApiException.badRequest("Choose the Facebook Page your ads will come from.");
            }
            applyPage(a, x.pages().stream().filter(o -> o.id().equals(req.pageId())).findFirst()
                    .orElseThrow(() -> ApiException.badRequest("That Facebook Page isn't available.")));
        } else {
            a.setIdentityId(null);
            a.setIdentityName(null);
            a.setIdentityType(null);
            if (req.identityId() != null && !req.identityId().isBlank()) {
                applyIdentity(a, x.identities().stream().filter(o -> o.id().equals(req.identityId())).findFirst()
                        .orElseThrow(() -> ApiException.badRequest("That TikTok account isn't available.")));
            }
        }
        a.setState(AdAccount.State.CONNECTED);
        accounts.save(a);
        return networkViews(s).stream().filter(v -> v.network().equals(networkId)).findFirst().orElseThrow();
    }

    public void disconnect(Long ownerId, String networkId) {
        Store s = stores.requireStore(ownerId);
        accounts.findByStoreIdAndNetwork(s.getId(), networkId).ifPresent(accounts::delete);
    }

    private static void applyAccount(AdAccount a, Option o) {
        a.setAdAccountId(o.id());
        a.setAdAccountName(o.name());
        a.setCurrency(o.currency() == null ? "USD" : o.currency().toUpperCase(Locale.ROOT));
        a.setMinDailyBudget(o.minDailyBudget());
    }

    private static void applyPage(AdAccount a, Option o) {
        a.setPageId(o.id());
        a.setPageName(o.name());
        a.setInstagramUserId(o.linkedId());
        a.setInstagramUsername(o.linkedName());
    }

    private static void applyIdentity(AdAccount a, Option o) {
        a.setIdentityId(o.id());
        a.setIdentityName(o.name());
        a.setIdentityType(o.type());
    }

    private static List<OptionView> options(List<Option> list) {
        return list.stream().map(o -> new OptionView(o.id(), o.name(), o.currency(), o.minDailyBudget(),
                o.linkedId(), o.linkedName(), o.type())).toList();
    }

    // ── AI ad copy ─────────────────────────────────────────────────────────────

    /** Three ready-to-use versions of the ad text for a product (uses one AI credit). */
    public JsonNode adCopy(Long ownerId, AdCopyRequest req) {
        Store s = stores.requireStore(ownerId);
        Product p = products.findByIdAndStoreId(req.productId(), s.getId())
                .orElseThrow(() -> ApiException.notFound("Product not found."));
        ObjectNode body = storeNode(s);
        body.set("product", productNode(p));
        body.put("network", req.network());
        body.put("tone", req.tone() == null || req.tone().isBlank() ? "exciting" : req.tone());
        body.put("language", req.language() == null || req.language().isBlank() ? "English" : req.language());
        return ai.metered(new Prepared(s.getId(), s.isWhatsappOrders(), body), "/v1/ad-copy");
    }

    ObjectNode storeNode(Store s) {
        ObjectNode body = mapper.createObjectNode();
        ObjectNode n = body.putObject("store");
        n.put("name", s.getName());
        n.put("currency", s.getCurrency());
        n.put("about", s.getAbout());
        n.put("shop_url", stores.shopUrl(s));
        n.put("whatsapp_orders", s.isWhatsappOrders());
        n.put("online_payments", s.isOnlinePayments());
        return body;
    }

    ObjectNode productNode(Product p) {
        ObjectNode n = mapper.createObjectNode();
        n.put("id", p.getId());
        n.put("name", p.getName());
        n.put("price", p.getPrice());
        n.put("category", p.getCategory());
        n.put("description", p.getDescription());
        n.put("available", p.isAvailable());
        n.put("has_image", p.getImageUrl() != null);
        if (p.getStockQty() != null) n.put("stock_qty", p.getStockQty());
        n.put("featured", p.isFeatured());
        return n;
    }

    // ── Creating ads ───────────────────────────────────────────────────────────

    public AdView launch(Long ownerId, LaunchRequest req) {
        Store s = stores.requireStore(ownerId);
        AdCampaign c = prepare(s, req.network(), req.productId(), req.headline(), req.primaryText(), req.description(),
                req.callToAction(), req.dailyBudget(), req.days(), req.countries(), req.ageMin(), req.ageMax(),
                Origin.SELLER, null);
        return view(doLaunch(c));
    }

    /** Builds and saves an ad (status DRAFT) after checking the account, product and budget. */
    AdCampaign prepare(Store s, String networkId, Long productId, String headline, String primaryText,
                       String description, String cta, BigDecimal dailyBudget, Integer days, List<String> countries,
                       Integer ageMin, Integer ageMax, Origin origin, String aiReason) {
        AdAccount a = readyAccount(s, networkId);
        Product p = products.findByIdAndStoreId(productId, s.getId())
                .orElseThrow(() -> ApiException.notFound("Product not found."));
        if (!p.isAvailable()) throw ApiException.badRequest(p.getName() + " is sold out. Advertise something in stock.");
        BigDecimal budget = Money.round(dailyBudget);
        checkBudget(a, budget);
        int lo = ageMin == null ? 18 : Math.max(18, ageMin);
        int hi = ageMax == null ? 55 : Math.max(lo, ageMax);

        AdCampaign c = new AdCampaign();
        c.setStore(s);
        c.setNetwork(a.getNetwork());
        c.setProductId(p.getId());
        c.setProductName(p.getName());
        c.setProductImageUrl(p.getImageUrl());
        c.setOrigin(origin);
        c.setAiReason(aiReason);
        c.setHeadline(cut(headline, 40));
        c.setPrimaryText(cut(primaryText, 500));
        c.setDescription(cut(description, 60));
        c.setCallToAction(cta == null || cta.isBlank() ? "SHOP_NOW" : cta);
        c.setDailyBudget(budget);
        c.setCurrency(a.getCurrency());
        c.setCountries(String.join(",", cleanCountries(countries)));
        c.setAgeMin(lo);
        c.setAgeMax(hi);
        c.setEndDate(days == null ? null : LocalDate.now(ZoneOffset.UTC).plusDays(days - 1));
        c.setStatus(AdStatus.DRAFT);
        c = campaigns.save(c);
        c.setLandingUrl(landingUrl(s, c));
        return campaigns.save(c);
    }

    public AdView approve(Long ownerId, Long adId) {
        AdCampaign c = owned(ownerId, adId);
        if (c.getStatus() != AdStatus.DRAFT && c.getStatus() != AdStatus.ERROR) {
            throw ApiException.badRequest("This ad has already been launched.");
        }
        checkBudget(readyAccount(c.getStore(), c.getNetwork()), c.getDailyBudget());
        return view(doLaunch(c));
    }

    /** Creates the ad at the network. Never throws for network problems: the ad ends up ERROR with the reason. */
    AdCampaign doLaunch(AdCampaign c) {
        AdAccount a = readyAccount(c.getStore(), c.getNetwork());
        AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
        c.setStatus(AdStatus.LAUNCHING);
        c.setLastError(null);
        c = campaigns.save(c);
        try {
            List<Image> images = images(c, n);
            LaunchSpec spec = new LaunchSpec(
                    cut(c.getStore().getName() + " · " + c.getProductName() + " · "
                            + DateTimeFormatter.ISO_LOCAL_DATE.format(LocalDate.now(ZoneOffset.UTC)), 100),
                    c.getHeadline(), c.getPrimaryText(), c.getDescription(), c.getCallToAction(), c.getLandingUrl(),
                    c.getDailyBudget(), Instant.now().plus(Duration.ofMinutes(5)), c.getEndDate(),
                    Arrays.asList(c.getCountries().split(",")), c.getAgeMin(), c.getAgeMax(), images);
            Launched ids = n.launch(ref(a), spec);
            c.setExtCampaignId(ids.campaignId());
            c.setExtAdSetId(ids.adSetId());
            c.setExtCreativeId(ids.creativeId());
            c.setExtAdId(ids.adId());
            c.setStatus(AdStatus.IN_REVIEW);
            c.setLaunchedAt(Instant.now());
            log.info("Launched {} ad {} for {}", n.id(), c.getId(), c.getStore().getSlug());
        } catch (AdsException e) {
            c.setStatus(AdStatus.ERROR);
            c.setLastError(cut(e.getMessage(), 500));
            if (e.reconnect()) markReconnect(a);
        }
        return campaigns.save(c);
    }

    /** The product photo, plus (TikTok photo carousels need 2+) photos of other products from the shop. */
    List<Image> images(AdCampaign c, AdNetwork n) {
        List<Image> out = new ArrayList<>();
        readImage(c.getProductImageUrl()).ifPresent(out::add);
        if (out.isEmpty() && !n.simulated()) {
            throw new AdsException("Upload a photo for " + c.getProductName() + " first (Products > Edit).");
        }
        if ("tiktok".equals(c.getNetwork())) {
            for (Product other : shops.catalog(c.getStore())) {
                if (out.size() >= 5) break;
                if (other.getId().equals(c.getProductId()) || !other.isAvailable()) continue;
                readImage(other.getImageUrl()).ifPresent(out::add);
            }
        }
        return out;
    }

    private Optional<Image> readImage(String url) {
        if (url == null) return Optional.empty();
        return storage.read(url).map(f -> new Image(url.substring(url.lastIndexOf('/') + 1), f.mediaType(), f.bytes()));
    }

    // ── Managing ───────────────────────────────────────────────────────────────

    public AdView pause(Long ownerId, Long adId) {
        AdCampaign c = owned(ownerId, adId);
        if (c.getStatus() != AdStatus.ACTIVE && c.getStatus() != AdStatus.IN_REVIEW) {
            throw ApiException.badRequest("Only running ads can be paused.");
        }
        return view(setActive(c, false, false));
    }

    public AdView resume(Long ownerId, Long adId) {
        AdCampaign c = owned(ownerId, adId);
        if (c.getStatus() != AdStatus.PAUSED) throw ApiException.badRequest("Only paused ads can be resumed.");
        return view(setActive(c, true, false));
    }

    AdCampaign setActive(AdCampaign c, boolean active, boolean byAutopilot) {
        AdAccount a = readyAccount(c.getStore(), c.getNetwork());
        AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
        call(a, () -> {
            n.setActive(ref(a), ids(c), active);
            return null;
        });
        c.setStatus(active ? AdStatus.ACTIVE : AdStatus.PAUSED);
        c.setPausedAt(active ? null : Instant.now());
        c.setPausedByAutopilot(!active && byAutopilot);
        return campaigns.save(c);
    }

    public AdView end(Long ownerId, Long adId) {
        AdCampaign c = owned(ownerId, adId);
        if (c.getStatus() == AdStatus.DRAFT) {
            campaigns.delete(c);
            return view(c);
        }
        if (c.getStatus().live()) {
            AdAccount a = readyAccount(c.getStore(), c.getNetwork());
            AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
            call(a, () -> {
                n.end(ref(a), ids(c));
                return null;
            });
        }
        c.setStatus(AdStatus.ENDED);
        c.setEndedAt(Instant.now());
        return view(campaigns.save(c));
    }

    public AdView budget(Long ownerId, Long adId, BigDecimal dailyBudget) {
        AdCampaign c = owned(ownerId, adId);
        BigDecimal b = Money.round(dailyBudget);
        AdAccount a = readyAccount(c.getStore(), c.getNetwork());
        checkBudget(a, b);
        if (c.getStatus().live()) {
            AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
            call(a, () -> {
                n.updateBudget(ref(a), ids(c), b);
                return null;
            });
        }
        c.setDailyBudget(b);
        return view(campaigns.save(c));
    }

    // ── Settings ───────────────────────────────────────────────────────────────

    AdSettings settings(Store s) {
        return settingsRepo.findByStoreId(s.getId()).orElseGet(() -> {
            AdSettings x = new AdSettings();
            x.setStore(s);
            return x;
        });
    }

    public SettingsView saveSettings(Long ownerId, SettingsRequest req) {
        Store s = stores.requireStore(ownerId);
        AdSettings x = settings(s);
        if (req.autopilotEnabled() && x.getTermsAcceptedAt() == null && !req.acceptTerms()) {
            throw ApiException.badRequest("Please confirm that the autopilot may spend up to your daily limit.");
        }
        if (req.acceptTerms() && x.getTermsAcceptedAt() == null) x.setTermsAcceptedAt(Instant.now());
        BigDecimal max = props.ads().maxDailyBudget();
        if (max != null && req.perAdBudget().compareTo(max) > 0) {
            throw ApiException.badRequest("The most any single ad can spend per day is " + max.toPlainString() + ".");
        }
        if (req.dailyBudgetCap().signum() > 0 && req.perAdBudget().compareTo(req.dailyBudgetCap()) > 0) {
            throw ApiException.badRequest("The budget for each ad can't be more than your total daily limit.");
        }
        x.setAutopilotEnabled(req.autopilotEnabled());
        x.setAutoLaunch(req.autoLaunch());
        x.setNetworks(String.join(",", req.networks()));
        x.setDailyBudgetCap(Money.round(req.dailyBudgetCap()));
        x.setPerAdBudget(Money.round(req.perAdBudget()));
        x.setMaxActiveAds(req.maxActiveAds());
        x.setCountries(String.join(",", cleanCountries(req.countries())));
        x.setAgeMin(Math.max(18, req.ageMin()));
        x.setAgeMax(Math.max(Math.max(18, req.ageMin()), req.ageMax()));
        x.setMinCtr(req.minCtr().setScale(2, RoundingMode.HALF_UP));
        x.setMaxCpc(req.maxCpc() == null || req.maxCpc().signum() == 0 ? null : Money.round(req.maxCpc()));
        x.setFxRate(req.fxRate() == null || req.fxRate().signum() == 0 ? null : req.fxRate().setScale(4, RoundingMode.HALF_UP));
        return settingsView(settingsRepo.save(x));
    }

    static SettingsView settingsView(AdSettings x) {
        return new SettingsView(x.isAutopilotEnabled(), x.isAutoLaunch(), split(x.getNetworks()), x.getDailyBudgetCap(),
                x.getPerAdBudget(), x.getMaxActiveAds(), split(x.getCountries()), x.getAgeMin(), x.getAgeMax(),
                x.getMinCtr(), x.getMaxCpc(), x.getFxRate(), x.getTermsAcceptedAt() != null, x.getLastRunAt(),
                x.getLastRunSummary());
    }

    // ── Tracking customers who came from an ad ────────────────────────────────

    /** Counts a shop visit or a WhatsApp tap from someone who arrived with ?ref=ad42. */
    public void track(String slug, TrackRequest req) {
        Long id = OrderService.adIdFromRef(req.ref());
        if (id == null) return;
        Store s = shops.requireOpenStore(slug);
        Optional<AdCampaign> found = campaigns.findByIdAndStoreId(id, s.getId());
        if (found.isEmpty()) return;
        AdCampaign c = found.get();
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        AdDailyStat d = daily.findByAdCampaignIdAndStatDate(c.getId(), today)
                .orElseGet(() -> new AdDailyStat(c.getId(), s.getId(), today));
        if ("whatsapp".equals(req.event())) {
            d.setWhatsappClicks(d.getWhatsappClicks() + 1);
            c.setWhatsappClicks(c.getWhatsappClicks() + 1);
        } else {
            d.setVisits(d.getVisits() + 1);
            c.setVisits(c.getVisits() + 1);
        }
        daily.save(d);
        campaigns.save(c);
    }

    // ── Views ──────────────────────────────────────────────────────────────────

    AdView view(AdCampaign c) {
        long count = 0;
        BigDecimal rev = BigDecimal.ZERO;
        if (c.getId() != null) {
            for (ShopOrder o : orders.findByStoreIdAndAdCampaignIdIsNotNullAndCreatedAtAfter(c.getStore().getId(),
                    c.getCreatedAt().minus(Duration.ofDays(1)))) {
                if (c.getId().equals(o.getAdCampaignId()) && o.getStatus().countsAsSale()) {
                    count++;
                    rev = rev.add(o.getTotal());
                }
            }
        }
        return view(c, count, rev);
    }

    static AdView view(AdCampaign c, long orderCount, BigDecimal revenue) {
        Double ctr = c.getImpressions() > 0 ? round2(c.getClicks() * 100.0 / c.getImpressions()) : null;
        BigDecimal cpc = c.getClicks() > 0
                ? c.getSpend().divide(BigDecimal.valueOf(c.getClicks()), 2, RoundingMode.HALF_UP) : null;
        return new AdView(c.getId(), c.getNetwork(), c.getProductId(), c.getProductName(), c.getProductImageUrl(),
                c.getStatus().name(), c.getOrigin().name(), c.getHeadline(), c.getPrimaryText(), c.getDescription(),
                c.getCallToAction(), c.getDailyBudget(), c.getCurrency(), split(c.getCountries()), c.getAgeMin(),
                c.getAgeMax(), c.getEndDate(), c.getReviewNote(), c.getLastError(), c.getAiReason(), c.getImpressions(),
                c.getClicks(), Money.round(c.getSpend()), c.getVisits(), c.getWhatsappClicks(), orderCount,
                Money.round(revenue), ctr, cpc, c.getCreatedAt(), c.getLaunchedAt(), c.getLastSyncedAt());
    }

    static LogView logView(AutopilotLog l) {
        return new LogView(l.getId(), l.getAction(), l.getMessage(), l.getAdCampaignId(), l.getCreatedAt());
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    public Long storeId(Long ownerId) {
        return stores.requireStore(ownerId).getId();
    }

    AdCampaign owned(Long ownerId, Long adId) {
        Store s = stores.requireStore(ownerId);
        return campaigns.findByIdAndStoreId(adId, s.getId()).orElseThrow(() -> ApiException.notFound("Ad not found."));
    }

    AdAccount account(Store s, String networkId) {
        return accounts.findByStoreIdAndNetwork(s.getId(), networkId).orElseThrow(() -> ApiException.badRequest(
                "Connect " + AdNetworks.label(networkId) + " first."));
    }

    /** A connected, fully set-up account with a working token. */
    AdAccount readyAccount(Store s, String networkId) {
        AdAccount a = account(s, networkId);
        boolean expired = a.getTokenExpiresAt() != null && a.getTokenExpiresAt().isBefore(Instant.now());
        if (a.getState() == AdAccount.State.RECONNECT || expired) {
            throw ApiException.badRequest("Your " + AdNetworks.label(networkId) + " connection expired. Reconnect it first.");
        }
        if (a.getState() != AdAccount.State.CONNECTED || a.getAdAccountId() == null) {
            throw ApiException.badRequest("Finish setting up " + AdNetworks.label(networkId) + ": choose your ad account.");
        }
        return a;
    }

    BigDecimal minBudget(AdAccount a) {
        if (a.getMinDailyBudget() != null) return a.getMinDailyBudget();
        AdNetwork n = networks.forAccount(a.getNetwork(), a.isSimulated());
        BigDecimal m = n.minDailyBudget(null);
        return m == null ? BigDecimal.ONE : m;
    }

    void checkBudget(AdAccount a, BigDecimal budget) {
        BigDecimal min = minBudget(a);
        if (budget.compareTo(min) < 0) {
            throw ApiException.badRequest(AdNetworks.label(a.getNetwork()) + " needs at least "
                    + min.toPlainString() + " " + a.getCurrency() + " a day.");
        }
        BigDecimal max = props.ads().maxDailyBudget();
        if (max != null && budget.compareTo(max) > 0) {
            throw ApiException.badRequest("The most an ad can spend per day here is " + max.toPlainString() + " "
                    + a.getCurrency() + ".");
        }
    }

    AccountRef ref(AdAccount a) {
        String token = token(a);
        if (token == null) {
            markReconnect(a);
            throw ApiException.badRequest("Please reconnect " + AdNetworks.label(a.getNetwork()) + ".");
        }
        return new AccountRef(token, a.getAdAccountId(), a.getCurrency(), a.getPageId(), a.getInstagramUserId(),
                a.getIdentityId(), a.getIdentityType());
    }

    static Launched ids(AdCampaign c) {
        return new Launched(c.getExtCampaignId(), c.getExtAdSetId(), c.getExtCreativeId(), c.getExtAdId());
    }

    String token(AdAccount a) {
        return cipher.decrypt(a.getTokenEncrypted());
    }

    static List<String> granted(AdAccount a) {
        return split(a.getGrantedAccountIds());
    }

    void markReconnect(AdAccount a) {
        a.setState(AdAccount.State.RECONNECT);
        accounts.save(a);
    }

    /** Runs a network call and turns its errors into messages for the seller. */
    <T> T call(AdAccount a, java.util.function.Supplier<T> action) {
        try {
            return action.get();
        } catch (AdsException e) {
            if (e.reconnect()) markReconnect(a);
            throw ApiException.badGateway(e.getMessage());
        }
    }

    String landingUrl(Store s, AdCampaign c) {
        String source = "tiktok".equals(c.getNetwork()) ? "tiktok" : "facebook";
        return stores.shopUrl(s) + "?p=" + c.getProductId() + "&ref=" + c.ref()
                + "&utm_source=" + source + "&utm_medium=paid_social&utm_campaign=lm-" + c.ref();
    }

    String redirectUri(String networkId) {
        return props.web().base() + "/api/ads/oauth/" + networkId + "/callback";
    }

    private String stateSecret() {
        return props.security().jwtSecret();
    }

    static List<String> cleanCountries(List<String> countries) {
        if (countries == null || countries.isEmpty()) return List.of("GH");
        List<String> out = countries.stream().map(c -> c.trim().toUpperCase(Locale.ROOT)).filter(c -> !c.isEmpty())
                .distinct().toList();
        return out.isEmpty() ? List.of("GH") : out;
    }

    static List<String> split(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        return Arrays.stream(csv.split(",")).map(String::trim).filter(x -> !x.isEmpty()).toList();
    }

    static String cut(String s, int max) {
        if (s == null) return null;
        String t = s.trim();
        return t.length() <= max ? t : t.substring(0, max).trim();
    }

    static Double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
