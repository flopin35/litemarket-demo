package com.litemarket.ads;

import com.litemarket.ads.AdCampaign.Origin;
import com.litemarket.ads.AutopilotLog.Action;
import com.litemarket.config.AppProperties;
import com.litemarket.order.OrderItem;
import com.litemarket.order.ShopOrder;
import com.litemarket.order.ShopOrderRepository;
import com.litemarket.product.Product;
import com.litemarket.product.ProductRepository;
import com.litemarket.store.Store;
import com.litemarket.store.StoreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * With the demo seed and ads demo mode on, gives Ama's Kitchen a connected (demo) Facebook & Instagram account,
 * a few ads with two weeks of results, autopilot settings and activity, so the Ads page has something to show.
 */
@Component
@Order(2)
public class AdsDemoSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(AdsDemoSeeder.class);

    private final AppProperties props;
    private final StoreRepository stores;
    private final ProductRepository products;
    private final ShopOrderRepository orders;
    private final AdAccountRepository accounts;
    private final AdCampaignRepository campaigns;
    private final AdSettingsRepository settings;
    private final AutopilotLogRepository logs;
    private final TokenCipher cipher;
    private final AdsService ads;
    private final AdsSync sync;

    public AdsDemoSeeder(AppProperties props, StoreRepository stores, ProductRepository products,
                         ShopOrderRepository orders, AdAccountRepository accounts, AdCampaignRepository campaigns,
                         AdSettingsRepository settings, AutopilotLogRepository logs, TokenCipher cipher,
                         AdsService ads, AdsSync sync) {
        this.props = props;
        this.stores = stores;
        this.products = products;
        this.orders = orders;
        this.accounts = accounts;
        this.campaigns = campaigns;
        this.settings = settings;
        this.logs = logs;
        this.cipher = cipher;
        this.ads = ads;
        this.sync = sync;
    }

    @Override
    public void run(String... args) {
        if (!props.demo().seed() || !props.ads().demoMode() || accounts.count() > 0) return;
        Optional<Store> found = stores.findBySlug("amas-kitchen");
        if (found.isEmpty()) return;
        Store s = found.get();
        List<Product> menu = products.findByStoreIdOrderByCreatedAtDesc(s.getId());
        if (menu.size() < 5) return;
        Instant now = Instant.now();

        AdAccount a = new AdAccount();
        a.setStore(s);
        a.setNetwork("meta");
        a.setSimulated(true);
        a.setState(AdAccount.State.CONNECTED);
        a.setTokenEncrypted(cipher.encrypt("sim-demo-token"));
        a.setTokenExpiresAt(now.plus(Duration.ofDays(52)));
        a.setGrantedAccountIds("sim-1001");
        a.setAdAccountId("sim-1001");
        a.setAdAccountName("Ama's Kitchen ads (demo)");
        a.setCurrency(s.getCurrency());
        a.setMinDailyBudget(BigDecimal.ONE);
        a.setPageId("sim-page-1");
        a.setPageName("Ama's Kitchen");
        a.setInstagramUserId("sim-ig-1");
        a.setInstagramUsername("amaskitchen.gh");
        a.setConnectedAt(now.minus(Duration.ofDays(16)));
        accounts.save(a);

        AdSettings x = new AdSettings();
        x.setStore(s);
        x.setAutopilotEnabled(true);
        x.setAutoLaunch(false); // new ads wait for approval, so the demo shows a suggestion to approve
        x.setNetworks("meta");
        x.setDailyBudgetCap(new BigDecimal("120.00"));
        x.setPerAdBudget(new BigDecimal("40.00"));
        x.setMaxActiveAds(3);
        x.setCountries("GH");
        x.setAgeMin(18);
        x.setAgeMax(45);
        x.setTermsAcceptedAt(now.minus(Duration.ofDays(16)));
        x.setLastRunAt(now.minus(Duration.ofHours(2)));
        x.setLastRunSummary("1 suggested.");
        settings.save(x);

        Product jollof = byName(menu, "Jollof");
        Product waakye = byName(menu, "Waakye");
        Product kelewele = byName(menu, "Kelewele");
        Product sobolo = byName(menu, "Sobolo");

        AdCampaign j = ad(s, jollof, Origin.AUTOPILOT, AdStatus.ACTIVE, "Smoky party jollof, delivered hot",
                "Craving real party jollof? 🔥 Smoky rice, grilled chicken, fried plantain and fresh salad, delivered hot around Accra. Order in 2 taps on WhatsApp or pay with MoMo.",
                "GHS 45 · Delivered hot", "48.00", now.minus(Duration.ofDays(12)), null,
                "Your best seller this month with 2 orders a day on average, and it has a photo customers love.");
        AdCampaign w = ad(s, waakye, Origin.SELLER, AdStatus.ACTIVE, "Waakye Special for lunch",
                "Waakye with gari, spaghetti, egg, wele, fish and our house shito. Order before 12 and lunch arrives hot. 🍛",
                "Order on WhatsApp", "30.00", now.minus(Duration.ofDays(8)), null, null);
        AdCampaign k = ad(s, kelewele, Origin.AUTOPILOT, AdStatus.PAUSED, "Spicy kelewele, the perfect snack",
                "Ripe plantain cubes fried with ginger and pepper. Add peanuts for the full experience!",
                "GHS 15 snack", "25.00", now.minus(Duration.ofDays(15)), now.minus(Duration.ofDays(4)),
                "Snacks sell well in the evening and this one is cheap to try.");
        k.setPausedByAutopilot(true);
        campaigns.save(k);
        AdCampaign d = ad(s, sobolo, Origin.AUTOPILOT, AdStatus.DRAFT, "Ice-cold sobolo for the heat",
                "Chilled hibiscus sobolo with ginger and pineapple. Add a bottle to any meal for GHS 12! 🧊",
                "Add one to your order", "25.00", null, null,
                "Drinks are the easiest add-on: customers who order food often add one.");

        sync.syncStore(s.getId());

        // Customers who came through the ads ordered (link a few existing demo orders to them).
        tagOrders(s, j, jollof, 5);
        tagOrders(s, w, waakye, 3);

        logs.save(at(new AutopilotLog(s.getId(), j.getId(), Action.LAUNCHED, "Launched \"" + j.getHeadline()
                + "\" for " + j.getProductName() + " at 40.00 " + s.getCurrency() + "/day. " + j.getAiReason()), now.minus(Duration.ofDays(12))));
        logs.save(at(new AutopilotLog(s.getId(), k.getId(), Action.PAUSED, "Paused \"" + k.getHeadline()
                + "\": few people who saw it clicked, so the budget went to better ads."), now.minus(Duration.ofDays(4))));
        logs.save(at(new AutopilotLog(s.getId(), j.getId(), Action.BUDGET_UP, "\"" + j.getHeadline()
                + "\" is a winner. It brought 5 orders. Daily budget raised to 48.00 " + s.getCurrency() + "."), now.minus(Duration.ofDays(2))));
        logs.save(at(new AutopilotLog(s.getId(), d.getId(), Action.SUGGESTED, "Suggested an ad for "
                + d.getProductName() + ". Approve it below to launch. " + d.getAiReason()), now.minus(Duration.ofHours(2))));
        log.info("Demo ads created for {}", s.getSlug());
    }

    private AdCampaign ad(Store s, Product p, Origin origin, AdStatus status, String headline, String text,
                          String description, String budget, Instant launched, Instant paused, String reason) {
        AdCampaign c = new AdCampaign();
        c.setStore(s);
        c.setNetwork("meta");
        c.setProductId(p.getId());
        c.setProductName(p.getName());
        c.setProductImageUrl(p.getImageUrl());
        c.setOrigin(origin);
        c.setStatus(status);
        c.setHeadline(headline);
        c.setPrimaryText(text);
        c.setDescription(description);
        c.setCallToAction("ORDER_NOW");
        c.setDailyBudget(new BigDecimal(budget));
        c.setCurrency(s.getCurrency());
        c.setCountries("GH");
        c.setAgeMin(18);
        c.setAgeMax(45);
        c.setAiReason(reason);
        c.setCreatedAt(launched == null ? Instant.now().minus(Duration.ofHours(2)) : launched.minus(Duration.ofMinutes(5)));
        c.setLaunchedAt(launched);
        c.setPausedAt(paused);
        c = campaigns.save(c);
        c.setLandingUrl(ads.landingUrl(s, c));
        if (launched != null) {
            String key = "seed-" + c.getId();
            c.setExtCampaignId("sim-c-" + key);
            c.setExtAdSetId("sim-s-" + key);
            c.setExtCreativeId("sim-cr-" + key);
            c.setExtAdId("sim-ad-" + key);
        }
        return campaigns.save(c);
    }

    private void tagOrders(Store s, AdCampaign c, Product p, int count) {
        Set<Long> used = new HashSet<>();
        int tagged = 0;
        for (ShopOrder o : orders.findByStoreIdOrderByCreatedAtDesc(s.getId())) {
            if (tagged >= count) break;
            if (o.getAdCampaignId() != null || !o.getStatus().countsAsSale() || used.contains(o.getId())) continue;
            if (c.getLaunchedAt() != null && o.getCreatedAt().isBefore(c.getLaunchedAt())) continue;
            boolean hasProduct = o.getItems().stream().map(OrderItem::getProductId).anyMatch(p.getId()::equals);
            if (!hasProduct && tagged >= count / 2) continue;
            o.setAdCampaignId(c.getId());
            orders.save(o);
            used.add(o.getId());
            tagged++;
        }
    }

    private static AutopilotLog at(AutopilotLog l, Instant when) {
        l.setCreatedAt(when);
        return l;
    }

    private static Product byName(List<Product> menu, String part) {
        return menu.stream().filter(p -> p.getName().contains(part)).findFirst().orElse(menu.get(0));
    }
}
