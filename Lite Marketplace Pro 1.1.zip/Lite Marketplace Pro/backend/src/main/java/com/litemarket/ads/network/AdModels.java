package com.litemarket.ads.network;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

/** Plain data passed between AdsService and the ad networks. */
public final class AdModels {

    private AdModels() {}

    /** The token a seller's sign-in produced, and (TikTok) the ad accounts they allowed. */
    public record TokenGrant(String accessToken, Instant expiresAt, List<String> accountIds) {}

    /** Something the seller can pick: an ad account, a Facebook Page, an Instagram account or a TikTok identity. */
    public record Option(String id, String name, String currency, BigDecimal minDailyBudget,
                         String linkedId, String linkedName, String type) {}

    public record Assets(List<Option> adAccounts, List<Option> pages, List<Option> identities) {}

    /** The account the ad runs from (decrypted token plus the seller's choices). */
    public record AccountRef(String accessToken, String adAccountId, String currency, String pageId,
                             String instagramUserId, String identityId, String identityType) {}

    /** A photo for the ad. */
    public record Image(String fileName, String mediaType, byte[] bytes) {}

    /** Everything needed to create one ad. Budget is in the ad account's currency, per day. */
    public record LaunchSpec(
            String name,
            String headline,
            String primaryText,
            String description,
            String callToAction,
            String landingUrl,
            BigDecimal dailyBudget,
            Instant start,
            LocalDate endDate,
            List<String> countries,
            int ageMin,
            int ageMax,
            List<Image> images) {}

    /** Ids the network gave the new ad's pieces. */
    public record Launched(String campaignId, String adSetId, String creativeId, String adId) {}

    /** Where the ad stands at the network. status is one of IN_REVIEW, ACTIVE, PAUSED, REJECTED, ERROR, ENDED. */
    public record Review(String status, String note) {}

    public record DayRow(LocalDate day, long impressions, long reach, long clicks, BigDecimal spend) {}
}
