package com.litemarket.config;

import com.litemarket.payment.gateway.GatewayModels.ProviderOption;
import com.litemarket.payment.gateway.GatewayRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/** Public settings the website needs before anyone logs in (brand, commission, payment and ad options). */
@RestController
public class ConfigController {

    public record PublicConfig(
            String brandName,
            String supportEmail,
            String currency,
            BigDecimal commissionPercent,
            boolean commissionOnWhatsappOrders,
            int aiMonthlyCredits,
            Integer productLimit,
            List<ProviderOption> providers,
            boolean demoPayments,
            AdsConfig ads) {}

    /** Which ad networks sellers can connect. */
    public record AdsConfig(boolean meta, boolean tiktok, boolean demo) {}

    private final AppProperties props;
    private final GatewayRegistry gateways;

    public ConfigController(AppProperties props, GatewayRegistry gateways) {
        this.props = props;
        this.gateways = gateways;
    }

    @GetMapping("/api/config")
    public PublicConfig config() {
        AppProperties.Commission c = props.commission();
        AppProperties.Ads ads = props.ads();
        return new PublicConfig(
                props.brand().name(),
                props.brand().supportEmail(),
                props.brand().defaultCurrency(),
                c.percent(),
                c.onWhatsappOrders(),
                c.aiMonthlyCredits(),
                c.productLimit() > 0 ? c.productLimit() : null,
                gateways.options(),
                props.payments().demoMode(),
                new AdsConfig(ads.meta().enabled(), ads.tiktok().enabled(), ads.demoMode()));
    }

    @GetMapping("/api/health")
    public Map<String, String> health() {
        return Map.of("status", "ok");
    }
}
