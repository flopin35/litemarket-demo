package com.litemarket.ads;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.Optional;

/**
 * The "state" sent through Facebook/TikTok sign-in: which shop and network it is for, signed so it can't be
 * forged and valid for 15 minutes. No database needed.
 */
public final class OAuthState {

    public record Payload(Long storeId, String network) {}

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Base64.Encoder B64 = Base64.getUrlEncoder().withoutPadding();

    private OAuthState() {}

    public static String create(String secret, Long storeId, String network, Instant now) {
        byte[] nonce = new byte[9];
        RANDOM.nextBytes(nonce);
        String body = storeId + "." + network + "." + (now.getEpochSecond() + 900) + "." + B64.encodeToString(nonce);
        String payload = B64.encodeToString(body.getBytes(StandardCharsets.UTF_8));
        return payload + "." + sign(secret, payload);
    }

    public static Optional<Payload> verify(String secret, String state, Instant now) {
        if (state == null) return Optional.empty();
        int dot = state.lastIndexOf('.');
        if (dot <= 0) return Optional.empty();
        String payload = state.substring(0, dot);
        String sig = state.substring(dot + 1);
        if (!MessageDigest.isEqual(sign(secret, payload).getBytes(StandardCharsets.UTF_8),
                sig.getBytes(StandardCharsets.UTF_8))) {
            return Optional.empty();
        }
        try {
            String[] parts = new String(Base64.getUrlDecoder().decode(payload), StandardCharsets.UTF_8).split("\\.");
            if (parts.length != 4 || Long.parseLong(parts[2]) < now.getEpochSecond()) return Optional.empty();
            return Optional.of(new Payload(Long.parseLong(parts[0]), parts[1]));
        } catch (RuntimeException e) {
            return Optional.empty();
        }
    }

    private static String sign(String secret, String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(("oauth-state:" + secret).getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return B64.encodeToString(mac.doFinal(payload.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
