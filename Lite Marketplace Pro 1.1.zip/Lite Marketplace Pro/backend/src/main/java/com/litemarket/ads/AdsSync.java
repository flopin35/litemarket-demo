package com.litemarket.ads;

import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdNetwork;
import com.litemarket.ads.network.AdNetworks;
import com.litemarket.ads.network.AdsException;
import com.litemarket.ads.network.SimulatedAdsNetwork;
import com.litemarket.ads.network.SimulatedAdsNetwork.SimDay;
import com.litemarket.common.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

/** Pulls review status and daily results for live ads from Meta/TikTok every couple of hours (ADS_SYNC_CRON). */
@Component
public class AdsSync {

    private static final Logger log = LoggerFactory.getLogger(AdsSync.class);

    private final AdCampaignRepository campaigns;
    private final AdAccountRepository accounts;
    private final AdDailyStatRepository daily;
    private final AdNetworks networks;
    private final AdsService ads;

    public AdsSync(AdCampaignRepository campaigns, AdAccountRepository accounts, AdDailyStatRepository daily,
                   AdNetworks networks, AdsService ads) {
        this.campaigns = campaigns;
        this.accounts = accounts;
        this.daily = daily;
        this.networks = networks;
        this.ads = ads;
    }

    @Scheduled(cron = "${app.ads.sync-cron:0 20 */2 * * *}")
    public void syncAll() {
        Set<Long> storeIds = new TreeSet<>();
        for (AdCampaign c : campaigns.findByStatusIn(AdsService.LIVE)) storeIds.add(c.getStore().getId());
        for (Long id : storeIds) {
            try {
                syncStore(id);
            } catch (RuntimeException e) {
                log.warn("Ad sync failed for store {}: {}", id, e.getMessage());
            }
        }
    }

    /** Refreshes every live ad of one shop. Returns how many ads were updated. */
    public int syncStore(Long storeId) {
        List<AdCampaign> live = campaigns.findByStoreIdAndStatusIn(storeId, AdsService.LIVE);
        Map<String, List<AdCampaign>> byNetwork = new LinkedHashMap<>();
        for (AdCampaign c : live) byNetwork.computeIfAbsent(c.getNetwork(), k -> new ArrayList<>()).add(c);
        int updated = 0;
        for (Map.Entry<String, List<AdCampaign>> e : byNetwork.entrySet()) {
            Optional<AdAccount> acc = accounts.findByStoreIdAndNetwork(storeId, e.getKey());
            if (acc.isEmpty() || acc.get().getState() != AdAccount.State.CONNECTED) continue;
            AdAccount a = acc.get();
            AdNetwork n;
            AccountRef ref;
            try {
                n = networks.forAccount(a.getNetwork(), a.isSimulated());
                ref = ads.ref(a);
            } catch (ApiException ex) {
                continue;
            }
            try {
                updated += n instanceof SimulatedAdsNetwork sim ? syncSimulated(sim, ref, e.getValue())
                        : syncReal(n, ref, e.getValue());
            } catch (AdsException ex) {
                if (ex.reconnect()) ads.markReconnect(a);
                log.info("Ad sync for store {} on {} stopped: {}", storeId, e.getKey(), ex.getMessage());
            }
        }
        return updated;
    }

    private int syncReal(AdNetwork n, AccountRef ref, List<AdCampaign> ads) {
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        LocalDate from = today;
        List<Launched> ids = new ArrayList<>();
        for (AdCampaign c : ads) {
            applyReview(c, n.review(ref, AdsService.ids(c)), false);
            ids.add(AdsService.ids(c));
            LocalDate launched = c.getLaunchedAt() == null ? today : LocalDate.ofInstant(c.getLaunchedAt(), ZoneOffset.UTC);
            if (launched.isBefore(from)) from = launched;
        }
        if (from.isBefore(today.minusDays(29))) from = today.minusDays(29);
        Map<String, List<DayRow>> rows = n.results(ref, ids, from, today);
        for (AdCampaign c : ads) {
            for (DayRow r : rows.getOrDefault(c.getExtAdId(), List.of())) {
                AdDailyStat d = row(c, r.day());
                d.setImpressions(r.impressions());
                d.setReach(r.reach());
                d.setClicks(r.clicks());
                d.setSpend(r.spend());
                daily.save(d);
            }
            recomputeTotals(c);
        }
        return ads.size();
    }

    private int syncSimulated(SimulatedAdsNetwork sim, AccountRef ref, List<AdCampaign> ads) {
        Instant now = Instant.now();
        for (AdCampaign c : ads) {
            applyReview(c, sim.review(ref, AdsService.ids(c)), true);
            if (c.getLaunchedAt() != null && c.getStatus() != AdStatus.IN_REVIEW) {
                Instant from = c.getLaunchedAt().plus(Duration.ofMinutes(1));
                Instant until = c.getStatus() == AdStatus.PAUSED && c.getPausedAt() != null ? c.getPausedAt()
                        : c.getEndedAt() != null ? c.getEndedAt() : now;
                for (SimDay sd : sim.simulate(c.getExtAdId(), c.getDailyBudget(), c.getCurrency(), from, until, now)) {
                    AdDailyStat d = row(c, sd.day());
                    d.setImpressions(sd.impressions());
                    d.setReach(sd.reach());
                    d.setClicks(sd.clicks());
                    d.setSpend(sd.spend());
                    d.setVisits(Math.max(d.getVisits(), sd.visits()));
                    d.setWhatsappClicks(Math.max(d.getWhatsappClicks(), sd.whatsappClicks()));
                    daily.save(d);
                }
            }
            recomputeTotals(c);
        }
        return ads.size();
    }

    /**
     * Applies the network's view of the ad. Real networks are the source of truth (a seller may pause an ad
     * in Ads Manager); the demo network only moves ads out of review.
     */
    void applyReview(AdCampaign c, Review r, boolean simulated) {
        AdStatus next = switch (r.status()) {
            case "ACTIVE" -> AdStatus.ACTIVE;
            case "PAUSED" -> AdStatus.PAUSED;
            case "REJECTED" -> AdStatus.REJECTED;
            case "ENDED" -> AdStatus.ENDED;
            case "ERROR" -> AdStatus.ERROR;
            default -> AdStatus.IN_REVIEW;
        };
        if (simulated && c.getStatus() != AdStatus.IN_REVIEW) return;
        if (c.getStatus() == AdStatus.PAUSED && next == AdStatus.IN_REVIEW) return; // paused while in review
        if (next != c.getStatus()) {
            c.setStatus(next);
            if (next == AdStatus.ENDED && c.getEndedAt() == null) c.setEndedAt(Instant.now());
        }
        if (next == AdStatus.REJECTED) c.setReviewNote(AdsService.cut(r.note(), 500));
        if (next == AdStatus.ERROR) c.setLastError(AdsService.cut(r.note(), 500));
    }

    private AdDailyStat row(AdCampaign c, LocalDate day) {
        return daily.findByAdCampaignIdAndStatDate(c.getId(), day)
                .orElseGet(() -> new AdDailyStat(c.getId(), c.getStore().getId(), day));
    }

    private void recomputeTotals(AdCampaign c) {
        long impressions = 0, reach = 0, clicks = 0, visits = 0, whatsapp = 0;
        BigDecimal spend = BigDecimal.ZERO;
        for (AdDailyStat d : daily.findByAdCampaignId(c.getId())) {
            impressions += d.getImpressions();
            reach += d.getReach();
            clicks += d.getClicks();
            visits += d.getVisits();
            whatsapp += d.getWhatsappClicks();
            spend = spend.add(d.getSpend());
        }
        c.setImpressions(impressions);
        c.setReach(reach);
        c.setClicks(clicks);
        c.setVisits(visits);
        c.setWhatsappClicks(whatsapp);
        c.setSpend(spend);
        c.setLastSyncedAt(Instant.now());
        campaigns.save(c);
    }
}
