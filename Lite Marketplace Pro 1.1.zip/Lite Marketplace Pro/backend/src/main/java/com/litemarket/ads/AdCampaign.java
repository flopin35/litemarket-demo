package com.litemarket.ads;

import com.litemarket.store.Store;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/**
 * One ad promoting one product on one network. At Meta it is a campaign + ad set + creative + ad;
 * at TikTok a campaign + ad group + ad. Running totals are refreshed by AdsSync.
 */
@Entity
@Table(name = "ad_campaigns")
public class AdCampaign {

    public enum Origin { SELLER, AUTOPILOT }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "store_id")
    private Store store;

    @Column(nullable = false, length = 20)
    private String network;

    private Long productId;

    @Column(length = 120)
    private String productName;

    @Column(length = 500)
    private String productImageUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AdStatus status = AdStatus.DRAFT;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Origin origin = Origin.SELLER;

    @Column(length = 60)
    private String headline;

    @Column(length = 600)
    private String primaryText;

    @Column(length = 80)
    private String description;

    @Column(length = 30)
    private String callToAction = "SHOP_NOW";

    @Column(length = 600)
    private String landingUrl;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal dailyBudget = BigDecimal.ZERO;

    @Column(length = 3)
    private String currency;

    /** Comma-separated ISO country codes, e.g. "GH" or "GH,NG". */
    @Column(length = 100)
    private String countries = "GH";

    private Integer ageMin = 18;

    private Integer ageMax = 55;

    private LocalDate endDate;

    @Column(length = 64)
    private String extCampaignId;

    @Column(length = 64)
    private String extAdSetId;

    @Column(length = 64)
    private String extCreativeId;

    @Column(length = 64)
    private String extAdId;

    @Column(length = 500)
    private String reviewNote;

    @Column(length = 500)
    private String lastError;

    /** Why the autopilot chose this product (shown to the seller). */
    @Column(length = 500)
    private String aiReason;

    /** Paused by the autopilot because it wasn't working (so it isn't suggested again for a while). */
    private boolean pausedByAutopilot;

    private long impressions;

    private long reach;

    private long clicks;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal spend = BigDecimal.ZERO;

    private long visits;

    private long whatsappClicks;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    private Instant launchedAt;

    private Instant pausedAt;

    private Instant endedAt;

    private Instant lastSyncedAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Store getStore() { return store; }
    public void setStore(Store store) { this.store = store; }
    public String getNetwork() { return network; }
    public void setNetwork(String network) { this.network = network; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public String getProductImageUrl() { return productImageUrl; }
    public void setProductImageUrl(String productImageUrl) { this.productImageUrl = productImageUrl; }
    public AdStatus getStatus() { return status; }
    public void setStatus(AdStatus status) { this.status = status; }
    public Origin getOrigin() { return origin; }
    public void setOrigin(Origin origin) { this.origin = origin; }
    public String getHeadline() { return headline; }
    public void setHeadline(String headline) { this.headline = headline; }
    public String getPrimaryText() { return primaryText; }
    public void setPrimaryText(String primaryText) { this.primaryText = primaryText; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCallToAction() { return callToAction; }
    public void setCallToAction(String callToAction) { this.callToAction = callToAction; }
    public String getLandingUrl() { return landingUrl; }
    public void setLandingUrl(String landingUrl) { this.landingUrl = landingUrl; }
    public BigDecimal getDailyBudget() { return dailyBudget; }
    public void setDailyBudget(BigDecimal dailyBudget) { this.dailyBudget = dailyBudget; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getCountries() { return countries; }
    public void setCountries(String countries) { this.countries = countries; }
    public Integer getAgeMin() { return ageMin; }
    public void setAgeMin(Integer ageMin) { this.ageMin = ageMin; }
    public Integer getAgeMax() { return ageMax; }
    public void setAgeMax(Integer ageMax) { this.ageMax = ageMax; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public String getExtCampaignId() { return extCampaignId; }
    public void setExtCampaignId(String extCampaignId) { this.extCampaignId = extCampaignId; }
    public String getExtAdSetId() { return extAdSetId; }
    public void setExtAdSetId(String extAdSetId) { this.extAdSetId = extAdSetId; }
    public String getExtCreativeId() { return extCreativeId; }
    public void setExtCreativeId(String extCreativeId) { this.extCreativeId = extCreativeId; }
    public String getExtAdId() { return extAdId; }
    public void setExtAdId(String extAdId) { this.extAdId = extAdId; }
    public String getReviewNote() { return reviewNote; }
    public void setReviewNote(String reviewNote) { this.reviewNote = reviewNote; }
    public String getLastError() { return lastError; }
    public void setLastError(String lastError) { this.lastError = lastError; }
    public String getAiReason() { return aiReason; }
    public void setAiReason(String aiReason) { this.aiReason = aiReason; }
    public boolean isPausedByAutopilot() { return pausedByAutopilot; }
    public void setPausedByAutopilot(boolean pausedByAutopilot) { this.pausedByAutopilot = pausedByAutopilot; }
    public long getImpressions() { return impressions; }
    public void setImpressions(long impressions) { this.impressions = impressions; }
    public long getReach() { return reach; }
    public void setReach(long reach) { this.reach = reach; }
    public long getClicks() { return clicks; }
    public void setClicks(long clicks) { this.clicks = clicks; }
    public BigDecimal getSpend() { return spend; }
    public void setSpend(BigDecimal spend) { this.spend = spend; }
    public long getVisits() { return visits; }
    public void setVisits(long visits) { this.visits = visits; }
    public long getWhatsappClicks() { return whatsappClicks; }
    public void setWhatsappClicks(long whatsappClicks) { this.whatsappClicks = whatsappClicks; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getLaunchedAt() { return launchedAt; }
    public void setLaunchedAt(Instant launchedAt) { this.launchedAt = launchedAt; }
    public Instant getPausedAt() { return pausedAt; }
    public void setPausedAt(Instant pausedAt) { this.pausedAt = pausedAt; }
    public Instant getEndedAt() { return endedAt; }
    public void setEndedAt(Instant endedAt) { this.endedAt = endedAt; }
    public Instant getLastSyncedAt() { return lastSyncedAt; }
    public void setLastSyncedAt(Instant lastSyncedAt) { this.lastSyncedAt = lastSyncedAt; }

    public String ref() {
        return "ad" + id;
    }
}
