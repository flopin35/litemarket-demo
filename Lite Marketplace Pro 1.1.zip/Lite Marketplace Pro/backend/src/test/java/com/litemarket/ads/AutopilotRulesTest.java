package com.litemarket.ads;

import com.litemarket.ads.AutopilotRules.Decision;
import com.litemarket.ads.AutopilotRules.Performance;
import com.litemarket.ads.AutopilotRules.Verdict;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AutopilotRulesTest {

    private static final BigDecimal MIN_CTR = new BigDecimal("0.80");
    private static final BigDecimal MAX_BUDGET = new BigDecimal("100");

    private static BigDecimal d(String v) {
        return new BigDecimal(v);
    }

    private static Decision judge(long impressions, long clicks, String spend, long orders, String revenue, String budget, long days) {
        return AutopilotRules.judge(new Performance(impressions, clicks, d(spend), orders,
                revenue == null ? null : d(revenue), d(budget), days), MIN_CTR, null, MAX_BUDGET, "USD");
    }

    @Test
    void newAdsAreLeftToLearn() {
        Decision x = judge(400, 1, "2.00", 0, "0", "5", 1);
        assertEquals(Verdict.KEEP, x.verdict());
        assertTrue(x.reason().contains("Still learning"));
    }

    @Test
    void lowClickRatePausesAfterEnoughViews() {
        Decision x = judge(2000, 8, "6.00", 0, "0", "5", 2);   // 0.40% < 0.80%
        assertEquals(Verdict.PAUSE, x.verdict());
        assertTrue(x.reason().contains("0.40%"));
    }

    @Test
    void expensiveClicksPauseWhenALimitIsSet() {
        Decision x = AutopilotRules.judge(new Performance(1200, 25, d("20.00"), 0, d("0"), d("10"), 3),
                MIN_CTR, d("0.50"), MAX_BUDGET, "USD");             // 0.80 per click > 0.50
        assertEquals(Verdict.PAUSE, x.verdict());
        assertTrue(x.reason().contains("0.80 USD"));
    }

    @Test
    void spendingFourDaysOfBudgetWithoutOrdersPauses() {
        Decision x = judge(1400, 40, "20.00", 0, "0", "5", 4);
        assertEquals(Verdict.PAUSE, x.verdict());
    }

    @Test
    void winnersGetTwentyPercentMoreUpToTheCap() {
        Decision x = judge(5000, 120, "15.00", 3, "60.00", "10", 3); // 4x return
        assertEquals(Verdict.BUDGET_UP, x.verdict());
        assertEquals(d("12.00"), x.newBudget());
        Decision capped = AutopilotRules.judge(new Performance(5000, 120, d("15.00"), 3, d("60.00"), d("95"), 3),
                MIN_CTR, null, MAX_BUDGET, "USD");
        assertEquals(d("100.00"), capped.newBudget());
    }

    @Test
    void withoutAnExchangeRateWinnersAreJudgedOnClickRate() {
        Decision x = judge(3000, 60, "9.00", 2, null, "5", 2);       // 2% click rate, 2 orders
        assertEquals(Verdict.BUDGET_UP, x.verdict());
    }

    @Test
    void budgetForNewAdsRespectsTheDailyCapAndNetworkMinimum() {
        assertEquals(d("5.00"), AutopilotRules.budgetForNew(d("20"), d("10"), d("5"), d("1")));
        assertEquals(d("3.00"), AutopilotRules.budgetForNew(d("20"), d("17"), d("5"), d("1")));
        assertNull(AutopilotRules.budgetForNew(d("20"), d("19.50"), d("5"), d("1")));
        assertNull(AutopilotRules.budgetForNew(d("100"), d("0"), d("10"), d("20"))); // TikTok minimum
        assertEquals(2, AutopilotRules.openSlots(3, 1));
        assertEquals(0, AutopilotRules.openSlots(3, 5));
    }
}
