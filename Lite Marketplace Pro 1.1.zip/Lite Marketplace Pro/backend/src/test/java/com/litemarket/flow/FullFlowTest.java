package com.litemarket.flow;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Boots the whole API on an in-memory database and walks the main journey: a seller signs up and adds
 * products, a customer orders on WhatsApp and pays online (demo gateway), commission is charged and paid,
 * and the seller runs ads on the demo ad network. Run with: mvn test
 */
@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:flow;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "app.demo.seed=false",
        "app.payments.demo-mode=true",
        "app.ads.demo-mode=true",
        "app.commission.percent=5",
        "app.commission.due-limit=200",
        "app.ai.base-url=http://127.0.0.1:9",
        "app.storage.upload-dir=target/test-uploads"
})
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FullFlowTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper json;

    private JsonNode call(String method, String url, String token, String body, int expectedStatus) throws Exception {
        var req = switch (method) {
            case "GET" -> get(url);
            case "PUT" -> put(url);
            case "PATCH" -> patch(url);
            case "DELETE" -> delete(url);
            default -> post(url);
        };
        if (token != null) req = req.header("Authorization", "Bearer " + token);
        if (body != null) req = req.contentType(MediaType.APPLICATION_JSON).content(body);
        MvcResult r = mvc.perform(req).andExpect(status().is(expectedStatus)).andReturn();
        String text = r.getResponse().getContentAsString();
        return text.isEmpty() ? json.createObjectNode() : json.readTree(text);
    }

    private static boolean same(JsonNode n, String amount) {
        return n.decimalValue().compareTo(new BigDecimal(amount)) == 0;
    }

    @Test
    @Order(1)
    void sellerCustomerPaymentCommissionAndAdsJourney() throws Exception {
        // Public config works without logging in
        JsonNode config = call("GET", "/api/config", null, null, 200);
        assertTrue(same(config.path("commissionPercent"), "5"));
        assertTrue(config.path("ads").path("demo").asBoolean());

        // 1. Seller signs up (first account becomes admin)
        JsonNode auth = call("POST", "/api/auth/signup", null, """
                {"email":"ama@example.com","password":"supersecret1","storeName":"Ama's Kitchen","whatsapp":"024 123 4567"}
                """, 200);
        String token = auth.path("accessToken").asText();
        assertEquals("ADMIN", auth.path("me").path("role").asText());
        assertEquals("amas-kitchen", auth.path("me").path("store").path("slug").asText());
        assertEquals("233241234567", auth.path("me").path("store").path("whatsapp").asText());

        // Protected routes need the token
        call("GET", "/api/products", null, null, 401);
        call("POST", "/api/auth/login", null, """
                {"email":"ama@example.com","password":"wrong-password"}""", 401);

        // 2. Seller adds products
        JsonNode jollof = call("POST", "/api/products", token, """
                {"name":"Jollof Rice","price":45,"category":"Food","description":"Smoky","inStock":true,"stockQty":10,"featured":true}
                """, 200);
        long jollofId = jollof.path("id").asLong();
        call("POST", "/api/products", token, """
                {"name":"Sobolo","price":12.5,"category":"Drinks","inStock":true}""", 200);
        assertEquals(2, call("GET", "/api/products", token, null, 200).size());

        // 3. Customer sees the shop
        JsonNode shop = call("GET", "/api/shops/amas-kitchen", null, null, 200);
        assertEquals(2, shop.path("products").size());
        assertTrue(shop.path("providers").toString().contains("demo"));
        assertTrue(shop.path("whatsappOrders").asBoolean());

        // 4. Customer orders on WhatsApp: order is saved and a wa.me link comes back
        JsonNode wa = call("POST", "/api/shops/amas-kitchen/orders", null, """
                {"items":[{"productId":%d,"quantity":2}],
                 "customer":{"name":"Kofi","phone":"0201234567","address":"Osu","note":"Extra shito"}}
                """.formatted(jollofId), 200);
        assertTrue(same(wa.path("total"), "90"));
        assertTrue(wa.path("whatsappUrl").asText().startsWith("https://wa.me/233241234567?text="));

        // 5. Customer pays online with the demo gateway
        JsonNode checkout = call("POST", "/api/shops/amas-kitchen/checkout", null, """
                {"items":[{"productId":%d,"quantity":1}],
                 "customer":{"name":"Efua","phone":"0241112222","email":"efua@example.com","address":"East Legon"},
                 "provider":"demo"}
                """.formatted(jollofId), 200);
        String ref = checkout.path("reference").asText();
        assertTrue(checkout.path("checkoutUrl").asText().contains("/pay/demo?reference=" + ref));
        assertEquals("PENDING", call("POST", "/api/payments/verify", null,
                "{\"reference\":\"" + ref + "\"}", 200).path("status").asText());
        JsonNode paid = call("POST", "/api/payments/demo/" + ref + "/complete", null, null, 200);
        assertEquals("SUCCESS", paid.path("status").asText());
        assertTrue(paid.path("whatsappUrl").asText().startsWith("https://wa.me/"));
        // Paying twice delivers once
        assertEquals("SUCCESS", call("POST", "/api/payments/demo/" + ref + "/complete", null, null, 200)
                .path("status").asText());

        // Stock went down by 1 (paid) and the dashboard counts the sale
        for (JsonNode p : call("GET", "/api/products", token, null, 200)) {
            if (p.path("id").asLong() == jollofId) assertEquals(9, p.path("stockQty").asInt());
        }
        JsonNode dash = call("GET", "/api/dashboard", token, null, 200);
        assertEquals(1, dash.path("paidOrders").asInt());
        assertEquals(1, dash.path("newOrders").asInt());
        assertEquals(2, dash.path("totalOrders").asInt());

        // 6. Commission: the online payment paid 5% automatically; the WhatsApp order owes 5% once marked paid
        JsonNode earnings = call("GET", "/api/earnings", token, null, 200);
        assertEquals(0, earnings.path("due").decimalValue().signum());
        assertTrue(same(earnings.path("paidAllTime"), "2.25"));
        long waOrderId = 0;
        for (JsonNode o : call("GET", "/api/orders", token, null, 200)) {
            if ("WHATSAPP".equals(o.path("channel").asText())) waOrderId = o.path("id").asLong();
        }
        call("PATCH", "/api/orders/" + waOrderId + "/status", token, "{\"status\":\"PAID\"}", 200);
        call("PATCH", "/api/orders/" + waOrderId + "/status", token, "{\"status\":\"DELIVERED\"}", 200);
        assertTrue(same(call("GET", "/api/earnings", token, null, 200).path("due"), "4.50"));
        assertTrue(same(call("GET", "/api/me", token, null, 200).path("account").path("commissionDue"), "4.50"));
        // The seller pays it with the demo gateway and owes nothing
        JsonNode pay = call("POST", "/api/earnings/pay", token, "{\"provider\":\"demo\"}", 200);
        assertEquals("SUCCESS", call("POST", "/api/payments/demo/" + pay.path("reference").asText() + "/complete",
                null, null, 200).path("status").asText());
        assertEquals(0, call("GET", "/api/earnings", token, null, 200).path("due").decimalValue().signum());
        call("POST", "/api/earnings/pay", token, "{\"provider\":\"demo\"}", 400); // nothing left to pay

        // 7. Ads on the demo network: connect, launch, pause, resume, track a visit, read the numbers
        assertTrue(call("POST", "/api/ads/accounts/meta/connect", token, null, 200).path("url").asText()
                .contains("connected=meta"));
        JsonNode overview = call("GET", "/api/ads", token, null, 200);
        assertEquals("CONNECTED", overview.path("networks").path(0).path("status").asText());
        JsonNode ad = call("POST", "/api/ads", token, """
                {"network":"meta","productId":%d,"headline":"Smoky party jollof","primaryText":"Hot jollof in 2 taps",
                 "callToAction":"ORDER_NOW","dailyBudget":5,"countries":["GH"],"ageMin":18,"ageMax":45}
                """.formatted(jollofId), 200);
        long adId = ad.path("id").asLong();
        assertEquals("IN_REVIEW", ad.path("status").asText());
        assertTrue(ad.path("aiReason").isNull());
        call("POST", "/api/ads", token, """
                {"network":"meta","productId":%d,"headline":"Too much","primaryText":"x","dailyBudget":5000}
                """.formatted(jollofId), 400); // above the per-ad daily cap
        assertEquals("PAUSED", call("POST", "/api/ads/" + adId + "/pause", token, null, 200).path("status").asText());
        assertEquals("ACTIVE", call("POST", "/api/ads/" + adId + "/resume", token, null, 200).path("status").asText());
        call("POST", "/api/shops/amas-kitchen/track", null, "{\"ref\":\"ad" + adId + "\",\"event\":\"visit\"}", 204);
        call("POST", "/api/shops/amas-kitchen/orders", null, """
                {"items":[{"productId":%d,"quantity":1}],
                 "customer":{"name":"Yaw","phone":"0201234500","address":"Madina"},"ref":"ad%d"}
                """.formatted(jollofId, adId), 200);
        JsonNode stats = call("GET", "/api/ads/stats?days=7", token, null, 200);
        assertTrue(stats.path("totals").path("visits").asLong() >= 1);
        boolean tagged = false;
        for (JsonNode o : call("GET", "/api/orders", token, null, 200)) tagged |= o.path("fromAd").asBoolean();
        assertTrue(tagged);

        // Autopilot needs the seller to accept the spending limit first; a run works even with the AI offline
        String settings = """
                {"autopilotEnabled":true,"autoLaunch":true,"networks":["meta"],"dailyBudgetCap":20,"perAdBudget":5,
                 "maxActiveAds":3,"countries":["GH"],"ageMin":18,"ageMax":45,"minCtr":0.8,"acceptTerms":%s}
                """;
        call("PUT", "/api/ads/settings", token, settings.formatted("false"), 400);
        assertTrue(call("PUT", "/api/ads/settings", token, settings.formatted("true"), 200).path("termsAccepted").asBoolean());
        assertTrue(call("POST", "/api/ads/autopilot/run", token, null, 200).path("summary").asText().length() > 0);

        // 8. Admin endpoints work for the admin (they show commission, never sellers' ads)
        assertEquals(1, call("GET", "/api/admin/sellers", token, null, 200).size());
        JsonNode adminOverview = call("GET", "/api/admin/overview", token, null, 200);
        assertTrue(adminOverview.path("orders").asInt() >= 3);
        assertTrue(adminOverview.has("commissionEarned"));

        // Webhooks for disabled gateways are refused
        call("POST", "/api/webhooks/paystack", null, "{}", 404);
    }

    @Test
    @Order(2)
    void sellersOnlySeeTheirOwnAdsAndAdminIsProtected() throws Exception {
        String amaToken = call("POST", "/api/auth/login", null, """
                {"email":"ama@example.com","password":"supersecret1"}""", 200).path("accessToken").asText();
        long amaAd = call("GET", "/api/ads", amaToken, null, 200).path("ads").path(0).path("id").asLong();

        JsonNode second = call("POST", "/api/auth/signup", null, """
                {"email":"kofi@example.com","password":"supersecret1","storeName":"Kofi Kicks","whatsapp":"0241234599"}
                """, 200);
        assertEquals("SELLER", second.path("me").path("role").asText());
        String token = second.path("accessToken").asText();
        call("GET", "/api/admin/overview", token, null, 403);

        // Kofi can't see or touch Ama's ads, and can't launch before connecting an account
        assertEquals(0, call("GET", "/api/ads", token, null, 200).path("ads").size());
        call("POST", "/api/ads/" + amaAd + "/pause", token, null, 404);
        call("POST", "/api/ads", token, """
                {"network":"meta","productId":1,"headline":"x","primaryText":"y","dailyBudget":5}""", 400);

        // No product limit by default (sellers pay commission, not plans)
        for (int i = 0; i < 7; i++) {
            call("POST", "/api/products", token, "{\"name\":\"Shoe " + i + "\",\"price\":100,\"inStock\":true}", 200);
        }

        // Validation errors are readable
        JsonNode bad = call("POST", "/api/auth/signup", null, "{\"email\":\"nope\",\"password\":\"x\"}", 400);
        assertEquals("VALIDATION", bad.path("error").asText());
    }
}
