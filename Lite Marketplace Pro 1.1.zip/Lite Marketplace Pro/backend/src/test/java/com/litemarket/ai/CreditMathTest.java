package com.litemarket.ai;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CreditMathTest {

    private static final Instant NOW = Instant.parse("2026-10-05T10:00:00Z");

    @Test
    void aiCreditsResetMonthly() {
        assertEquals(LocalDate.parse("2026-10-01"), CreditMath.periodStart(NOW));
        assertEquals(12, CreditMath.used(LocalDate.parse("2026-10-01"), 12, NOW));
        assertEquals(0, CreditMath.used(LocalDate.parse("2026-09-01"), 49, NOW));
        assertEquals(0, CreditMath.used(null, 49, NOW));
    }
}
