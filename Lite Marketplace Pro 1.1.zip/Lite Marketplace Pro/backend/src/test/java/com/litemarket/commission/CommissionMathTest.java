package com.litemarket.commission;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CommissionMathTest {

    private static BigDecimal d(String v) {
        return new BigDecimal(v);
    }

    @Test
    void feeIsAPercentOfTheSaleRounded() {
        assertEquals(d("2.25"), CommissionMath.fee(d("45.00"), d("5")));
        assertEquals(d("0.63"), CommissionMath.fee(d("12.50"), d("5")));   // 0.625 rounds half up
        assertEquals(d("0.00"), CommissionMath.fee(d("100"), d("0")));
        assertEquals(d("0.00"), CommissionMath.fee(null, d("5")));
    }

    @Test
    void paymentSettlesTheOldestEntriesItCovers() {
        List<BigDecimal> due = List.of(d("2.00"), d("3.00"), d("5.00"));
        assertEquals(3, CommissionMath.coveredCount(due, d("10.00")));
        assertEquals(2, CommissionMath.coveredCount(due, d("9.99")));
        assertEquals(0, CommissionMath.coveredCount(due, d("1.00")));
        assertEquals(0, CommissionMath.coveredCount(List.of(), d("5.00")));
    }

    @Test
    void creditsMakeRoomForLaterEntries() {
        // 4 due, then a 4 credit (cancelled order), then 3 due: paying 3 covers all three lines.
        List<BigDecimal> due = List.of(d("4.00"), d("-4.00"), d("3.00"));
        assertEquals(3, CommissionMath.coveredCount(due, d("3.00")));
    }

    @Test
    void whatsappPausesOnlyAtTheLimit() {
        assertFalse(CommissionMath.whatsappPaused(d("199.99"), d("200")));
        assertTrue(CommissionMath.whatsappPaused(d("200.00"), d("200")));
        assertFalse(CommissionMath.whatsappPaused(d("5000"), d("0")));
        assertFalse(CommissionMath.whatsappPaused(d("5000"), null));
    }
}
