package com.litemarket.ads.network;

import com.litemarket.ads.network.AdModels.AccountRef;
import com.litemarket.ads.network.AdModels.DayRow;
import com.litemarket.ads.network.AdModels.Image;
import com.litemarket.ads.network.AdModels.LaunchSpec;
import com.litemarket.ads.network.AdModels.Launched;
import com.litemarket.ads.network.AdModels.Review;
import com.litemarket.ads.network.AdModels.TokenGrant;
import com.litemarket.payment.gateway.FakeHttp;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Request building and response parsing for Meta and TikTok, without calling the internet. */
class AdNetworksTest {

    private static final Image PHOTO = new Image("jollof.jpg", "image/jpeg", new byte[]{1, 2, 3, 4});
    private static final Image PHOTO2 = new Image("waakye.jpg", "image/jpeg", new byte[]{5, 6, 7});

    private static LaunchSpec spec(BigDecimal budget, List<Image> images) {
        return new LaunchSpec("Ama's Kitchen · Jollof", "Smoky party jollof", "Order hot jollof in 2 taps on WhatsApp!",
                "GHS 45", "ORDER_NOW", "https://shop.example/s/amas-kitchen?p=1&ref=ad9", budget,
                Instant.parse("2026-10-06T08:00:00Z"), null, List.of("GH"), 18, 45, images);
    }

    // ── Meta ───────────────────────────────────────────────────────────────────

    private static MetaAdsNetwork meta(FakeHttp http) {
        return new MetaAdsNetwork("app-1", "shh", "v26.0", "https://graph.test", "https://www.fb.test", http);
    }

    private static final AccountRef META_ACCOUNT =
            new AccountRef("EAAtoken", "act_123", "USD", "page-1", "ig-9", null, null);

    @Test
    void metaSignInUsesV26AndAdsScopes() {
        String url = meta(new FakeHttp()).authorizeUrl("st4te", "https://shop.example/api/ads/oauth/meta/callback");
        assertTrue(url.startsWith("https://www.fb.test/v26.0/dialog/oauth?client_id=app-1"));
        assertTrue(url.contains("state=st4te"));
        assertTrue(url.contains("ads_management"));
        assertTrue(url.contains("redirect_uri=https%3A%2F%2Fshop.example%2Fapi%2Fads%2Foauth%2Fmeta%2Fcallback"));
    }

    @Test
    void metaSwapsTheCodeForALongLivedToken() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"access_token\":\"short\",\"expires_in\":3600}")
                .reply(200, "{\"access_token\":\"long\",\"expires_in\":5183944}");
        TokenGrant g = meta(http).exchangeCode("c0de", "https://x/cb");
        assertEquals("long", g.accessToken());
        assertTrue(g.expiresAt().isAfter(Instant.now().plusSeconds(50L * 24 * 3600)));
        assertTrue(http.sent.get(1).url().contains("grant_type=fb_exchange_token"));
        assertTrue(http.sent.get(1).url().contains("fb_exchange_token=short"));
    }

    @Test
    void metaLaunchCreatesCampaignAdSetCreativeAndAd() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"images\":{\"jollof.jpg\":{\"hash\":\"h4sh\"}}}")
                .reply(200, "{\"id\":\"c1\"}")
                .reply(200, "{\"id\":\"s1\"}")
                .reply(200, "{\"id\":\"cr1\"}")
                .reply(200, "{\"id\":\"a1\"}");
        Launched l = meta(http).launch(META_ACCOUNT, spec(new BigDecimal("5.00"), List.of(PHOTO)));
        assertEquals(new Launched("c1", "s1", "cr1", "a1"), l);
        assertEquals(5, http.sent.size());
        assertEquals("Bearer EAAtoken", http.sent.get(0).authorization());
        assertTrue(http.sent.get(0).url().endsWith("/v26.0/act_123/adimages"));

        String campaign = http.sent.get(1).body();
        assertTrue(campaign.contains("objective=OUTCOME_TRAFFIC"));
        assertTrue(campaign.contains("special_ad_categories=%5B%5D"));
        assertTrue(campaign.contains("is_adset_budget_sharing_enabled=false"));

        String adSet = java.net.URLDecoder.decode(http.sent.get(2).body(), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(adSet.contains("daily_budget=500"));          // 5.00 USD in cents
        assertTrue(adSet.contains("\"advantage_audience\":0"));
        assertTrue(adSet.contains("\"instagram\""));
        assertFalse(adSet.contains("explore"));
        assertTrue(adSet.contains("\"countries\":[\"GH\"]"));

        String creative = java.net.URLDecoder.decode(http.sent.get(3).body(), java.nio.charset.StandardCharsets.UTF_8);
        assertTrue(creative.contains("\"instagram_user_id\":\"ig-9\""));
        assertTrue(creative.contains("\"image_hash\":\"h4sh\""));
        assertTrue(creative.contains("\"type\":\"ORDER_NOW\""));
        assertTrue(creative.contains("ref=ad9"));

        assertTrue(java.net.URLDecoder.decode(http.sent.get(4).body(), java.nio.charset.StandardCharsets.UTF_8)
                .contains("{\"creative_id\":\"cr1\"}"));
    }

    @Test
    void metaCleansUpWhenALaterStepFails() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"images\":{\"jollof.jpg\":{\"hash\":\"h4sh\"}}}")
                .reply(200, "{\"id\":\"c1\"}")
                .reply(400, "{\"error\":{\"message\":\"Invalid parameter\",\"code\":100,"
                        + "\"error_user_msg\":\"Budget is too low.\"}}")
                .reply(200, "{\"success\":true}");
        AdsException e = assertThrows(AdsException.class,
                () -> meta(http).launch(META_ACCOUNT, spec(new BigDecimal("0.50"), List.of(PHOTO))));
        assertEquals("Facebook: Budget is too low.", e.getMessage());
        assertTrue(http.last().url().endsWith("/v26.0/c1"));
        assertTrue(http.last().body().contains("status=DELETED"));
    }

    @Test
    void metaExpiredTokenAsksToReconnect() {
        FakeHttp http = new FakeHttp().reply(400, "{\"error\":{\"message\":\"Session has expired\",\"code\":190}}");
        AdsException e = assertThrows(AdsException.class,
                () -> meta(http).review(META_ACCOUNT, new Launched("c1", "s1", "cr1", "a1")));
        assertTrue(e.reconnect());
    }

    @Test
    void metaReadsReviewAndDailyResults() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"effective_status\":\"DISAPPROVED\",\"ad_review_feedback\":{\"global\":"
                        + "{\"Prohibited Content\":\"Your ad goes against our policies.\"}}}")
                .reply(200, "{\"data\":[{\"date_start\":\"2026-10-04\",\"impressions\":\"1200\",\"reach\":\"900\","
                        + "\"clicks\":\"40\",\"inline_link_clicks\":\"31\",\"spend\":\"3.21\"}]}");
        MetaAdsNetwork m = meta(http);
        Review r = m.review(META_ACCOUNT, new Launched("c1", "s1", "cr1", "a1"));
        assertEquals("REJECTED", r.status());
        assertEquals("Your ad goes against our policies.", r.note());
        Map<String, List<DayRow>> rows = m.results(META_ACCOUNT, List.of(new Launched("c1", "s1", "cr1", "a1")),
                LocalDate.parse("2026-10-01"), LocalDate.parse("2026-10-05"));
        DayRow d = rows.get("a1").get(0);
        assertEquals(LocalDate.parse("2026-10-04"), d.day());
        assertEquals(1200, d.impressions());
        assertEquals(31, d.clicks());                       // link clicks, not all clicks
        assertEquals(new BigDecimal("3.21"), d.spend());
        assertTrue(http.last().url().contains("time_increment=1"));
    }

    // ── TikTok ─────────────────────────────────────────────────────────────────

    private static TikTokAdsNetwork tiktok(FakeHttp http) {
        return new TikTokAdsNetwork("tt-app", "tt-secret", "https://tt.test/open_api/v1.3", "https://tt.test/portal/auth",
                new BigDecimal("20"), "music-7", http);
    }

    private static final AccountRef TT_ACCOUNT =
            new AccountRef("tt-token", "adv-1", "USD", null, null, "ident-1", "TT_USER");

    @Test
    void tiktokExchangesAuthCodeAndKeepsAdvertisers() {
        FakeHttp http = new FakeHttp().reply(200,
                "{\"code\":0,\"message\":\"OK\",\"data\":{\"access_token\":\"tt-token\",\"advertiser_ids\":[\"adv-1\",\"adv-2\"]}}");
        TokenGrant g = tiktok(http).exchangeCode("auth-c0de", "https://x/cb");
        assertEquals("tt-token", g.accessToken());
        assertEquals(List.of("adv-1", "adv-2"), g.accountIds());
        assertTrue(http.last().body().contains("\"auth_code\":\"auth-c0de\""));
        assertTrue(http.last().url().endsWith("/oauth2/access_token/"));
    }

    @Test
    void tiktokLaunchCreatesACarouselTrafficAd() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"code\":0,\"data\":{\"image_id\":\"img-1\"}}")
                .reply(200, "{\"code\":0,\"data\":{\"image_id\":\"img-2\"}}")
                .reply(200, "{\"code\":0,\"data\":{\"campaign_id\":\"tc1\"}}")
                .reply(200, "{\"code\":0,\"data\":{\"adgroup_id\":\"tg1\"}}")
                .reply(200, "{\"code\":0,\"data\":{\"ad_ids\":[\"ta1\"]}}");
        Launched l = tiktok(http).launch(TT_ACCOUNT, spec(new BigDecimal("20"), List.of(PHOTO, PHOTO2)));
        assertEquals(new Launched("tc1", "tg1", null, "ta1"), l);
        assertEquals("tt-token", http.sent.get(0).authorization());
        assertTrue(http.sent.get(0).body().contains("UPLOAD_BY_FILE"));
        String group = http.sent.get(3).body();
        assertTrue(group.contains("\"location_ids\":[\"2300660\"]"));
        assertTrue(group.contains("\"PLACEMENT_TIKTOK\""));
        assertTrue(group.contains("\"budget_mode\":\"BUDGET_MODE_DAY\""));
        assertTrue(group.contains("\"age_groups\":[\"AGE_18_24\",\"AGE_25_34\",\"AGE_35_44\",\"AGE_45_54\"]"));
        String ad = http.sent.get(4).body();
        assertTrue(ad.contains("\"ad_format\":\"CAROUSEL_ADS\""));
        assertTrue(ad.contains("\"image_ids\":[\"img-1\",\"img-2\"]"));
        assertTrue(ad.contains("\"music_id\":\"music-7\""));
        assertTrue(ad.contains("\"identity_id\":\"ident-1\""));
        assertTrue(ad.contains("\"call_to_action\":\"ORDER_NOW\""));
    }

    @Test
    void tiktokChecksPhotosBudgetAndIdentityFirst() {
        TikTokAdsNetwork t = tiktok(new FakeHttp());
        assertThrows(AdsException.class, () -> t.launch(TT_ACCOUNT, spec(new BigDecimal("20"), List.of(PHOTO))));
        assertThrows(AdsException.class, () -> t.launch(TT_ACCOUNT, spec(new BigDecimal("5"), List.of(PHOTO, PHOTO2))));
        AccountRef noIdentity = new AccountRef("tt-token", "adv-1", "USD", null, null, null, null);
        assertThrows(AdsException.class, () -> t.launch(noIdentity, spec(new BigDecimal("20"), List.of(PHOTO, PHOTO2))));
    }

    @Test
    void tiktokErrorsComeBackWithHttp200() {
        FakeHttp http = new FakeHttp()
                .reply(200, "{\"code\":40105,\"message\":\"Access token is incorrect or has been revoked.\"}")
                .reply(200, "{\"code\":40002,\"message\":\"Budget too low\"}");
        TikTokAdsNetwork t = tiktok(http);
        Launched ids = new Launched("tc1", "tg1", null, "ta1");
        AdsException revoked = assertThrows(AdsException.class, () -> t.setActive(TT_ACCOUNT, ids, false));
        assertTrue(revoked.reconnect());
        AdsException bad = assertThrows(AdsException.class, () -> t.updateBudget(TT_ACCOUNT, ids, new BigDecimal("25")));
        assertEquals("TikTok: Budget too low", bad.getMessage());
    }

    @Test
    void tiktokReadsReportRowsForOurAds() {
        FakeHttp http = new FakeHttp().reply(200, "{\"code\":0,\"data\":{\"list\":["
                + "{\"dimensions\":{\"ad_id\":\"ta1\",\"stat_time_day\":\"2026-10-04 00:00:00\"},"
                + "\"metrics\":{\"spend\":\"18.40\",\"impressions\":\"5200\",\"clicks\":\"61\",\"reach\":\"4100\"}},"
                + "{\"dimensions\":{\"ad_id\":\"someone-elses\",\"stat_time_day\":\"2026-10-04 00:00:00\"},"
                + "\"metrics\":{\"spend\":\"1\",\"impressions\":\"1\",\"clicks\":\"1\",\"reach\":\"1\"}}]}}");
        Map<String, List<DayRow>> rows = tiktok(http).results(TT_ACCOUNT, List.of(new Launched("tc1", "tg1", null, "ta1")),
                LocalDate.parse("2026-09-01"), LocalDate.parse("2026-10-05"));
        assertEquals(1, rows.size());
        DayRow d = rows.get("ta1").get(0);
        assertEquals(5200, d.impressions());
        assertEquals(new BigDecimal("18.40"), d.spend());
        assertTrue(http.last().url().contains("start_date=2026-09-06"));  // 30-day window
    }

    @Test
    void tiktokAudienceHelpers() {
        assertEquals(List.of("AGE_25_34", "AGE_35_44"), TikTokAdsNetwork.ageGroups(25, 40));
        assertEquals(List.of("2300660", "2328926"), TikTokAdsNetwork.locationIds(List.of("gh", "NG")));
        assertThrows(AdsException.class, () -> TikTokAdsNetwork.locationIds(List.of("ZZ")));
    }

    // ── Demo network ───────────────────────────────────────────────────────────

    @Test
    void demoNetworkGeneratesBelievableResults() {
        SimulatedAdsNetwork sim = new SimulatedAdsNetwork("meta", "Facebook & Instagram");
        Instant now = Instant.parse("2026-10-05T12:00:00Z");
        List<SimulatedAdsNetwork.SimDay> days = sim.simulate("sim-ad-x", new BigDecimal("40"), "GHS",
                Instant.parse("2026-09-28T12:00:00Z"), now, now);
        assertEquals(8, days.size());
        for (SimulatedAdsNetwork.SimDay d : days) {
            assertTrue(d.spend().compareTo(new BigDecimal("40.01")) < 0);
            assertTrue(d.clicks() <= d.impressions());
            assertTrue(d.whatsappClicks() <= d.visits());
        }
        // Same inputs, same numbers (stable between syncs).
        assertEquals(days, sim.simulate("sim-ad-x", new BigDecimal("40"), "GHS",
                Instant.parse("2026-09-28T12:00:00Z"), now, now));
    }
}
