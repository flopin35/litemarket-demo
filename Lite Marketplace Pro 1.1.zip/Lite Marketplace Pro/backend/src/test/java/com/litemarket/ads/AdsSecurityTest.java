package com.litemarket.ads;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AdsSecurityTest {

    private static final Instant NOW = Instant.parse("2026-10-05T10:00:00Z");

    @Test
    void oauthStateRoundTripsAndExpires() {
        String state = OAuthState.create("secret", 42L, "meta", NOW);
        OAuthState.Payload p = OAuthState.verify("secret", state, NOW.plus(Duration.ofMinutes(5))).orElseThrow();
        assertEquals(42L, p.storeId());
        assertEquals("meta", p.network());
        assertTrue(OAuthState.verify("secret", state, NOW.plus(Duration.ofMinutes(16))).isEmpty());
    }

    @Test
    void oauthStateCantBeForged() {
        String state = OAuthState.create("secret", 42L, "meta", NOW);
        assertTrue(OAuthState.verify("other-secret", state, NOW).isEmpty());
        String tampered = state.replaceFirst("^.", state.charAt(0) == 'A' ? "B" : "A");
        assertTrue(OAuthState.verify("secret", tampered, NOW).isEmpty());
        assertTrue(OAuthState.verify("secret", "garbage", NOW).isEmpty());
        assertTrue(OAuthState.verify("secret", null, NOW).isEmpty());
    }

    @Test
    void tokensAreEncryptedAtRest() {
        TokenCipher c = new TokenCipher("key-one");
        String enc = c.encrypt("EAAB-secret-token");
        assertNotEquals("EAAB-secret-token", enc);
        assertNotEquals(enc, c.encrypt("EAAB-secret-token")); // random IV
        assertEquals("EAAB-secret-token", c.decrypt(enc));
        assertNull(new TokenCipher("key-two").decrypt(enc));    // wrong key: reconnect instead of crashing
    }

    @Test
    void campaignRefMatchesOrderParsing() {
        AdCampaign c = new AdCampaign();
        c.setId(7L);
        assertEquals("ad7", c.ref());
        assertEquals(7L, com.litemarket.order.OrderService.adIdFromRef(c.ref()));
        assertNull(com.litemarket.order.OrderService.adIdFromRef("ad7; drop table"));
        assertNull(com.litemarket.order.OrderService.adIdFromRef(null));
    }
}
