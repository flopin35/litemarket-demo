"""Social ads: ad copy and the autopilot's product picks.  Run: python -m unittest discover -s tests -v"""
from __future__ import annotations

import json
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from test_service import KEY, STORE, Base, anthropic_reply  # noqa: E402

PRODUCTS = [
    {"id": 1, "name": "Jollof Rice & Grilled Chicken", "price": 45, "category": "Food", "available": True,
     "featured": True, "units_30": 40, "units_7": 12, "revenue_30": 1800, "has_image": True, "stock_qty": None},
    {"id": 2, "name": "Waakye Special", "price": 35, "category": "Food", "available": True,
     "units_30": 22, "units_7": 6, "has_image": True},
    {"id": 3, "name": "Sobolo (500ml)", "price": 12, "category": "Drinks", "available": True,
     "units_30": 15, "units_7": 3, "has_image": True},
    {"id": 4, "name": "Meat Pie (2 pieces)", "price": 10, "category": "Snacks", "available": True,
     "units_30": 30, "units_7": 9, "has_image": True, "stock_qty": 2},
    {"id": 5, "name": "Kelewele", "price": 15, "category": "Snacks", "available": True,
     "units_30": 4, "units_7": 1, "has_image": True, "past_ads": 1, "best_ctr": 0.3},
]


def autopilot_body(**over):
    body = {"store": STORE, "products": PRODUCTS, "running_ads": [], "slots": 2, "networks": ["meta"],
            "budget_per_ad": 40, "ad_currency": "GHS", "audience": {"countries": ["GH"], "age_min": 18, "age_max": 45}}
    body.update(over)
    return body


class OfflineAdsTest(Base):

    def test_ad_copy_gives_three_variants_within_limits(self):
        out = self.post("/v1/ad-copy", {"store": STORE, "product": PRODUCTS[0], "network": "meta"}).get_json()
        self.assertEqual("offline", out["engine"])
        self.assertEqual(3, len(out["variants"]))
        for v in out["variants"]:
            self.assertLessEqual(len(v["headline"]), 40)
            self.assertLessEqual(len(v["primary_text"]), 250)
            self.assertEqual("ORDER_NOW", v["call_to_action"])        # food
        angles = [v["angle"] for v in out["variants"]]
        self.assertIn("Price", angles)
        self.assertIn("Popular", angles)                               # 40 sold: a real number, not a claim
        self.assertIn("40 sold this month", out["variants"][2]["primary_text"])
        self.assertIn("45", out["variants"][1]["headline"])

    def test_tiktok_copy_is_one_short_line_with_hashtags(self):
        out = self.post("/v1/ad-copy", {"store": STORE, "product": PRODUCTS[2], "network": "tiktok"}).get_json()
        for v in out["variants"]:
            self.assertLessEqual(len(v["primary_text"]), 100)
            self.assertIn("#", v["primary_text"])
        self.assertTrue(any("carousel" in t for t in out["tips"]))

    def test_copy_warns_when_the_product_has_no_photo(self):
        product = {**PRODUCTS[1], "has_image": False, "units_30": 0}
        out = self.post("/v1/ad-copy", {"store": STORE, "product": product}).get_json()
        self.assertIn("photo", out["tips"][0])
        self.assertIn("Invitation", [v["angle"] for v in out["variants"]])   # no fake popularity claim

    def test_autopilot_picks_by_sales_and_spreads_categories(self):
        out = self.post("/v1/ads-autopilot", autopilot_body(slots=3)).get_json()
        ids = [p["product_id"] for p in out["picks"]]
        self.assertEqual(1, ids[0])                    # best seller first
        self.assertNotIn(4, ids[:2])                   # only 2 meat pies left: don't pay to sell out
        self.assertNotIn(5, ids)                       # earlier ad flopped (0.3% clicks)
        self.assertIn(3, ids)                          # a drink fills the last slot
        self.assertIn("40 sold", out["picks"][0]["reason"])
        self.assertTrue(all(p["network"] == "meta" for p in out["picks"]))

    def test_autopilot_skips_products_already_running_and_alternates_networks(self):
        out = self.post("/v1/ads-autopilot", autopilot_body(
            slots=2, networks=["meta", "tiktok"],
            running_ads=[{"product_id": 1, "network": "meta", "status": "ACTIVE", "ctr": 2.1, "orders": 5}])).get_json()
        ids = [p["product_id"] for p in out["picks"]]
        self.assertNotIn(1, ids)
        self.assertEqual(["meta", "tiktok"], [p["network"] for p in out["picks"]])
        self.assertLessEqual(len(out["picks"][1]["primary_text"]), 100)

    def test_autopilot_with_nothing_to_advertise(self):
        out = self.post("/v1/ads-autopilot", autopilot_body(products=[{**PRODUCTS[0], "available": False}])).get_json()
        self.assertEqual([], out["picks"])
        self.assertIn("No products", out["summary"])

    def test_autopilot_validates_input(self):
        self.assertEqual(422, self.post("/v1/ads-autopilot", autopilot_body(networks=["myspace"])).status_code)
        self.assertEqual(422, self.post("/v1/ads-autopilot", autopilot_body(budget_per_ad=0)).status_code)


class ClaudeAdsTest(Base):
    provider_settings = {"provider": "auto", "anthropic_key": "sk-ant-test"}

    def test_model_picks_are_limited_to_the_shortlist(self):
        answer = {"picks": [
            {"product_id": 999, "network": "meta", "headline": "Invented", "primary_text": "x", "reason": "x"},
            {"product_id": 3, "network": "linkedin", "headline": "Ice-cold sobolo for the heat wave this week",
             "primary_text": "Chilled hibiscus sobolo with ginger. Add one to your lunch!",
             "call_to_action": "ORDER_NOW", "reason": "Drinks are an easy add-on."},
            {"product_id": 3, "network": "meta", "headline": "Duplicate", "primary_text": "x", "reason": "x"},
        ], "summary": "Push drinks."}
        with mock.patch("app.llm.requests.post", return_value=anthropic_reply(answer)) as post:
            out = self.post("/v1/ads-autopilot", autopilot_body()).get_json()
        self.assertEqual("claude", out["engine"])
        self.assertEqual([3], [p["product_id"] for p in out["picks"]])    # unknown id and duplicate dropped
        self.assertEqual("meta", out["picks"][0]["network"])              # unknown network replaced
        self.assertLessEqual(len(out["picks"][0]["headline"]), 40)         # trimmed to the platform limit
        sent = post.call_args.kwargs["json"]["messages"][0]["content"][-1]["text"]
        self.assertIn("CANDIDATES", sent)
        self.assertIn("score", sent)

    def test_unusable_answers_fall_back_to_the_offline_plan(self):
        with mock.patch("app.llm.requests.post", return_value=anthropic_reply({"picks": []})):
            out = self.post("/v1/ads-autopilot", autopilot_body()).get_json()
        self.assertEqual("offline", out["engine"])
        self.assertEqual(2, len(out["picks"]))

    def test_ad_copy_from_claude_is_trimmed_and_validated(self):
        answer = {"variants": [{"angle": "Taste", "headline": "Smoky party jollof, delivered hot to your door in Accra",
                                "primary_text": "Real party jollof 🔥", "call_to_action": "ORDER_NOW"}],
                  "tips": ["Post at lunchtime"]}
        with mock.patch("app.llm.requests.post", return_value=anthropic_reply(answer)):
            out = self.post("/v1/ad-copy", {"store": STORE, "product": PRODUCTS[0]}).get_json()
        self.assertEqual("claude", out["engine"])
        self.assertLessEqual(len(out["variants"][0]["headline"]), 40)
        bad = anthropic_reply({"variants": [{"angle": "x", "headline": "", "primary_text": "y",
                                             "call_to_action": "CALL_ME"}]})
        with mock.patch("app.llm.requests.post", return_value=bad):
            out = self.post("/v1/ad-copy", {"store": STORE, "product": PRODUCTS[0]}).get_json()
        self.assertEqual("offline", out["engine"])


if __name__ == "__main__":
    unittest.main()
