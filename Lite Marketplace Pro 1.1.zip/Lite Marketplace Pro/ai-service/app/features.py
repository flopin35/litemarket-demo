"""Each feature: try the language model, validate its JSON, fall back to the offline engine."""
from __future__ import annotations

import logging
import re

from pydantic import ValidationError

from . import ads, offline, prompts
from .analytics import analyse, display_stats
from .llm import LLM, Image, LLMError, extract_json
from .schemas import (AdCopyIn, AdCopyOut, AdPick, AutopilotIn, AutopilotOut, BroadcastIn, BroadcastOut, CoachIn,
                      CoachOut, ProductWriterIn, ProductWriterOut, ReplyDraftsIn, ReplyDraftsOut, ShopChatIn,
                      ShopChatOut)

log = logging.getLogger("ai.features")


class Features:
    def __init__(self, llm: LLM):
        self.llm = llm

    def _ask(self, system: str, user: str, **kw) -> dict | None:
        if not self.llm.available:
            return None
        try:
            return extract_json(self.llm.complete(system, user, **kw))
        except LLMError as e:
            log.warning("AI provider failed, using offline engine: %s", e)
            return None

    # ── Product writer ─────────────────────────────────────────────────────────

    def product_writer(self, inp: ProductWriterIn) -> ProductWriterOut:
        image = Image(inp.image.media_type, inp.image.data) if inp.image else None
        user = prompts.as_json({
            "store": prompts.store_brief(inp.store),
            "product": inp.product.model_dump(),
            "photo_attached": image is not None,
        })
        data = self._ask(prompts.product_writer(inp.language, inp.tone), user, image=image, max_tokens=900)
        if data is not None:
            try:
                out = ProductWriterOut(**{**data, "engine": self.llm.engine})
                if out.category not in offline.CATEGORIES:
                    out.category = offline.normalise_category(out.category, inp.product.name, inp.product.notes)
                out.hashtags = [h if h.startswith("#") else "#" + h for h in out.hashtags][:8]
                return out
            except (ValidationError, TypeError) as e:
                log.warning("Product writer answer rejected: %s", e)
        return offline.write_product(inp)

    # ── Reply drafts ───────────────────────────────────────────────────────────

    def reply_drafts(self, inp: ReplyDraftsIn) -> ReplyDraftsOut:
        user = prompts.as_json({
            "store": prompts.store_brief(inp.store),
            "customer_message": inp.message,
            "order": inp.order.model_dump() if inp.order else None,
        })
        data = self._ask(prompts.reply_drafts(inp.language, inp.tone), user, max_tokens=900)
        if data is not None:
            try:
                return ReplyDraftsOut(**{**data, "engine": self.llm.engine})
            except (ValidationError, TypeError) as e:
                log.warning("Reply drafts answer rejected: %s", e)
        return offline.draft_replies(inp)

    # ── Shop chat ──────────────────────────────────────────────────────────────

    def shop_chat(self, inp: ShopChatIn) -> ShopChatOut:
        valid_ids = {p.id for p in inp.products if p.id is not None and p.available}
        transcript = "\n".join(
            f"{'Customer' if m.role == 'user' else 'Assistant'}: {m.content}" for m in inp.messages[-12:])
        cart = [p.name for p in inp.products if p.id in set(inp.cart)]
        user = (f"CATALOG ({inp.store.currency}):\n{prompts.catalog_lines(inp.products[:80], inp.store.currency)}\n\n"
                f"CART: {', '.join(cart) if cart else 'empty'}\n\n"
                f"CONVERSATION:\n{transcript}\n\nReply to the customer's last message.")
        data = self._ask(prompts.shop_chat(inp.store), user, fast=True, max_tokens=500)
        if data is not None:
            try:
                ids: list[int] = []
                for raw in data.get("suggestions") or []:
                    try:
                        value = int(re.sub(r"[^0-9]", "", str(raw)) or -1)
                    except ValueError:
                        continue
                    if value in valid_ids and value not in ids:
                        ids.append(value)
                return ShopChatOut(reply=str(data.get("reply", "")).strip(), suggestions=ids[:3],
                                   engine=self.llm.engine)
            except (ValidationError, TypeError) as e:
                log.warning("Shop chat answer rejected: %s", e)
        return offline.shop_chat(inp)

    # ── Sales coach ────────────────────────────────────────────────────────────

    def coach(self, inp: CoachIn) -> CoachOut:
        analysis = analyse(inp)
        rules = offline.coach(inp, analysis)
        user = prompts.as_json({
            "store": inp.store.name,
            "numbers": analysis.as_dict(),
            "findings": [i.model_dump() for i in rules.insights],
        })
        data = self._ask(prompts.coach(), user, max_tokens=1200)
        if data is not None:
            try:
                out = CoachOut(**{**data, "stats": display_stats(analysis), "engine": self.llm.engine})
                return out
            except (ValidationError, TypeError) as e:
                log.warning("Coach answer rejected: %s", e)
        return rules

    # ── Broadcast ──────────────────────────────────────────────────────────────

    def broadcast(self, inp: BroadcastIn) -> BroadcastOut:
        user = prompts.as_json({
            "store": prompts.store_brief(inp.store),
            "goal": inp.goal,
            "products": [{"name": p.name, "price": p.price, "category": p.category,
                          "description": (p.description or "")[:200]} for p in inp.products],
        })
        data = self._ask(prompts.broadcast(inp.language, inp.tone), user, max_tokens=700)
        if data is not None:
            try:
                return BroadcastOut(**{**data, "engine": self.llm.engine})
            except (ValidationError, TypeError) as e:
                log.warning("Broadcast answer rejected: %s", e)
        return offline.broadcast(inp)

    # ── Social ads ─────────────────────────────────────────────────────────────

    def ad_copy(self, inp: AdCopyIn) -> AdCopyOut:
        p = inp.product
        user = prompts.as_json({
            "store": prompts.store_brief(inp.store),
            "product": {"name": p.name, "price": p.price, "category": p.category,
                        "description": (p.description or "")[:400], "sold_last_30_days": p.units_30},
            "network": inp.network,
        })
        data = self._ask(prompts.ad_copy(inp.language, inp.tone, inp.network), user, max_tokens=900)
        if data is not None:
            try:
                fixed = []
                for v in (data.get("variants") or [])[:3]:
                    v = dict(v)
                    v["headline"] = ads.cut(str(v.get("headline", "")), 40)
                    v["primary_text"] = ads.cut(str(v.get("primary_text", "")), 100 if inp.network == "tiktok" else 500)
                    if v.get("description"):
                        v["description"] = ads.cut(str(v["description"]), 60)
                    fixed.append(v)
                out = AdCopyOut(variants=fixed, tips=[str(t)[:200] for t in (data.get("tips") or [])][:3],
                                engine=self.llm.engine)
                if not p.has_image:
                    out.tips = ["Add a photo to this product first: ads can't run without one."] + out.tips[:2]
                return out
            except (ValidationError, TypeError, ValueError) as e:
                log.warning("Ad copy answer rejected: %s", e)
        return ads.ad_copy(inp)

    def ads_autopilot(self, inp: AutopilotIn) -> AutopilotOut:
        running = {a.product_id for a in inp.running_ads if a.product_id is not None and a.status != "PAUSED"}
        scored = ads.score_products(inp.products, running)
        if not scored:
            return ads.autopilot(inp)
        shortlist = scored[: inp.slots + 4]
        by_id = {s.product.id: s for s in shortlist}
        user = prompts.as_json({
            "store": prompts.store_brief(inp.store),
            "SLOTS": inp.slots,
            "NETWORKS": inp.networks,
            "budget_per_ad_per_day": f"{inp.budget_per_ad:.2f} {inp.ad_currency}",
            "audience": inp.audience.model_dump(),
            "CANDIDATES": [{"id": s.product.id, "name": s.product.name, "price": s.product.price,
                            "category": s.category, "score": s.score, "signals": s.why,
                            "description": (s.product.description or "")[:200]} for s in shortlist],
            "running_ads": [a.model_dump() for a in inp.running_ads],
        })
        data = self._ask(prompts.ads_autopilot(inp.language), user, max_tokens=1400)
        if data is not None:
            try:
                picks: list[AdPick] = []
                for raw in data.get("picks") or []:
                    pid = int(raw.get("product_id"))
                    if pid not in by_id or any(p.product_id == pid for p in picks):
                        continue  # only shortlisted products, each once
                    network = raw.get("network") if raw.get("network") in inp.networks else inp.networks[0]
                    limit = 100 if network == "tiktok" else 500
                    picks.append(AdPick(
                        product_id=pid, network=network,
                        headline=ads.cut(str(raw.get("headline", "")), 40),
                        primary_text=ads.cut(str(raw.get("primary_text", "")), limit),
                        description=ads.cut(str(raw["description"]), 60) if raw.get("description") else None,
                        call_to_action=raw.get("call_to_action") or "SHOP_NOW",
                        reason=ads.cut(str(raw.get("reason") or f"Chosen because {by_id[pid].why}."), 300),
                        score=by_id[pid].score))
                    if len(picks) >= inp.slots:
                        break
                if picks:
                    return AutopilotOut(picks=picks, summary=ads.cut(str(data.get("summary") or "New ads planned."), 400),
                                        engine=self.llm.engine)
            except (ValidationError, TypeError, ValueError, KeyError) as e:
                log.warning("Autopilot answer rejected: %s", e)
        return ads.autopilot(inp)
