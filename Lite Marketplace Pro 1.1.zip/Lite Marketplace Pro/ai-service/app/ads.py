"""Social ads: product scoring for the autopilot (plain maths) and the offline ad writer.

The numbers that decide what to advertise are computed here, in code. The language model only chooses among
the best-scored products and writes the words; if it is unavailable, this module writes the ads itself.
"""
from __future__ import annotations

from dataclasses import dataclass

from .offline import COPY, fmt_price, no_emoji, normalise_category, smart_title, tag
from .schemas import (AdCopyIn, AdCopyOut, AdPick, AdProductCtx, AdVariant, AutopilotIn, AutopilotOut,
                      StoreCtx)

ENGINE = "offline"
FOOD_LIKE = {"Food", "Drinks", "Snacks"}


def cut(text: str, limit: int) -> str:
    text = " ".join((text or "").split())
    if len(text) <= limit:
        return text
    trimmed = text[: limit - 1].rsplit(" ", 1)[0].rstrip(",.;:-–")
    return (trimmed or text[: limit - 1]) + "…"


# ── Scoring ─────────────────────────────────────────────────────────────────────

@dataclass
class Scored:
    product: AdProductCtx
    score: float
    category: str
    why: str


def score_products(products: list[AdProductCtx], running_ids: set[int]) -> list[Scored]:
    """Ranks products by how likely an ad is to pay off, with a plain-language reason for each."""
    out: list[Scored] = []
    for p in products:
        if p.id is None or not p.available or p.id in running_ids:
            continue
        if p.stock_qty is not None and p.stock_qty <= 3:
            continue  # nearly sold out: don't pay to advertise it
        category = normalise_category(p.category, p.name, p.description)
        score = p.units_7 * 3.0 + p.units_30 * 1.0
        reasons: list[str] = []
        if p.units_30:
            reasons.append(f"{p.units_30} sold in the last 30 days" + (f" ({p.units_7} this week)" if p.units_7 else ""))
        if p.featured:
            score += 2
            reasons.append("it's one of your featured products")
        if p.past_ads and p.best_ctr >= 1.5:
            score += 3
            reasons.append(f"its earlier ad got a {p.best_ctr:.1f}% click rate")
        elif p.past_ads and p.best_ctr < 0.5:
            score -= 3
        if p.stock_qty is not None and p.stock_qty >= 10:
            score += 1
            reasons.append(f"{p.stock_qty} in stock")
        if p.has_image:
            score += 1
        if not reasons:
            reasons.append("it's in stock and hasn't been advertised yet")
        out.append(Scored(p, round(score, 2), category, "; ".join(reasons)))
    out.sort(key=lambda s: (-s.score, s.product.id or 0))
    return out


def choose(scored: list[Scored], slots: int) -> list[Scored]:
    """Best scores first. Variety across categories wins only between products with comparable scores
    (at least 40% of the best), so a weak product is never chosen just because its category is new."""
    picked: list[Scored] = []
    used: set[str] = set()
    top = scored[0].score if scored else 0
    for s in scored:
        if len(picked) >= slots:
            break
        if s.category not in used and s.score >= 0.4 * top:
            picked.append(s)
            used.add(s.category)
    for s in scored:
        if len(picked) >= slots:
            break
        if s not in picked:
            picked.append(s)
    return picked


# ── Offline writer ──────────────────────────────────────────────────────────────

def _cta(category: str) -> str:
    return "ORDER_NOW" if category in FOOD_LIKE else "SHOP_NOW"


def _how_to_buy(store: StoreCtx) -> str:
    if store.whatsapp_orders and store.online_payments:
        return "Order on WhatsApp or pay with MoMo or card."
    if store.whatsapp_orders:
        return "Order in 2 taps on WhatsApp."
    return "Pay online with MoMo or card."


def variants(store: StoreCtx, p: AdProductCtx, network: str, tone: str = "exciting") -> list[AdVariant]:
    category = normalise_category(p.category, p.name, p.description)
    copy = COPY.get(category, COPY["Other"])
    name = smart_title(p.name)
    price = fmt_price(p.price, store.currency)
    emoji = "" if no_emoji(tone) else copy["emoji"] + " "
    cta = _cta(category)
    buy = _how_to_buy(store)
    hashtags = " ".join([tag(store.name), tag(category if category != "Other" else name)])

    def body(text: str) -> str:
        if network == "tiktok":
            tags = hashtags if len(hashtags) <= 40 else tag(store.name)
            return cut(text, 99 - len(tags)) + " " + tags
        return cut(text, 250)

    out = [AdVariant(
        angle="Benefit",
        headline=cut(name, 40),
        primary_text=body(f"{emoji}{copy['hook']}. {name} {copy['line']}. {buy}"),
        description=cut(price or store.name, 30),
        call_to_action=cta)]
    if price:
        out.append(AdVariant(
            angle="Price",
            headline=cut(f"{name}, {price}", 40),
            primary_text=body(f"{emoji}{name} for {price}. {copy['cta']} {buy}"),
            description=cut(store.name, 30),
            call_to_action=cta))
    if p.units_30 >= 5:
        out.append(AdVariant(
            angle="Popular",
            headline=cut(f"Our customers' favourite: {name}", 40),
            primary_text=body(f"{emoji}{p.units_30} sold this month and counting. Try {name} from {store.name}. {buy}"),
            description=cut(price or "Order today", 30),
            call_to_action=cta))
    else:
        out.append(AdVariant(
            angle="Invitation",
            headline=cut(f"Try {name} today", 40),
            primary_text=body(f"{emoji}New to {store.name}? Start with {name}. {copy['cta']}"),
            description=cut(price or "Order today", 30),
            call_to_action=cta))
    return out


def ad_copy(inp: AdCopyIn) -> AdCopyOut:
    tips = ["Use a bright, close-up photo: it matters more than the text."]
    if inp.network == "tiktok":
        tips.append("TikTok shows photo ads as a swipeable carousel, so keep your other product photos sharp too.")
    else:
        tips.append("Start with a small daily budget and let it run 3-4 days before judging it.")
    if not inp.product.has_image:
        tips.insert(0, "Add a photo to this product first: ads can't run without one.")
    return AdCopyOut(variants=variants(inp.store, inp.product, inp.network, inp.tone), tips=tips[:3], engine=ENGINE)


def autopilot(inp: AutopilotIn) -> AutopilotOut:
    running = {a.product_id for a in inp.running_ads if a.product_id is not None and a.status != "PAUSED"}
    scored = score_products(inp.products, running)
    picks: list[AdPick] = []
    for i, s in enumerate(choose(scored, inp.slots)):
        network = inp.networks[i % len(inp.networks)]
        v = variants(inp.store, s.product, network)[0]
        picks.append(AdPick(product_id=s.product.id, network=network, headline=v.headline,
                            primary_text=v.primary_text, description=v.description, call_to_action=v.call_to_action,
                            reason=cut(f"Chosen because {s.why}.", 300), score=s.score))
    if not picks:
        return AutopilotOut(picks=[], summary="No products are ready to advertise right now.", engine=ENGINE)
    names = ", ".join(smart_title(p.product.name) for p in choose(scored, inp.slots))
    return AutopilotOut(picks=picks, summary=cut(f"Advertise {names} next: they have the best sales signals.", 400),
                        engine=ENGINE)
