package com.litemarket.payment;

public enum PaymentPurpose {
    /** A seller paying for a plan. */
    SUBSCRIPTION,
    /** A customer paying for an order. */
    ORDER
}
