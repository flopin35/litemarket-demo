# Lite Marketplace: Commercial Licence

Copyright (c) 2026 Wilson Makafui. All rights reserved.

> This is a starting template. Fill in the [brackets], and have it checked by a lawyer in your country before you sell. It is not legal advice.

## 1. Definitions

- **Software**: the Lite Marketplace source code, documentation and assets in this package.
- **Licensor**: [Your full name or company], [country].
- **Licensee**: the person or company who bought a licence.
- **End Product**: one website or platform built with the Software and run under one domain.

## 2. What you may do

### Standard Licence
- Use the Software to build and run **one** End Product, for yourself or for one client.
- Change the code, the design and the branding.
- Charge sellers and customers of that End Product (plans, commissions).

### Extended Licence
- Everything in the Standard Licence, for **up to [5]** End Products.

### Full-Rights Transfer (if agreed in writing)
- Ownership of the copyright passes to the buyer on full payment, as described in a separate signed agreement.

## 3. What you may not do

- Resell, give away or publish the Software, or a modified copy of it, as a template, theme, boilerplate or source-code product.
- Remove this licence from the source code.
- Use the Software for anything illegal, or to collect payments or personal data without telling people.

## 4. Support and updates

- Support by email at [support@example.com] for [6 months] after purchase, for installation questions and bugs.
- Updates for [12 months] after purchase.
- Custom work is not included unless agreed separately.

## 5. Third-party services and components

The Software uses open-source libraries under their own licences (Spring Boot, React, Tailwind CSS, Flask and others) and connects to third-party services (Paystack, Flutterwave, Stripe, Anthropic, OpenAI). You are responsible for your own accounts with those services, their fees, and following their terms.

## 6. No warranty

The Software is provided "as is", without warranty of any kind. The Licensor is not liable for any loss, including lost payments, data or profits, arising from its use. You are responsible for securing your deployment, your keys and your users' data.

## 7. Termination

The licence ends automatically if you break these terms. You must then stop using and delete the Software.
